/*
 * Sybase Mobile Workflow version 2.0.1
 * 
 * Workflow.js
 * This file will be regenerated, so changes made herein will be removed the
 * next time the workflow is regenerated. It is therefore strongly recommended
 * that the user not make changes in this file.
 * 
 * Copyright (c) 2010 Sybase Inc. All rights reserved.
 */



function menuItemCallbackAllMBODataType_update_instanceOnline_Request() {
    if (!customBeforeMenuItemClick('AllMBODataType_update_instance', 'Online_Request')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'AllMBODataType_type_INT_attribKey';
    rmiKeyTypes[0] = 'NUMBER';
    rmiKeys[1] = '_old.AllMBODataType.type_INT';
    rmiKeyTypes[1] = 'NUMBER';
    rmiKeys[2] = 'AllMBODataType_type_LONG_attribKey';
    rmiKeyTypes[2] = 'NUMBER';
    rmiKeys[3] = '_old.AllMBODataType.type_LONG';
    rmiKeyTypes[3] = 'NUMBER';
    rmiKeys[4] = 'AllMBODataType_type_STRING_attribKey';
    rmiKeyTypes[4] = 'TEXT';
    rmiKeys[5] = '_old.AllMBODataType.type_STRING';
    rmiKeyTypes[5] = 'TEXT';
    rmiKeys[6] = 'AllMBODataType_type_DATE_attribKey';
    rmiKeyTypes[6] = 'DATETIME';
    rmiKeys[7] = '_old.AllMBODataType.type_DATE';
    rmiKeyTypes[7] = 'DATETIME';
    rmiKeys[8] = 'AllMBODataType_type_DATETIME_attribKey';
    rmiKeyTypes[8] = 'DATETIME';
    rmiKeys[9] = '_old.AllMBODataType.type_DATETIME';
    rmiKeyTypes[9] = 'DATETIME';
    rmiKeys[10] = 'AllMBODataType_type_TIME_attribKey';
    rmiKeyTypes[10] = 'DATETIME';
    rmiKeys[11] = '_old.AllMBODataType.type_TIME';
    rmiKeyTypes[11] = 'DATETIME';
    rmiKeys[12] = 'AllMBODataType_type_DECIMAL_attribKey';
    rmiKeyTypes[12] = 'NUMBER';
    rmiKeys[13] = '_old.AllMBODataType.type_DECIMAL';
    rmiKeyTypes[13] = 'NUMBER';
    rmiKeys[14] = 'AllMBODataType_type_FLOAT_attribKey';
    rmiKeyTypes[14] = 'NUMBER';
    rmiKeys[15] = '_old.AllMBODataType.type_FLOAT';
    rmiKeyTypes[15] = 'NUMBER';
    rmiKeys[16] = 'AllMBODataType_type_DOUBLE_attribKey';
    rmiKeyTypes[16] = 'NUMBER';
    rmiKeys[17] = '_old.AllMBODataType.type_DOUBLE';
    rmiKeyTypes[17] = 'NUMBER';
    rmiKeys[18] = 'AllMBODataType_type_BOOLEAN_attribKey';
    rmiKeyTypes[18] = 'BOOLEAN';
    rmiKeys[19] = '_old.AllMBODataType.type_BOOLEAN';
    rmiKeyTypes[19] = 'BOOLEAN';
    rmiKeys[20] = 'AllMBODataType_type_BINARY_attribKey';
    rmiKeyTypes[20] = 'TEXT';
    rmiKeys[21] = '_old.AllMBODataType.type_BINARY';
    rmiKeyTypes[21] = 'TEXT';
    rmiKeys[22] = 'AllMBODataType_type_multi_attribKey';
    rmiKeyTypes[22] = 'TEXT';
    rmiKeys[23] = '_old.AllMBODataType.type_multi';
    rmiKeyTypes[23] = 'TEXT';
    rmiKeys[24] = 'AllMBODataType_id_attribKey';
    rmiKeyTypes[24] = 'NUMBER';
    rmiKeys[25] = '_old.AllMBODataType.id';
    rmiKeyTypes[25] = 'NUMBER';
    rmiKeys[26] = 'ErrorLogs';
    rmiKeyTypes[26] = 'LIST';
    rmiInputOnlyKeys[0] = 'AllMBODataType_type_INT_attribKey';
    rmiInputOnlyKeyTypes[0] = 'NUMBER';
    rmiInputOnlyKeys[1] = '_old.AllMBODataType.type_INT';
    rmiInputOnlyKeyTypes[1] = 'NUMBER';
    rmiInputOnlyKeys[2] = 'AllMBODataType_type_LONG_attribKey';
    rmiInputOnlyKeyTypes[2] = 'NUMBER';
    rmiInputOnlyKeys[3] = '_old.AllMBODataType.type_LONG';
    rmiInputOnlyKeyTypes[3] = 'NUMBER';
    rmiInputOnlyKeys[4] = 'AllMBODataType_type_STRING_attribKey';
    rmiInputOnlyKeyTypes[4] = 'TEXT';
    rmiInputOnlyKeys[5] = '_old.AllMBODataType.type_STRING';
    rmiInputOnlyKeyTypes[5] = 'TEXT';
    rmiInputOnlyKeys[6] = 'AllMBODataType_type_DATE_attribKey';
    rmiInputOnlyKeyTypes[6] = 'DATETIME';
    rmiInputOnlyKeys[7] = '_old.AllMBODataType.type_DATE';
    rmiInputOnlyKeyTypes[7] = 'DATETIME';
    rmiInputOnlyKeys[8] = 'AllMBODataType_type_DATETIME_attribKey';
    rmiInputOnlyKeyTypes[8] = 'DATETIME';
    rmiInputOnlyKeys[9] = '_old.AllMBODataType.type_DATETIME';
    rmiInputOnlyKeyTypes[9] = 'DATETIME';
    rmiInputOnlyKeys[10] = 'AllMBODataType_type_TIME_attribKey';
    rmiInputOnlyKeyTypes[10] = 'DATETIME';
    rmiInputOnlyKeys[11] = '_old.AllMBODataType.type_TIME';
    rmiInputOnlyKeyTypes[11] = 'DATETIME';
    rmiInputOnlyKeys[12] = 'AllMBODataType_type_DECIMAL_attribKey';
    rmiInputOnlyKeyTypes[12] = 'NUMBER';
    rmiInputOnlyKeys[13] = '_old.AllMBODataType.type_DECIMAL';
    rmiInputOnlyKeyTypes[13] = 'NUMBER';
    rmiInputOnlyKeys[14] = 'AllMBODataType_type_FLOAT_attribKey';
    rmiInputOnlyKeyTypes[14] = 'NUMBER';
    rmiInputOnlyKeys[15] = '_old.AllMBODataType.type_FLOAT';
    rmiInputOnlyKeyTypes[15] = 'NUMBER';
    rmiInputOnlyKeys[16] = 'AllMBODataType_type_DOUBLE_attribKey';
    rmiInputOnlyKeyTypes[16] = 'NUMBER';
    rmiInputOnlyKeys[17] = '_old.AllMBODataType.type_DOUBLE';
    rmiInputOnlyKeyTypes[17] = 'NUMBER';
    rmiInputOnlyKeys[18] = 'AllMBODataType_type_BOOLEAN_attribKey';
    rmiInputOnlyKeyTypes[18] = 'BOOLEAN';
    rmiInputOnlyKeys[19] = '_old.AllMBODataType.type_BOOLEAN';
    rmiInputOnlyKeyTypes[19] = 'BOOLEAN';
    rmiInputOnlyKeys[20] = 'AllMBODataType_type_BINARY_attribKey';
    rmiInputOnlyKeyTypes[20] = 'TEXT';
    rmiInputOnlyKeys[21] = '_old.AllMBODataType.type_BINARY';
    rmiInputOnlyKeyTypes[21] = 'TEXT';
    rmiInputOnlyKeys[22] = 'AllMBODataType_type_multi_attribKey';
    rmiInputOnlyKeyTypes[22] = 'TEXT';
    rmiInputOnlyKeys[23] = '_old.AllMBODataType.type_multi';
    rmiInputOnlyKeyTypes[23] = 'TEXT';
    rmiInputOnlyKeys[24] = 'AllMBODataType_id_attribKey';
    rmiInputOnlyKeyTypes[24] = 'NUMBER';
    rmiInputOnlyKeys[25] = '_old.AllMBODataType.id';
    rmiInputOnlyKeyTypes[25] = 'NUMBER';
    rmiInputOnlyKeys[26] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[26] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('AllMBODataType_update_instance', 'Online_Request', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('AllMBODataType_update_instance', 'Online_Request', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('AllMBODataType_update_instance', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('AllMBODataType_update_instance', 'Online_Request', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('AllMBODataType_update_instance', 'Online_Request');
}


function menuItemCallbackAllMBODataType_update_instanceCancel() {
    if (!customBeforeMenuItemClick('AllMBODataType_update_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('AllMBODataType_update_instance', 'Cancel');
}


function menuItemCallbackAllMBODataType_delete_instanceOnline_Request() {
    if (!customBeforeMenuItemClick('AllMBODataType_delete_instance', 'Online_Request')) {
        return;
    }

    if (saveScreens()) {
        doSubmitWorkflow('AllMBODataType_delete_instance', 'Online_Request', '', '');
    }
    customAfterMenuItemClick('AllMBODataType_delete_instance', 'Online_Request');
}


function menuItemCallbackAllMBODataType_delete_instanceCancel() {
    if (!customBeforeMenuItemClick('AllMBODataType_delete_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('AllMBODataType_delete_instance', 'Cancel');
}


function menuItemCallbackAllMBODataTypeDetailOpen_AllMBODataType_update_instance() {
    if (!customBeforeMenuItemClick('AllMBODataTypeDetail', 'Open_AllMBODataType_update_instance')) {
        return;
    }
    navigateForward('AllMBODataType_update_instance');
    customAfterMenuItemClick('AllMBODataTypeDetail', 'Open_AllMBODataType_update_instance');
}


function menuItemCallbackAllMBODataTypeDetailOpen_AllMBODataType_delete_instance() {
    if (!customBeforeMenuItemClick('AllMBODataTypeDetail', 'Open_AllMBODataType_delete_instance')) {
        return;
    }
    navigateForward('AllMBODataType_delete_instance');
    customAfterMenuItemClick('AllMBODataTypeDetail', 'Open_AllMBODataType_delete_instance');
}


function menuItemCallbackAllMBODataTypeDetailBack() {
    if (!customBeforeMenuItemClick('AllMBODataTypeDetail', 'Back')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('AllMBODataTypeDetail', 'Back');
}
function menuItemCallbackAllMBODataTypeDetailCancel() {
   if (!customBeforeMenuItemClick('AllMBODataTypeDetail', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('AllMBODataTypeDetail', 'Cancel');
}


function menuItemCallbackAllMBODataTypeSubmit() {
    if (!customBeforeMenuItemClick('AllMBODataType', 'Submit')) {
        return;
    }

    if (saveScreens()) {
        doSubmitWorkflow('AllMBODataType', 'Submit', '', '');
    }
    customAfterMenuItemClick('AllMBODataType', 'Submit');
}


function menuItemCallbackAllMBODataTypeCancel_Screen() {
    if (!customBeforeMenuItemClick('AllMBODataType', 'Cancel_Screen')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('AllMBODataType', 'Cancel_Screen');
}
function menuItemCallbacksuccessScrCancel() {
   if (!customBeforeMenuItemClick('successScr', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('successScr', 'Cancel');
}

function doAddRowAction(addScreen) {
    var mvc = getCurrentMessageValueCollection();
    var relationKey = getListViewKey(getCurrentScreen());
    var mv = mvc.getData(relationKey);
    var childMVC = new MessageValueCollection();
    var key = guid();
    childMVC.setKey(key);
    childMVC.setState("new");
    childMVC.setParent(mv.getKey());
    childMVC.setParentValue(mv);
    mv.getValue().push(childMVC);
    setDefaultValues(addScreen);
    // collect default values from the addScreen
    updateMessageValueCollectionFromUI(childMVC, addScreen);
    navigateForward(addScreen, key);
}

function doListviewAddRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (mvc.getState() === "new") {
        // this action is triggered after AddRow action
        if (validateScreen(getCurrentScreen(), mvc)) {
            mvc.setState("add");
            doSaveAction(false);
        }
    }
}

function doListviewUpdateRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("update");            
        }
        doSaveAction(false);
    }
}

function doListviewDeleteRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("delete");            
            doSaveAction(false);
        }
        else {
            var valuesArray = mvc.getParentValue().getValue();
            for (var i = 0; i < valuesArray.length; i++) {
                if (valuesArray[i] == mvc) {
                    valuesArray.splice(i, 1);
                }
            }
            navigateBack(true);
            updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        }        
    }
}

function doSaveActionWithoutReturn() {
   doSaveAction();
   return;
}

function doSaveAction(needValidation) {
    if (!getPreviousScreen()) {
        if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
            doSubmitWorkflow(getCurrentScreen(), "Save", '', '');
            return false;
        }
        return true;
    }
    if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
        navigateBack(false);
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        return true;
    }
    return false;
}

function doCancelAction() {
    if (!getPreviousScreen()) {
        closeWorkflow();
        return;
    }
    var mvc = getCurrentMessageValueCollection();
    navigateBack(true);
    var mvc1 = getCurrentMessageValueCollection();
    if (mvc.getState() === "add" || mvc.getState() === "new") {
        mvc1.getData(mvc.getParent()).getValue().pop();
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
    } else if (mvc.getState() === "update") {
        mvc.setState("");
    }
}
