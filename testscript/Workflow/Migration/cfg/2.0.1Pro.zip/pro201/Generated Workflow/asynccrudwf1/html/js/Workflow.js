/*
 * Sybase Mobile Workflow version 2.0.1
 * 
 * Workflow.js
 * This file will be regenerated, so changes made herein will be removed the
 * next time the workflow is regenerated. It is therefore strongly recommended
 * that the user not make changes in this file.
 * 
 * Copyright (c) 2010 Sybase Inc. All rights reserved.
 */



function menuItemCallbackDepartment_update_instanceSubmit_Workflow() {
    if (!customBeforeMenuItemClick('Department_update_instance', 'Submit_Workflow')) {
        return;
    }

    if (saveScreens()) {
        doSubmitWorkflow('Department_update_instance', 'Submit_Workflow', '', '');
    }
    customAfterMenuItemClick('Department_update_instance', 'Submit_Workflow');
}


function menuItemCallbackDepartment_update_instanceCancel() {
    if (!customBeforeMenuItemClick('Department_update_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department_update_instance', 'Cancel');
}


function menuItemCallbackDepartment_delete_instanceSubmit_Workflow() {
    if (!customBeforeMenuItemClick('Department_delete_instance', 'Submit_Workflow')) {
        return;
    }

    if (saveScreens()) {
        doSubmitWorkflow('Department_delete_instance', 'Submit_Workflow', '', '');
    }
    customAfterMenuItemClick('Department_delete_instance', 'Submit_Workflow');
}


function menuItemCallbackDepartment_delete_instanceCancel() {
    if (!customBeforeMenuItemClick('Department_delete_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department_delete_instance', 'Cancel');
}


function menuItemCallbackDepartmentDetailOpen_Department_update_instance() {
    if (!customBeforeMenuItemClick('DepartmentDetail', 'Open_Department_update_instance')) {
        return;
    }
    navigateForward('Department_update_instance');
    customAfterMenuItemClick('DepartmentDetail', 'Open_Department_update_instance');
}


function menuItemCallbackDepartmentDetailOpen_Department_delete_instance() {
    if (!customBeforeMenuItemClick('DepartmentDetail', 'Open_Department_delete_instance')) {
        return;
    }
    navigateForward('Department_delete_instance');
    customAfterMenuItemClick('DepartmentDetail', 'Open_Department_delete_instance');
}
function menuItemCallbackDepartmentDetailCancel() {
   if (!customBeforeMenuItemClick('DepartmentDetail', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('DepartmentDetail', 'Cancel');
}

function doAddRowAction(addScreen) {
    var mvc = getCurrentMessageValueCollection();
    var relationKey = getListViewKey(getCurrentScreen());
    var mv = mvc.getData(relationKey);
    var childMVC = new MessageValueCollection();
    var key = guid();
    childMVC.setKey(key);
    childMVC.setState("new");
    childMVC.setParent(mv.getKey());
    childMVC.setParentValue(mv);
    mv.getValue().push(childMVC);
    setDefaultValues(addScreen);
    // collect default values from the addScreen
    updateMessageValueCollectionFromUI(childMVC, addScreen);
    navigateForward(addScreen, key);
}

function doListviewAddRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (mvc.getState() === "new") {
        // this action is triggered after AddRow action
        if (validateScreen(getCurrentScreen(), mvc)) {
            mvc.setState("add");
            doSaveAction(false);
        }
    }
}

function doListviewUpdateRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("update");            
        }
        doSaveAction(false);
    }
}

function doListviewDeleteRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("delete");            
            doSaveAction(false);
        }
        else {
            var valuesArray = mvc.getParentValue().getValue();
            for (var i = 0; i < valuesArray.length; i++) {
                if (valuesArray[i] == mvc) {
                    valuesArray.splice(i, 1);
                }
            }
            navigateBack(true);
            updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        }        
    }
}

function doSaveActionWithoutReturn() {
   doSaveAction();
   return;
}

function doSaveAction(needValidation) {
    if (!getPreviousScreen()) {
        if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
            doSubmitWorkflow(getCurrentScreen(), "Save", '', '');
            return false;
        }
        return true;
    }
    if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
        navigateBack(false);
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        return true;
    }
    return false;
}

function doCancelAction() {
    if (!getPreviousScreen()) {
        closeWorkflow();
        return;
    }
    var mvc = getCurrentMessageValueCollection();
    navigateBack(true);
    var mvc1 = getCurrentMessageValueCollection();
    if (mvc.getState() === "add" || mvc.getState() === "new") {
        mvc1.getData(mvc.getParent()).getValue().pop();
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
    } else if (mvc.getState() === "update") {
        mvc.setState("");
    }
}
