/*
 * Sybase Mobile Workflow version 2.0.1
 * 
 * Workflow.js
 * This file will be regenerated, so changes made herein will be removed the
 * next time the workflow is regenerated. It is therefore strongly recommended
 * that the user not make changes in this file.
 * 
 * Copyright (c) 2010 Sybase Inc. All rights reserved.
 */



function menuItemCallbackStart_ScreenCancel_Screen() {
    if (!customBeforeMenuItemClick('Start_Screen', 'Cancel_Screen')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Start_Screen', 'Cancel_Screen');
}


function menuItemCallbackStart_ScreenOpen_Department_create() {
    if (!customBeforeMenuItemClick('Start_Screen', 'Open_Department_create')) {
        return;
    }
    navigateForward('Department_create');
    customAfterMenuItemClick('Start_Screen', 'Open_Department_create');
}


function menuItemCallbackStart_ScreenOpen_Department_delete() {
    if (!customBeforeMenuItemClick('Start_Screen', 'Open_Department_delete')) {
        return;
    }
    navigateForward('Department_delete');
    customAfterMenuItemClick('Start_Screen', 'Open_Department_delete');
}


function menuItemCallbackDepartment_createCreate() {
    if (!customBeforeMenuItemClick('Department_create', 'Create')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'Department_create_dept_id_paramKey';
    rmiKeyTypes[0] = 'NUMBER';
    rmiKeys[1] = 'Department_create_dept_name_paramKey';
    rmiKeyTypes[1] = 'TEXT';
    rmiKeys[2] = 'Department_create_dept_head_id_paramKey';
    rmiKeyTypes[2] = 'NUMBER';
    rmiKeys[3] = 'ErrorLogs';
    rmiKeyTypes[3] = 'LIST';
    rmiInputOnlyKeys[0] = 'Department_create_dept_id_paramKey';
    rmiInputOnlyKeyTypes[0] = 'NUMBER';
    rmiInputOnlyKeys[1] = 'Department_create_dept_name_paramKey';
    rmiInputOnlyKeyTypes[1] = 'TEXT';
    rmiInputOnlyKeys[2] = 'Department_create_dept_head_id_paramKey';
    rmiInputOnlyKeyTypes[2] = 'NUMBER';
    rmiInputOnlyKeys[3] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[3] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department_create', 'Create', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department_create', 'Create', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('Department_create', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('Department_create', 'Create', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Department_create', 'Create');
}


function menuItemCallbackDepartment_createCancel() {
    if (!customBeforeMenuItemClick('Department_create', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department_create', 'Cancel');
}


function menuItemCallbackDepartment_deleteOnline_Request() {
    if (!customBeforeMenuItemClick('Department_delete', 'Online_Request')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'Department_delete_dept_id_paramKey';
    rmiKeyTypes[0] = 'NUMBER';
    rmiKeys[1] = 'ErrorLogs';
    rmiKeyTypes[1] = 'LIST';
    rmiInputOnlyKeys[0] = 'Department_delete_dept_id_paramKey';
    rmiInputOnlyKeyTypes[0] = 'NUMBER';
    rmiInputOnlyKeys[1] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[1] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department_delete', 'Online_Request', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department_delete', 'Online_Request', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('Department_delete', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('Department_delete', 'Online_Request', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Department_delete', 'Online_Request');
}


function menuItemCallbackDepartment_deleteCancel() {
    if (!customBeforeMenuItemClick('Department_delete', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department_delete', 'Cancel');
}

function doAddRowAction(addScreen) {
    var mvc = getCurrentMessageValueCollection();
    var relationKey = getListViewKey(getCurrentScreen());
    var mv = mvc.getData(relationKey);
    var childMVC = new MessageValueCollection();
    var key = guid();
    childMVC.setKey(key);
    childMVC.setState("new");
    childMVC.setParent(mv.getKey());
    childMVC.setParentValue(mv);
    mv.getValue().push(childMVC);
    setDefaultValues(addScreen);
    // collect default values from the addScreen
    updateMessageValueCollectionFromUI(childMVC, addScreen);
    navigateForward(addScreen, key);
}

function doListviewAddRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (mvc.getState() === "new") {
        // this action is triggered after AddRow action
        if (validateScreen(getCurrentScreen(), mvc)) {
            mvc.setState("add");
            doSaveAction(false);
        }
    }
}

function doListviewUpdateRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("update");            
        }
        doSaveAction(false);
    }
}

function doListviewDeleteRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("delete");            
            doSaveAction(false);
        }
        else {
            var valuesArray = mvc.getParentValue().getValue();
            for (var i = 0; i < valuesArray.length; i++) {
                if (valuesArray[i] == mvc) {
                    valuesArray.splice(i, 1);
                }
            }
            navigateBack(true);
            updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        }        
    }
}

function doSaveActionWithoutReturn() {
   doSaveAction();
   return;
}

function doSaveAction(needValidation) {
    if (!getPreviousScreen()) {
        if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
            doSubmitWorkflow(getCurrentScreen(), "Save", '', '');
            return false;
        }
        return true;
    }
    if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
        navigateBack(false);
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        return true;
    }
    return false;
}

function doCancelAction() {
    if (!getPreviousScreen()) {
        closeWorkflow();
        return;
    }
    var mvc = getCurrentMessageValueCollection();
    navigateBack(true);
    var mvc1 = getCurrentMessageValueCollection();
    if (mvc.getState() === "add" || mvc.getState() === "new") {
        mvc1.getData(mvc.getParent()).getValue().pop();
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
    } else if (mvc.getState() === "update") {
        mvc.setState("");
    }
}
