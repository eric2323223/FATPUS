/*
 * Sybase Mobile Workflow version 2.0.1
 * 
 * Workflow.js
 * This file will be regenerated, so changes made herein will be removed the
 * next time the workflow is regenerated. It is therefore strongly recommended
 * that the user not make changes in this file.
 * 
 * Copyright (c) 2010 Sybase Inc. All rights reserved.
 */



function menuItemCallbackDepartment_update_instanceOnline_Request() {
    if (!customBeforeMenuItemClick('Department_update_instance', 'Online_Request')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'Department_dept_name_attribKey';
    rmiKeyTypes[0] = 'TEXT';
    rmiKeys[1] = '_old.Department.dept_name';
    rmiKeyTypes[1] = 'TEXT';
    rmiKeys[2] = 'Department_dept_head_id_attribKey';
    rmiKeyTypes[2] = 'NUMBER';
    rmiKeys[3] = '_old.Department.dept_head_id';
    rmiKeyTypes[3] = 'NUMBER';
    rmiKeys[4] = 'Department_dept_id_attribKey';
    rmiKeyTypes[4] = 'NUMBER';
    rmiKeys[5] = '_old.Department.dept_id';
    rmiKeyTypes[5] = 'NUMBER';
    rmiKeys[6] = 'ErrorLogs';
    rmiKeyTypes[6] = 'LIST';
    rmiInputOnlyKeys[0] = 'Department_dept_name_attribKey';
    rmiInputOnlyKeyTypes[0] = 'TEXT';
    rmiInputOnlyKeys[1] = '_old.Department.dept_name';
    rmiInputOnlyKeyTypes[1] = 'TEXT';
    rmiInputOnlyKeys[2] = 'Department_dept_head_id_attribKey';
    rmiInputOnlyKeyTypes[2] = 'NUMBER';
    rmiInputOnlyKeys[3] = '_old.Department.dept_head_id';
    rmiInputOnlyKeyTypes[3] = 'NUMBER';
    rmiInputOnlyKeys[4] = 'Department_dept_id_attribKey';
    rmiInputOnlyKeyTypes[4] = 'NUMBER';
    rmiInputOnlyKeys[5] = '_old.Department.dept_id';
    rmiInputOnlyKeyTypes[5] = 'NUMBER';
    rmiInputOnlyKeys[6] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[6] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department_update_instance', 'Online_Request', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department_update_instance', 'Online_Request', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('Department_update_instance', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('Department_update_instance', 'Online_Request', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Department_update_instance', 'Online_Request');
}


function menuItemCallbackDepartment_update_instanceCancel() {
    if (!customBeforeMenuItemClick('Department_update_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department_update_instance', 'Cancel');
}


function menuItemCallbackDepartment_delete_instanceOnline_Request() {
    if (!customBeforeMenuItemClick('Department_delete_instance', 'Online_Request')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'Department_dept_id_attribKey';
    rmiKeyTypes[0] = 'NUMBER';
    rmiKeys[1] = '_old.Department.dept_id';
    rmiKeyTypes[1] = 'NUMBER';
    rmiKeys[2] = 'ErrorLogs';
    rmiKeyTypes[2] = 'LIST';
    rmiKeys[3] = 'Department_dept_name_attribKey';
    rmiKeyTypes[3] = 'TEXT';
    rmiKeys[4] = '_old.Department.dept_name';
    rmiKeyTypes[4] = 'TEXT';
    rmiKeys[5] = 'Department_dept_head_id_attribKey';
    rmiKeyTypes[5] = 'NUMBER';
    rmiKeys[6] = '_old.Department.dept_head_id';
    rmiKeyTypes[6] = 'NUMBER';
    rmiInputOnlyKeys[0] = 'Department_dept_id_attribKey';
    rmiInputOnlyKeyTypes[0] = 'NUMBER';
    rmiInputOnlyKeys[1] = '_old.Department.dept_id';
    rmiInputOnlyKeyTypes[1] = 'NUMBER';
    rmiInputOnlyKeys[2] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[2] = 'LIST';
    rmiInputOnlyKeys[3] = 'Department_dept_name_attribKey';
    rmiInputOnlyKeyTypes[3] = 'TEXT';
    rmiInputOnlyKeys[4] = '_old.Department.dept_name';
    rmiInputOnlyKeyTypes[4] = 'TEXT';
    rmiInputOnlyKeys[5] = 'Department_dept_head_id_attribKey';
    rmiInputOnlyKeyTypes[5] = 'NUMBER';
    rmiInputOnlyKeys[6] = '_old.Department.dept_head_id';
    rmiInputOnlyKeyTypes[6] = 'NUMBER';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department_delete_instance', 'Online_Request', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department_delete_instance', 'Online_Request', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('Department_delete_instance', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('Department_delete_instance', 'Online_Request', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Department_delete_instance', 'Online_Request');
}


function menuItemCallbackDepartment_delete_instanceCancel() {
    if (!customBeforeMenuItemClick('Department_delete_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department_delete_instance', 'Cancel');
}


function menuItemCallbackDepartment_deleteOnline_Request() {
    if (!customBeforeMenuItemClick('Department_delete', 'Online_Request')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'Department_delete_dept_id_paramKey';
    rmiKeyTypes[0] = 'NUMBER';
    rmiKeys[1] = 'ErrorLogs';
    rmiKeyTypes[1] = 'LIST';
    rmiKeys[2] = 'Department_dept_id_attribKey';
    rmiKeyTypes[2] = 'NUMBER';
    rmiKeys[3] = '_old.Department.dept_id';
    rmiKeyTypes[3] = 'NUMBER';
    rmiKeys[4] = 'Department_dept_name_attribKey';
    rmiKeyTypes[4] = 'TEXT';
    rmiKeys[5] = '_old.Department.dept_name';
    rmiKeyTypes[5] = 'TEXT';
    rmiKeys[6] = 'Department_dept_head_id_attribKey';
    rmiKeyTypes[6] = 'NUMBER';
    rmiKeys[7] = '_old.Department.dept_head_id';
    rmiKeyTypes[7] = 'NUMBER';
    rmiInputOnlyKeys[0] = 'Department_delete_dept_id_paramKey';
    rmiInputOnlyKeyTypes[0] = 'NUMBER';
    rmiInputOnlyKeys[1] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[1] = 'LIST';
    rmiInputOnlyKeys[2] = 'Department_dept_id_attribKey';
    rmiInputOnlyKeyTypes[2] = 'NUMBER';
    rmiInputOnlyKeys[3] = '_old.Department.dept_id';
    rmiInputOnlyKeyTypes[3] = 'NUMBER';
    rmiInputOnlyKeys[4] = 'Department_dept_name_attribKey';
    rmiInputOnlyKeyTypes[4] = 'TEXT';
    rmiInputOnlyKeys[5] = '_old.Department.dept_name';
    rmiInputOnlyKeyTypes[5] = 'TEXT';
    rmiInputOnlyKeys[6] = 'Department_dept_head_id_attribKey';
    rmiInputOnlyKeyTypes[6] = 'NUMBER';
    rmiInputOnlyKeys[7] = '_old.Department.dept_head_id';
    rmiInputOnlyKeyTypes[7] = 'NUMBER';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department_delete', 'Online_Request', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department_delete', 'Online_Request', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('Department_delete', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('Department_delete', 'Online_Request', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Department_delete', 'Online_Request');
}


function menuItemCallbackDepartment_deleteCancel() {
    if (!customBeforeMenuItemClick('Department_delete', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department_delete', 'Cancel');
}


function menuItemCallbackDepartmentDetailOpen_Department_update_instance() {
    if (!customBeforeMenuItemClick('DepartmentDetail', 'Open_Department_update_instance')) {
        return;
    }
    navigateForward('Department_update_instance');
    customAfterMenuItemClick('DepartmentDetail', 'Open_Department_update_instance');
}


function menuItemCallbackDepartmentDetailOpen_Department_delete_instance() {
    if (!customBeforeMenuItemClick('DepartmentDetail', 'Open_Department_delete_instance')) {
        return;
    }
    navigateForward('Department_delete_instance');
    customAfterMenuItemClick('DepartmentDetail', 'Open_Department_delete_instance');
}


function menuItemCallbackDepartmentDetailBack() {
    if (!customBeforeMenuItemClick('DepartmentDetail', 'Back')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('DepartmentDetail', 'Back');
}
function menuItemCallbackDepartmentDetailCancel() {
   if (!customBeforeMenuItemClick('DepartmentDetail', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('DepartmentDetail', 'Cancel');
}


function menuItemCallbackDepartmentSubmit() {
    if (!customBeforeMenuItemClick('Department', 'Submit')) {
        return;
    }

    if (saveScreens()) {
        doSubmitWorkflow('Department', 'Submit', '', '');
    }
    customAfterMenuItemClick('Department', 'Submit');
}


function menuItemCallbackDepartmentCancel_Screen() {
    if (!customBeforeMenuItemClick('Department', 'Cancel_Screen')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department', 'Cancel_Screen');
}

function doAddRowAction(addScreen) {
    var mvc = getCurrentMessageValueCollection();
    var relationKey = getListViewKey(getCurrentScreen());
    var mv = mvc.getData(relationKey);
    var childMVC = new MessageValueCollection();
    var key = guid();
    childMVC.setKey(key);
    childMVC.setState("new");
    childMVC.setParent(mv.getKey());
    childMVC.setParentValue(mv);
    mv.getValue().push(childMVC);
    setDefaultValues(addScreen);
    // collect default values from the addScreen
    updateMessageValueCollectionFromUI(childMVC, addScreen);
    navigateForward(addScreen, key);
}

function doListviewAddRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (mvc.getState() === "new") {
        // this action is triggered after AddRow action
        if (validateScreen(getCurrentScreen(), mvc)) {
            mvc.setState("add");
            doSaveAction(false);
        }
    }
}

function doListviewUpdateRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("update");            
        }
        doSaveAction(false);
    }
}

function doListviewDeleteRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("delete");            
            doSaveAction(false);
        }
        else {
            var valuesArray = mvc.getParentValue().getValue();
            for (var i = 0; i < valuesArray.length; i++) {
                if (valuesArray[i] == mvc) {
                    valuesArray.splice(i, 1);
                }
            }
            navigateBack(true);
            updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        }        
    }
}

function doSaveActionWithoutReturn() {
   doSaveAction();
   return;
}

function doSaveAction(needValidation) {
    if (!getPreviousScreen()) {
        if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
            doSubmitWorkflow(getCurrentScreen(), "Save", '', '');
            return false;
        }
        return true;
    }
    if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
        navigateBack(false);
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        return true;
    }
    return false;
}

function doCancelAction() {
    if (!getPreviousScreen()) {
        closeWorkflow();
        return;
    }
    var mvc = getCurrentMessageValueCollection();
    navigateBack(true);
    var mvc1 = getCurrentMessageValueCollection();
    if (mvc.getState() === "add" || mvc.getState() === "new") {
        mvc1.getData(mvc.getParent()).getValue().pop();
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
    } else if (mvc.getState() === "update") {
        mvc.setState("");
    }
}
