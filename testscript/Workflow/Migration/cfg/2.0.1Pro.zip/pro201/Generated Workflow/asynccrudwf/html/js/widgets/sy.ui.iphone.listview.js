$.widget("sy.syListview", {
    _create:function() {
        this.element.listview = $('<ul data-role="listview"  class="ui-listview" role="listbox">');
        this.element.append( this.element.listview );
        
        if ( this.options.showViewHeader ){
            this._createHeader();
        }
    },
      
    updateUIFromWorkFlowMessage:function( params ) {
        var id = this.element[0].getAttribute('id');
        var data  = params[0].getData( id );
        if (!data) {
            data = new MessageValue();
            data.setType("LIST");
            data.setKey(id);
            data.setValue(new Array(0));
            params[0].add(id, data);
        }
        var dataValue = data.value;
             
        var wrapData = this.element[0].getAttribute('wrap_data');
        wrapData = wrapData != null && wrapData === "true"; 

        var fields = this.options.fields;
        var lines = this.options.lines;
     
        var cellstr = "";
        this.element.listview[0].innerHTML = "";
        
        var pixelRatio2 = "";
        if ( window.devicePixelRatio && window.devicePixelRatio >= 2 ) {
            pixelRatio2 =" ui-icon-arrow-r-pixelratio-2";
        }
             
        var numValues = dataValue.length;
        for (var valuesIdx = 0; valuesIdx < numValues; valuesIdx++) { //for each values in a list
            var listValues = dataValue[valuesIdx];
            if (listValues.getState() === "delete") {
                continue;
            }            
                  
            var test =valuesIdx/2 -  Math.round(valuesIdx/2 );
            var  setAltClr =  test < 0  && this.options. alternateColor.length > 0;
            var alterClr = "";  
            if ( setAltClr ) {
                alterClr = this.element.attr('screen') + "_alternateColor";
            }
           
            cellstr += '<li role="option" class="'+ alterClr +' ui-btn disable_hover ui-btn-icon-right ui-li ui-btn-up-c" id="'+ valuesIdx + '">';
            cellstr += '<div class="ui-btn-inner">';
            cellstr += '<div class="ui-btn-text">';
            if (isBlackBerry()) { // we don't use link for Blackberry, since it reloads the page.
            }else {
                cellstr += '<a href="" class="listviewLines ui-link-inherit" id="' +listValues.getKey() +'">';
            }
            cellstr += this._createLines( data, valuesIdx, false, wrapData );
            
            if ( isBlackBerry()) {
                cellstr += '<span class="ui-icon ui-icon-arrow-r"></span></div></div></li>';
            }else {
                cellstr += '</a><span class="ui-icon ui-icon-arrow-r' + pixelRatio2 + '"></span></div></div></li>';
            }
        }
        if (numValues === 0 && this.options.onEmptyList) {
            cellstr += '<li role="option" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c">';
            cellstr += '<div class="ui-btn-inner">';
            cellstr += '<div class="ui-btn-text">';
            cellstr += '<div class="lv_line">';
            var value  =this.options.onEmptyList;

            var lineWidth = screen.width -40; //20 for arrow and 20 for margins
            var w = parseInt( lineWidth );
            var style = ' float: left; width:' + w + 'px;' + 'font-style:normal;font-weight:normal';
               
            var s = '<div  class="lv_line_field" style="'+ style +'">'+ value+'</div>';
            cellstr += s;

            cellstr += '</div>'; //end of line;
            if ( isBlackBerry()) {
                cellstr += '<span class="ui-icon ui-icon-arrow-r"></span></div></div></li>';
            }else {
                cellstr += '<span class="ui-icon ui-icon-arrow-r' + pixelRatio2 + '"></span></div></div></li>';
            }
        }
        
        this.element.listview.append(cellstr);

        if (numValues > 0 || !this.options.onEmptyList) {
	        var self = this;
	   
	        if (isBlackBerry()) {
	        
	            $('div.lv_lines',this.element.listview).bind('click',  function(){
	               
	                var liEle = this.parentElement.parentElement.parentElement;
	                $( liEle ).addClass("ui-btn-down-c");
	                
	                if ( self.options.onItemSelected != null ) {
	                    self.options.onItemSelected( this  );
	                } 
	                $( liEle ).removeClass("ui-btn-down-c");
	           });
	        
	        }
	        else if (isWindows()) {
	            $('a.listviewLines').bind('click',  function() {
	                var li = this.parentElement.parentElement.parentElement.parentElement.parentElement;
	                $(li).addClass('ui-btn-down-c');
	                    if ( self.options.onItemSelected != null) {
	                        self.options.onItemSelected(this);
	                    }
	                $(li).removeClass('ui-btn-down-c');
	            });
		    }
	        else {
	            var that = this;
	            
	            $('a.listviewLines').bind('touchstart',  function(){
	                that.isTouchMove = false;
	            });
	            
	            $('a.listviewLines').bind('touchmove',  function(){
	                that.isTouchMove = true;
	            });
	              
	            $('a.listviewLines').bind('touchend',  function(){
	                if ( that.isTouchMove ) {
	                    return;
	                }
	                 var li = this.parentElement.parentElement.parentElement.parentElement.parentElement;
	                $(li).addClass('ui-btn-down-c');
	                    if ( self.options.onItemSelected != null ) {
	                        self.options.onItemSelected( this  );
	                    } 
	                $(li).removeClass('ui-btn-down-c');
	                   
	            });
	        }
        }
    },
    
    _createLines:function( data,valuesIdx, isForHeader, wrapData  ) {
       var lines = this.options.lines;
      
        var cellstr = "";
        var listValues =  null;
        
        if (    data != null ) {      
            listValues = data.value[valuesIdx];
        }
        
        if ( listValues != null ) {
            cellstr += '<div class="lv_lines" id="' +listValues.getKey() +'">';
        }else {
            cellstr += '<div class="lv_lines">';
        }    
        
        var numLines = lines.length;
        for( var l = 0; l < numLines; l++ ) {
            cellstr += '<div class="lv_line">';
            var numFields = lines[l].length;
            for( var f = 0; f < numFields; f++ ) {
                var field = lines[l][f];
                var fieldData = (listValues) ? listValues.getData(field.id) : listValues;
                var value = field.name;
            
                if ( fieldData ) {
                    value  = fieldData.value;
                 
                    if (field.dataType === "DATE") {
                        var strIdx = value.indexOf("T");
                        if (strIdx !== -1) {
                            value = value.substr(0, strIdx);
                        }
                    } else if (field.dataType === "TIME") {
                        var strIdx = value.indexOf("T");
                        if (strIdx !== -1) {
                            value = value.substr(strIdx+1);
                        }
                    } else if (field.dataType === "DATETIME") {
                        var aDate = new Date(parseDateTime(null, value));
                        value = getDateTimeStringToDisplay(aDate, true);
                    }

                    if( value === '' ) {
                    	// Empty value.  Use a filler to maintain row height for the value.
                    	value = '<p></p>';
                    } else {
                    	if( wrapData ) {
                    		// User has HTML tags that they want treated as text
                    		// in the list, not markup.  Replace all &, <, and >
                    		// and wrap in PRE and CODE tags.
                    		value = value.toString().replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
                    		value = "<PRE><CODE>" + value + "</CODE></PRE>";
                    	}
                    }
                } else if ( !isForHeader )  {
                	// No data for the field.id, use a filler
                	value = '<p></p>';
                }
                var lineWidth = screen.width -40; //20 for arrow and 20 for margins
                var w = parseInt( lineWidth * field.width/100);
                var font = "normal";
                if (  data != null  ) { 
                    font  =field.font;
                }
                var style = ' float: left; width:' + w + 'px;' + 'font-style:' + font +';font-weight:normal';
               
                if ( field.font == "bold" ) {
                    style = style.replace('font-weight:normal', 'font-weight:bold');
                } 
                s = '<div  class="lv_line_field" style="'+ style +'">'+ value+'</div>';
                cellstr += s;
            }  
            cellstr += '</div>'; //end of line;
        }
        cellstr += '</div>'; //end of lines 
     
        return cellstr;
    },
      
     _createHeader:function() {
        var parents = this.element.parents();
        var page = null;
        
        var numParents = parents.length;
        for( var i =0; i < numParents; i++ ) {
            var node = parents.get( i);
            var value = $(node).attr('data-role');
            if ( value == 'page' ) {
                page = node;
                break;
            }
        }
        
        var header = null;
        var footer = null;
        
        
        if ( page != null ) {
            var children = page.children;
            value = "";
            
            var numChildren = children.length;
            for( var i =0; i < numChildren ; i++ ) {
                var value = $(children[i]).attr('data-role');
                if ( value =='header') {
                    header = children[i];
                }else if ( value =='footer') {
                    footer = children[i];
                }
             }
        }
        
        if ( header != null && this.options.showViewHeader ) {
            var listheader =  $('<div class="listview_header ui-bar-a" >');
            $(header).after( listheader );
            listheader.append( this._createLines( null, null, true ));
        }
     },
        
     options : {
         lines : null,
         data:[],
         showViewHeader:false,
         onEmptyList:"",
         alternateColor:"",
         onItemSelected:null
    }
});

