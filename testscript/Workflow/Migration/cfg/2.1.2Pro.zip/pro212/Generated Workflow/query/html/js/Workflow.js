/*
 * Sybase Mobile Workflow version 2.1.2
 * 
 * Workflow.js
 * This file will be regenerated, so changes made herein will be removed the
 * next time the workflow is regenerated. It is therefore strongly recommended
 * that the user not make changes in this file.
 * 
 * The template used to create this file was compiled on Wed Jan 25 04:34:30 PST 2012
 *
 * Copyright (c) 2010, 2011 Sybase Inc. All rights reserved.
 */



function menuItemCallbackStart_ScreenCancel_Screen() {
    if (!customBeforeMenuItemClick('Start_Screen', 'Cancel_Screen')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Start_Screen', 'Cancel_Screen');
}


function menuItemCallbackStart_Screenfindall() {
    if (!customBeforeMenuItemClick('Start_Screen', 'findall')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Start_Screen', 'findall', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Start_Screen', 'findall', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('Start_Screen', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('Start_Screen', 'findall', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Start_Screen', 'findall');
}


function menuItemCallbackStart_Screenfindbypk() {
    if (!customBeforeMenuItemClick('Start_Screen', 'findbypk')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'item';
    rmiKeyTypes[0] = 'NUMBER';
    rmiInputOnlyKeys[0] = 'item';
    rmiInputOnlyKeyTypes[0] = 'NUMBER';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Start_Screen', 'findbypk', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Start_Screen', 'findbypk', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('Start_Screen', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('Start_Screen', 'findbypk', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Start_Screen', 'findbypk');
}


function menuItemCallbackDepartment_createOnline_Request() {
    if (!customBeforeMenuItemClick('Department_create', 'Online Request')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'Department_create_dept_id_paramKey';
    rmiKeyTypes[0] = 'NUMBER';
    rmiKeys[1] = 'Department_create_dept_name_paramKey';
    rmiKeyTypes[1] = 'TEXT';
    rmiKeys[2] = 'Department_create_dept_head_id_paramKey';
    rmiKeyTypes[2] = 'NUMBER';
    rmiKeys[3] = 'ErrorLogs';
    rmiKeyTypes[3] = 'LIST';
    rmiInputOnlyKeys[0] = 'Department_create_dept_id_paramKey';
    rmiInputOnlyKeyTypes[0] = 'NUMBER';
    rmiInputOnlyKeys[1] = 'Department_create_dept_name_paramKey';
    rmiInputOnlyKeyTypes[1] = 'TEXT';
    rmiInputOnlyKeys[2] = 'Department_create_dept_head_id_paramKey';
    rmiInputOnlyKeyTypes[2] = 'NUMBER';
    rmiInputOnlyKeys[3] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[3] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department_create', 'Online Request', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department_create', 'Online Request', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('Department_create', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('Department_create', 'Online Request', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Department_create', 'Online Request');
}


function menuItemCallbackDepartment_createCancel() {
    if (!customBeforeMenuItemClick('Department_create', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department_create', 'Cancel');
}


function menuItemCallbackDepartment_update_instanceOnline_Request() {
    if (!customBeforeMenuItemClick('Department_update_instance', 'Online Request')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'Department_dept_name_attribKey';
    rmiKeyTypes[0] = 'TEXT';
    rmiKeys[1] = '_old.Department.dept_name';
    rmiKeyTypes[1] = 'TEXT';
    rmiKeys[2] = 'Department_dept_head_id_attribKey';
    rmiKeyTypes[2] = 'NUMBER';
    rmiKeys[3] = '_old.Department.dept_head_id';
    rmiKeyTypes[3] = 'NUMBER';
    rmiKeys[4] = 'Department_dept_id_attribKey';
    rmiKeyTypes[4] = 'NUMBER';
    rmiKeys[5] = '_old.Department.dept_id';
    rmiKeyTypes[5] = 'NUMBER';
    rmiKeys[6] = 'ErrorLogs';
    rmiKeyTypes[6] = 'LIST';
    rmiInputOnlyKeys[0] = 'Department_dept_name_attribKey';
    rmiInputOnlyKeyTypes[0] = 'TEXT';
    rmiInputOnlyKeys[1] = '_old.Department.dept_name';
    rmiInputOnlyKeyTypes[1] = 'TEXT';
    rmiInputOnlyKeys[2] = 'Department_dept_head_id_attribKey';
    rmiInputOnlyKeyTypes[2] = 'NUMBER';
    rmiInputOnlyKeys[3] = '_old.Department.dept_head_id';
    rmiInputOnlyKeyTypes[3] = 'NUMBER';
    rmiInputOnlyKeys[4] = 'Department_dept_id_attribKey';
    rmiInputOnlyKeyTypes[4] = 'NUMBER';
    rmiInputOnlyKeys[5] = '_old.Department.dept_id';
    rmiInputOnlyKeyTypes[5] = 'NUMBER';
    rmiInputOnlyKeys[6] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[6] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department_update_instance', 'Online Request', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department_update_instance', 'Online Request', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('Department_update_instance', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('Department_update_instance', 'Online Request', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Department_update_instance', 'Online Request');
}


function menuItemCallbackDepartment_update_instanceCancel() {
    if (!customBeforeMenuItemClick('Department_update_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department_update_instance', 'Cancel');
}


function menuItemCallbackDepartment_delete_instanceOnline_Request() {
    if (!customBeforeMenuItemClick('Department_delete_instance', 'Online Request')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'Department_dept_id_attribKey';
    rmiKeyTypes[0] = 'NUMBER';
    rmiKeys[1] = '_old.Department.dept_id';
    rmiKeyTypes[1] = 'NUMBER';
    rmiKeys[2] = 'Department_dept_name_attribKey';
    rmiKeyTypes[2] = 'TEXT';
    rmiKeys[3] = '_old.Department.dept_name';
    rmiKeyTypes[3] = 'TEXT';
    rmiKeys[4] = 'Department_dept_head_id_attribKey';
    rmiKeyTypes[4] = 'NUMBER';
    rmiKeys[5] = '_old.Department.dept_head_id';
    rmiKeyTypes[5] = 'NUMBER';
    rmiKeys[6] = 'ErrorLogs';
    rmiKeyTypes[6] = 'LIST';
    rmiInputOnlyKeys[0] = 'Department_dept_id_attribKey';
    rmiInputOnlyKeyTypes[0] = 'NUMBER';
    rmiInputOnlyKeys[1] = '_old.Department.dept_id';
    rmiInputOnlyKeyTypes[1] = 'NUMBER';
    rmiInputOnlyKeys[2] = 'Department_dept_name_attribKey';
    rmiInputOnlyKeyTypes[2] = 'TEXT';
    rmiInputOnlyKeys[3] = '_old.Department.dept_name';
    rmiInputOnlyKeyTypes[3] = 'TEXT';
    rmiInputOnlyKeys[4] = 'Department_dept_head_id_attribKey';
    rmiInputOnlyKeyTypes[4] = 'NUMBER';
    rmiInputOnlyKeys[5] = '_old.Department.dept_head_id';
    rmiInputOnlyKeyTypes[5] = 'NUMBER';
    rmiInputOnlyKeys[6] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[6] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department_delete_instance', 'Online Request', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department_delete_instance', 'Online Request', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('Department_delete_instance', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('Department_delete_instance', 'Online Request', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Department_delete_instance', 'Online Request');
}


function menuItemCallbackDepartment_delete_instanceCancel() {
    if (!customBeforeMenuItemClick('Department_delete_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department_delete_instance', 'Cancel');
}


function menuItemCallbackDepartmentDetailOpen_Department_update_instance() {
    if (!customBeforeMenuItemClick('DepartmentDetail', 'Open Department_update_instance')) {
        return;
    }
    navigateForward('Department_update_instance');
    customAfterMenuItemClick('DepartmentDetail', 'Open Department_update_instance');
}


function menuItemCallbackDepartmentDetailOpen_Department_delete_instance() {
    if (!customBeforeMenuItemClick('DepartmentDetail', 'Open Department_delete_instance')) {
        return;
    }
    navigateForward('Department_delete_instance');
    customAfterMenuItemClick('DepartmentDetail', 'Open Department_delete_instance');
}


function menuItemCallbackDepartmentDetailBack() {
    if (!customBeforeMenuItemClick('DepartmentDetail', 'Back')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('DepartmentDetail', 'Back');
}
function menuItemCallbackDepartmentDetailCancel() {
    if (!customBeforeMenuItemClick('DepartmentDetail', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('DepartmentDetail', 'Cancel');
}


function menuItemCallbackDepartmentSubmit() {
    if (!customBeforeMenuItemClick('Department', 'Submit')) {
        return;
    }

    if (saveScreens()) {
        doSubmitWorkflow('Department', 'Submit', '', '');
    }
    customAfterMenuItemClick('Department', 'Submit');
}


function menuItemCallbackDepartmentCancel_Screen() {
    if (!customBeforeMenuItemClick('Department', 'Cancel_Screen')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department', 'Cancel_Screen');
}

function doAddRowAction() {
    var mvc = getCurrentMessageValueCollection();
    var listview = getListviewMessageValue();
    if (listview) {
        var childMVC = new MessageValueCollection();
        var key = guid();
        childMVC.setKey(key);
        childMVC.setState("new");
        childMVC.setParent(listview.getKey());
        childMVC.setParentValue(listview);
        listview.getValue().push(childMVC);
        console.log(workflowMessage.serializeToString());
        if (validateScreen(getCurrentScreen(), mvc)) {
            listViewValuesKey.pop();
            listViewValuesKey.push(childMVC.getKey());
            doListviewAddRowAction();
            console.log(workflowMessage.serializeToString());
        }
    }
}

function doCreateKeyCollectionAction(addScreen) {
    var mvc = getCurrentMessageValueCollection();
    var relationKey = getListViewKey(getCurrentScreen());
    var mv = mvc.getData(relationKey);
    var childMVC = new MessageValueCollection();
    var key = guid();
    childMVC.setKey(key);
    childMVC.setState("new");
    childMVC.setParent(mv.getKey());
    childMVC.setParentValue(mv);
    mv.getValue().push(childMVC);
    setDefaultValues(addScreen);
    // collect default values from the addScreen
    updateMessageValueCollectionFromUI(childMVC, addScreen);
    navigateForward(addScreen, key);
}

function doListviewAddRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (mvc.getState() === "new") {
        // this action is triggered after AddRow action
        if (validateScreen(getCurrentScreen(), mvc)) {
            mvc.setState("add");
            doSaveAction(false);
        }
    }
}

function doListviewUpdateRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("update");            
        }
        doSaveAction(false);
    }
}

function doListviewDeleteRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("delete");            
            doSaveAction(false);
        }
        else {
            var valuesArray = mvc.getParentValue().getValue();
            for (var i = 0; i < valuesArray.length; i++) {
                if (valuesArray[i] == mvc) {
                    valuesArray.splice(i, 1);
                }
            }
            navigateBack(true);
            updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        }        
    }
}

function doSaveActionWithoutReturn() {
   doSaveAction();
   return;
}

function doSaveAction(needValidation) {
    if (!getPreviousScreen()) {
        if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
            doSubmitWorkflow(getCurrentScreen(), "Save", '', '');
            return false;
        }
        return true;
    }
    if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
        navigateBack(false, false);
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        return true;
    }
    return false;
}

function doCancelAction() {
    if (!getPreviousScreen()) {
        closeWorkflow();
        return;
    }
    
    var mvc = getCurrentMessageValueCollection();
    navigateBack(true);
    var mvc1 = getCurrentMessageValueCollection();
    
    //if we are moving onto a listview screen we should delete any newly added rows
    if (mvc != mvc1) {
        //find the items of the listview and if any of them are marked as new, delete them.
        var messValues = mvc1.getValues();
        for (var i = 0; i < messValues.length; i++) {
            if (messValues[i].getType() === "LIST") {
                var listViewValuesArray = messValues[i].getValue()
                for (var j = 0; j < listViewValuesArray.length; j++) {
                    if (listViewValuesArray[j].getState() === "new") {
                        listViewValuesArray.splice(j, 1);
                        j--;
                    }
                }
            }        
        }
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
    }
    else if (mvc.getState() === "update") {
        mvc.setState("");
    }
}

function customNavigationEntry() {
    this.condition;
    this.screen;
}
function customNavigationEntry( a_condition, a_screen ) {
    this.condition = a_condition;
    this.screen = a_screen;
}

/**
 * For the specific pair - screen named 'currentScreenKey' and the action 'actionName', return
 * the list of custom navigation condition-names and their destination screens.
 */
function getCustomNavigations( currentScreenKey, actionName )  {
    var customNavigations = new Array();
    return customNavigations;
}
