/*
 * Sybase Mobile Workflow version 2.1.2
 * 
 * Workflow.js
 * This file will be regenerated, so changes made herein will be removed the
 * next time the workflow is regenerated. It is therefore strongly recommended
 * that the user not make changes in this file.
 * 
 * The template used to create this file was compiled on Wed Jan 25 04:34:30 PST 2012
 *
 * Copyright (c) 2010, 2011 Sybase Inc. All rights reserved.
 */



function menuItemCallbackDepartment1_createOnline_Request() {
    if (!customBeforeMenuItemClick('Department1_create', 'Online Request')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'Department1_create_dept_id_paramKey';
    rmiKeyTypes[0] = 'NUMBER';
    rmiKeys[1] = 'Department1_create_dept_name_paramKey';
    rmiKeyTypes[1] = 'TEXT';
    rmiKeys[2] = 'Department1_create_dept_head_id_paramKey';
    rmiKeyTypes[2] = 'NUMBER';
    rmiKeys[3] = 'ErrorLogs';
    rmiKeyTypes[3] = 'LIST';
    rmiInputOnlyKeys[0] = 'Department1_create_dept_id_paramKey';
    rmiInputOnlyKeyTypes[0] = 'NUMBER';
    rmiInputOnlyKeys[1] = 'Department1_create_dept_name_paramKey';
    rmiInputOnlyKeyTypes[1] = 'TEXT';
    rmiInputOnlyKeys[2] = 'Department1_create_dept_head_id_paramKey';
    rmiInputOnlyKeyTypes[2] = 'NUMBER';
    rmiInputOnlyKeys[3] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[3] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department1_create', 'Online Request', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department1_create', 'Online Request', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('Department1_create', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('Department1_create', 'Online Request', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Department1_create', 'Online Request');
}


function menuItemCallbackDepartment1_createCancel() {
    if (!customBeforeMenuItemClick('Department1_create', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department1_create', 'Cancel');
}


function menuItemCallbackDepartment1_update_instanceOnline_Request() {
    if (!customBeforeMenuItemClick('Department1_update_instance', 'Online Request')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'Department1_dept_name_attribKey';
    rmiKeyTypes[0] = 'TEXT';
    rmiKeys[1] = '_old.Department1.dept_name';
    rmiKeyTypes[1] = 'TEXT';
    rmiKeys[2] = 'Department1_dept_head_id_attribKey';
    rmiKeyTypes[2] = 'NUMBER';
    rmiKeys[3] = '_old.Department1.dept_head_id';
    rmiKeyTypes[3] = 'NUMBER';
    rmiKeys[4] = 'Department1_dept_id_attribKey';
    rmiKeyTypes[4] = 'NUMBER';
    rmiKeys[5] = '_old.Department1.dept_id';
    rmiKeyTypes[5] = 'NUMBER';
    rmiKeys[6] = 'ErrorLogs';
    rmiKeyTypes[6] = 'LIST';
    rmiKeys[7] = 'Department1_products_relationshipKey';
    rmiKeyTypes[7] = 'LIST';
    rmiKeys[8] = '_old.Department1.products.Department1_products_relationshipKey';
    rmiKeyTypes[8] = 'LIST';
    rmiInputOnlyKeys[0] = 'Department1_dept_name_attribKey';
    rmiInputOnlyKeyTypes[0] = 'TEXT';
    rmiInputOnlyKeys[1] = '_old.Department1.dept_name';
    rmiInputOnlyKeyTypes[1] = 'TEXT';
    rmiInputOnlyKeys[2] = 'Department1_dept_head_id_attribKey';
    rmiInputOnlyKeyTypes[2] = 'NUMBER';
    rmiInputOnlyKeys[3] = '_old.Department1.dept_head_id';
    rmiInputOnlyKeyTypes[3] = 'NUMBER';
    rmiInputOnlyKeys[4] = 'Department1_dept_id_attribKey';
    rmiInputOnlyKeyTypes[4] = 'NUMBER';
    rmiInputOnlyKeys[5] = '_old.Department1.dept_id';
    rmiInputOnlyKeyTypes[5] = 'NUMBER';
    rmiInputOnlyKeys[6] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[6] = 'LIST';
    rmiInputOnlyKeys[7] = 'Department1_products_relationshipKey';
    rmiInputOnlyKeyTypes[7] = 'LIST';
    rmiInputOnlyKeys[8] = '_old.Department1.products.Department1_products_relationshipKey';
    rmiInputOnlyKeyTypes[8] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department1_update_instance', 'Online Request', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department1_update_instance', 'Online Request', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('Department1_update_instance', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('Department1_update_instance', 'Online Request', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Department1_update_instance', 'Online Request');
}


function menuItemCallbackDepartment1_update_instanceCancel() {
    if (!customBeforeMenuItemClick('Department1_update_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department1_update_instance', 'Cancel');
}


function menuItemCallbackDepartment1_delete_instanceOnline_Request() {
    if (!customBeforeMenuItemClick('Department1_delete_instance', 'Online Request')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'Department1_dept_id_attribKey';
    rmiKeyTypes[0] = 'NUMBER';
    rmiKeys[1] = '_old.Department1.dept_id';
    rmiKeyTypes[1] = 'NUMBER';
    rmiKeys[2] = 'Department1_dept_name_attribKey';
    rmiKeyTypes[2] = 'TEXT';
    rmiKeys[3] = '_old.Department1.dept_name';
    rmiKeyTypes[3] = 'TEXT';
    rmiKeys[4] = 'Department1_dept_head_id_attribKey';
    rmiKeyTypes[4] = 'NUMBER';
    rmiKeys[5] = '_old.Department1.dept_head_id';
    rmiKeyTypes[5] = 'NUMBER';
    rmiKeys[6] = 'ErrorLogs';
    rmiKeyTypes[6] = 'LIST';
    rmiKeys[7] = 'Department1_products_relationshipKey';
    rmiKeyTypes[7] = 'LIST';
    rmiKeys[8] = '_old.Department1.products.Department1_products_relationshipKey';
    rmiKeyTypes[8] = 'LIST';
    rmiInputOnlyKeys[0] = 'Department1_dept_id_attribKey';
    rmiInputOnlyKeyTypes[0] = 'NUMBER';
    rmiInputOnlyKeys[1] = '_old.Department1.dept_id';
    rmiInputOnlyKeyTypes[1] = 'NUMBER';
    rmiInputOnlyKeys[2] = 'Department1_dept_name_attribKey';
    rmiInputOnlyKeyTypes[2] = 'TEXT';
    rmiInputOnlyKeys[3] = '_old.Department1.dept_name';
    rmiInputOnlyKeyTypes[3] = 'TEXT';
    rmiInputOnlyKeys[4] = 'Department1_dept_head_id_attribKey';
    rmiInputOnlyKeyTypes[4] = 'NUMBER';
    rmiInputOnlyKeys[5] = '_old.Department1.dept_head_id';
    rmiInputOnlyKeyTypes[5] = 'NUMBER';
    rmiInputOnlyKeys[6] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[6] = 'LIST';
    rmiInputOnlyKeys[7] = 'Department1_products_relationshipKey';
    rmiInputOnlyKeyTypes[7] = 'LIST';
    rmiInputOnlyKeys[8] = '_old.Department1.products.Department1_products_relationshipKey';
    rmiInputOnlyKeyTypes[8] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department1_delete_instance', 'Online Request', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department1_delete_instance', 'Online Request', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('Department1_delete_instance', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('Department1_delete_instance', 'Online Request', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Department1_delete_instance', 'Online Request');
}


function menuItemCallbackDepartment1_delete_instanceCancel() {
    if (!customBeforeMenuItemClick('Department1_delete_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department1_delete_instance', 'Cancel');
}


function menuItemCallbackDepartment1DetailSubmit() {
    if (!customBeforeMenuItemClick('Department1Detail', 'Submit')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'ErrorLogs';
    rmiKeyTypes[0] = 'LIST';
    rmiKeys[1] = 'Department1_dept_id_attribKey';
    rmiKeyTypes[1] = 'NUMBER';
    rmiKeys[2] = '_old.Department1.dept_id';
    rmiKeyTypes[2] = 'NUMBER';
    rmiKeys[3] = 'Department1_dept_name_attribKey';
    rmiKeyTypes[3] = 'TEXT';
    rmiKeys[4] = '_old.Department1.dept_name';
    rmiKeyTypes[4] = 'TEXT';
    rmiKeys[5] = 'Department1_dept_head_id_attribKey';
    rmiKeyTypes[5] = 'NUMBER';
    rmiKeys[6] = '_old.Department1.dept_head_id';
    rmiKeyTypes[6] = 'NUMBER';
    rmiKeys[7] = 'Department1_products_relationshipKey';
    rmiKeyTypes[7] = 'LIST';
    rmiKeys[8] = '_old.Department1.products.Department1_products_relationshipKey';
    rmiKeyTypes[8] = 'LIST';
    rmiInputOnlyKeys[0] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[0] = 'LIST';
    rmiInputOnlyKeys[1] = 'Department1_dept_id_attribKey';
    rmiInputOnlyKeyTypes[1] = 'NUMBER';
    rmiInputOnlyKeys[2] = '_old.Department1.dept_id';
    rmiInputOnlyKeyTypes[2] = 'NUMBER';
    rmiInputOnlyKeys[3] = 'Department1_dept_name_attribKey';
    rmiInputOnlyKeyTypes[3] = 'TEXT';
    rmiInputOnlyKeys[4] = '_old.Department1.dept_name';
    rmiInputOnlyKeyTypes[4] = 'TEXT';
    rmiInputOnlyKeys[5] = 'Department1_dept_head_id_attribKey';
    rmiInputOnlyKeyTypes[5] = 'NUMBER';
    rmiInputOnlyKeys[6] = '_old.Department1.dept_head_id';
    rmiInputOnlyKeyTypes[6] = 'NUMBER';
    rmiInputOnlyKeys[7] = 'Department1_products_relationshipKey';
    rmiInputOnlyKeyTypes[7] = 'LIST';
    rmiInputOnlyKeys[8] = '_old.Department1.products.Department1_products_relationshipKey';
    rmiInputOnlyKeyTypes[8] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department1Detail', 'Submit', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department1Detail', 'Submit', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('Department1Detail', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('Department1Detail', 'Submit', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Department1Detail', 'Submit');
}


function menuItemCallbackDepartment1DetailOpen_Product() {
    if (!customBeforeMenuItemClick('Department1Detail', 'Open Product')) {
        return;
    }
    navigateForward('Product');
    customAfterMenuItemClick('Department1Detail', 'Open Product');
}


function menuItemCallbackDepartment1DetailOpen_Department1_update_instance() {
    if (!customBeforeMenuItemClick('Department1Detail', 'Open Department1_update_instance')) {
        return;
    }
    navigateForward('Department1_update_instance');
    customAfterMenuItemClick('Department1Detail', 'Open Department1_update_instance');
}


function menuItemCallbackDepartment1DetailOpen_Department1_delete_instance() {
    if (!customBeforeMenuItemClick('Department1Detail', 'Open Department1_delete_instance')) {
        return;
    }
    navigateForward('Department1_delete_instance');
    customAfterMenuItemClick('Department1Detail', 'Open Department1_delete_instance');
}


function menuItemCallbackDepartment1DetailBack() {
    if (!customBeforeMenuItemClick('Department1Detail', 'Back')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('Department1Detail', 'Back');
}
function menuItemCallbackDepartment1DetailCancel() {
    if (!customBeforeMenuItemClick('Department1Detail', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department1Detail', 'Cancel');
}


function menuItemCallbackProductAdd() {
    if (!customBeforeMenuItemClick('Product', 'Add')) {
        return;
    }
    doCreateKeyCollectionAction("Product_add");
    customAfterMenuItemClick('Product', 'Add');
}


function menuItemCallbackProductBack() {
    if (!customBeforeMenuItemClick('Product', 'Back')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('Product', 'Back');
}
function menuItemCallbackProductCancel() {
    if (!customBeforeMenuItemClick('Product', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Product', 'Cancel');
}


function menuItemCallbackProduct_addAdd_Key_Collection() {
    if (!customBeforeMenuItemClick('Product_add', 'Add Key Collection')) {
        return;
    }
    doListviewAddRowAction('Department1_products_relationshipKey');
    customAfterMenuItemClick('Product_add', 'Add Key Collection');
}


function menuItemCallbackProduct_addCancel() {
    if (!customBeforeMenuItemClick('Product_add', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Product_add', 'Cancel');
}


function menuItemCallbackProduct_update_instanceUpdate_Key_Collection() {
    if (!customBeforeMenuItemClick('Product_update_instance', 'Update Key Collection')) {
        return;
    }
    doListviewUpdateRowAction("Department1_products_relationshipKey");
    customAfterMenuItemClick('Product_update_instance', 'Update Key Collection');
}


function menuItemCallbackProduct_update_instanceCancel() {
    if (!customBeforeMenuItemClick('Product_update_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Product_update_instance', 'Cancel');
}


function menuItemCallbackProductDetailOpen_Screen_Product_update_instance() {
    if (!customBeforeMenuItemClick('ProductDetail', 'Open Screen Product_update_instance')) {
        return;
    }
    navigateForward('Product_update_instance');
    customAfterMenuItemClick('ProductDetail', 'Open Screen Product_update_instance');
}


function menuItemCallbackProductDetailProduct_delete_instance() {
    if (!customBeforeMenuItemClick('ProductDetail', 'Product_delete_instance')) {
        return;
    }
    doListviewDeleteRowAction("Department1_products_relationshipKey");
    customAfterMenuItemClick('ProductDetail', 'Product_delete_instance');
}


function menuItemCallbackProductDetailBack() {
    if (!customBeforeMenuItemClick('ProductDetail', 'Back')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('ProductDetail', 'Back');
}
function menuItemCallbackProductDetailCancel() {
    if (!customBeforeMenuItemClick('ProductDetail', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('ProductDetail', 'Cancel');
}


function menuItemCallbackDepartment1Submit() {
    if (!customBeforeMenuItemClick('Department1', 'Submit')) {
        return;
    }

    if (saveScreens()) {
        doSubmitWorkflow('Department1', 'Submit', '', '');
    }
    customAfterMenuItemClick('Department1', 'Submit');
}


function menuItemCallbackDepartment1Cancel_Screen() {
    if (!customBeforeMenuItemClick('Department1', 'Cancel_Screen')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department1', 'Cancel_Screen');
}

function doAddRowAction() {
    var mvc = getCurrentMessageValueCollection();
    var listview = getListviewMessageValue();
    if (listview) {
        var childMVC = new MessageValueCollection();
        var key = guid();
        childMVC.setKey(key);
        childMVC.setState("new");
        childMVC.setParent(listview.getKey());
        childMVC.setParentValue(listview);
        listview.getValue().push(childMVC);
        console.log(workflowMessage.serializeToString());
        if (validateScreen(getCurrentScreen(), mvc)) {
            listViewValuesKey.pop();
            listViewValuesKey.push(childMVC.getKey());
            doListviewAddRowAction();
            console.log(workflowMessage.serializeToString());
        }
    }
}

function doCreateKeyCollectionAction(addScreen) {
    var mvc = getCurrentMessageValueCollection();
    var relationKey = getListViewKey(getCurrentScreen());
    var mv = mvc.getData(relationKey);
    var childMVC = new MessageValueCollection();
    var key = guid();
    childMVC.setKey(key);
    childMVC.setState("new");
    childMVC.setParent(mv.getKey());
    childMVC.setParentValue(mv);
    mv.getValue().push(childMVC);
    setDefaultValues(addScreen);
    // collect default values from the addScreen
    updateMessageValueCollectionFromUI(childMVC, addScreen);
    navigateForward(addScreen, key);
}

function doListviewAddRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (mvc.getState() === "new") {
        // this action is triggered after AddRow action
        if (validateScreen(getCurrentScreen(), mvc)) {
            mvc.setState("add");
            doSaveAction(false);
        }
    }
}

function doListviewUpdateRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("update");            
        }
        doSaveAction(false);
    }
}

function doListviewDeleteRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("delete");            
            doSaveAction(false);
        }
        else {
            var valuesArray = mvc.getParentValue().getValue();
            for (var i = 0; i < valuesArray.length; i++) {
                if (valuesArray[i] == mvc) {
                    valuesArray.splice(i, 1);
                }
            }
            navigateBack(true);
            updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        }        
    }
}

function doSaveActionWithoutReturn() {
   doSaveAction();
   return;
}

function doSaveAction(needValidation) {
    if (!getPreviousScreen()) {
        if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
            doSubmitWorkflow(getCurrentScreen(), "Save", '', '');
            return false;
        }
        return true;
    }
    if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
        navigateBack(false, false);
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        return true;
    }
    return false;
}

function doCancelAction() {
    if (!getPreviousScreen()) {
        closeWorkflow();
        return;
    }
    
    var mvc = getCurrentMessageValueCollection();
    navigateBack(true);
    var mvc1 = getCurrentMessageValueCollection();
    
    //if we are moving onto a listview screen we should delete any newly added rows
    if (mvc != mvc1) {
        //find the items of the listview and if any of them are marked as new, delete them.
        var messValues = mvc1.getValues();
        for (var i = 0; i < messValues.length; i++) {
            if (messValues[i].getType() === "LIST") {
                var listViewValuesArray = messValues[i].getValue()
                for (var j = 0; j < listViewValuesArray.length; j++) {
                    if (listViewValuesArray[j].getState() === "new") {
                        listViewValuesArray.splice(j, 1);
                        j--;
                    }
                }
            }        
        }
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
    }
    else if (mvc.getState() === "update") {
        mvc.setState("");
    }
}

function customNavigationEntry() {
    this.condition;
    this.screen;
}
function customNavigationEntry( a_condition, a_screen ) {
    this.condition = a_condition;
    this.screen = a_screen;
}

/**
 * For the specific pair - screen named 'currentScreenKey' and the action 'actionName', return
 * the list of custom navigation condition-names and their destination screens.
 */
function getCustomNavigations( currentScreenKey, actionName )  {
    var customNavigations = new Array();
    return customNavigations;
}
