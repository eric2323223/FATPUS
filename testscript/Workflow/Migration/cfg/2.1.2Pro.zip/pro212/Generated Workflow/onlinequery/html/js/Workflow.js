/*
 * Sybase Mobile Workflow version 2.1.2
 * 
 * Workflow.js
 * This file will be regenerated, so changes made herein will be removed the
 * next time the workflow is regenerated. It is therefore strongly recommended
 * that the user not make changes in this file.
 * 
 * The template used to create this file was compiled on Wed Jan 25 04:34:30 PST 2012
 *
 * Copyright (c) 2010, 2011 Sybase Inc. All rights reserved.
 */



function menuItemCallbackStart_ScreenCancel_Screen() {
    if (!customBeforeMenuItemClick('Start_Screen', 'Cancel_Screen')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Start_Screen', 'Cancel_Screen');
}


function menuItemCallbackStart_Screeninvoke() {
    if (!customBeforeMenuItemClick('Start_Screen', 'invoke')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'item';
    rmiKeyTypes[0] = 'NUMBER';
    rmiInputOnlyKeys[0] = 'item';
    rmiInputOnlyKeyTypes[0] = 'NUMBER';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Start_Screen', 'invoke', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Start_Screen', 'invoke', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('Start_Screen', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('Start_Screen', 'invoke', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Start_Screen', 'invoke');
}


function menuItemCallbackDepartmentOnline_update_instanceOnline_Request() {
    if (!customBeforeMenuItemClick('DepartmentOnline_update_instance', 'Online Request')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'DepartmentOnline_dept_name_attribKey';
    rmiKeyTypes[0] = 'TEXT';
    rmiKeys[1] = '_old.DepartmentOnline.dept_name';
    rmiKeyTypes[1] = 'TEXT';
    rmiKeys[2] = 'DepartmentOnline_dept_head_id_attribKey';
    rmiKeyTypes[2] = 'NUMBER';
    rmiKeys[3] = '_old.DepartmentOnline.dept_head_id';
    rmiKeyTypes[3] = 'NUMBER';
    rmiKeys[4] = 'DepartmentOnline_dept_id_attribKey';
    rmiKeyTypes[4] = 'NUMBER';
    rmiKeys[5] = '_old.DepartmentOnline.dept_id';
    rmiKeyTypes[5] = 'NUMBER';
    rmiKeys[6] = 'ErrorLogs';
    rmiKeyTypes[6] = 'LIST';
    rmiInputOnlyKeys[0] = 'DepartmentOnline_dept_name_attribKey';
    rmiInputOnlyKeyTypes[0] = 'TEXT';
    rmiInputOnlyKeys[1] = '_old.DepartmentOnline.dept_name';
    rmiInputOnlyKeyTypes[1] = 'TEXT';
    rmiInputOnlyKeys[2] = 'DepartmentOnline_dept_head_id_attribKey';
    rmiInputOnlyKeyTypes[2] = 'NUMBER';
    rmiInputOnlyKeys[3] = '_old.DepartmentOnline.dept_head_id';
    rmiInputOnlyKeyTypes[3] = 'NUMBER';
    rmiInputOnlyKeys[4] = 'DepartmentOnline_dept_id_attribKey';
    rmiInputOnlyKeyTypes[4] = 'NUMBER';
    rmiInputOnlyKeys[5] = '_old.DepartmentOnline.dept_id';
    rmiInputOnlyKeyTypes[5] = 'NUMBER';
    rmiInputOnlyKeys[6] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[6] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('DepartmentOnline_update_instance', 'Online Request', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('DepartmentOnline_update_instance', 'Online Request', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('DepartmentOnline_update_instance', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('DepartmentOnline_update_instance', 'Online Request', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('DepartmentOnline_update_instance', 'Online Request');
}


function menuItemCallbackDepartmentOnline_update_instanceCancel() {
    if (!customBeforeMenuItemClick('DepartmentOnline_update_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('DepartmentOnline_update_instance', 'Cancel');
}


function menuItemCallbackDepartmentOnline_delete_instanceOnline_Request() {
    if (!customBeforeMenuItemClick('DepartmentOnline_delete_instance', 'Online Request')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'DepartmentOnline_dept_id_attribKey';
    rmiKeyTypes[0] = 'NUMBER';
    rmiKeys[1] = '_old.DepartmentOnline.dept_id';
    rmiKeyTypes[1] = 'NUMBER';
    rmiKeys[2] = 'DepartmentOnline_dept_name_attribKey';
    rmiKeyTypes[2] = 'TEXT';
    rmiKeys[3] = '_old.DepartmentOnline.dept_name';
    rmiKeyTypes[3] = 'TEXT';
    rmiKeys[4] = 'DepartmentOnline_dept_head_id_attribKey';
    rmiKeyTypes[4] = 'NUMBER';
    rmiKeys[5] = '_old.DepartmentOnline.dept_head_id';
    rmiKeyTypes[5] = 'NUMBER';
    rmiKeys[6] = 'ErrorLogs';
    rmiKeyTypes[6] = 'LIST';
    rmiInputOnlyKeys[0] = 'DepartmentOnline_dept_id_attribKey';
    rmiInputOnlyKeyTypes[0] = 'NUMBER';
    rmiInputOnlyKeys[1] = '_old.DepartmentOnline.dept_id';
    rmiInputOnlyKeyTypes[1] = 'NUMBER';
    rmiInputOnlyKeys[2] = 'DepartmentOnline_dept_name_attribKey';
    rmiInputOnlyKeyTypes[2] = 'TEXT';
    rmiInputOnlyKeys[3] = '_old.DepartmentOnline.dept_name';
    rmiInputOnlyKeyTypes[3] = 'TEXT';
    rmiInputOnlyKeys[4] = 'DepartmentOnline_dept_head_id_attribKey';
    rmiInputOnlyKeyTypes[4] = 'NUMBER';
    rmiInputOnlyKeys[5] = '_old.DepartmentOnline.dept_head_id';
    rmiInputOnlyKeyTypes[5] = 'NUMBER';
    rmiInputOnlyKeys[6] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[6] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('DepartmentOnline_delete_instance', 'Online Request', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('DepartmentOnline_delete_instance', 'Online Request', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('DepartmentOnline_delete_instance', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('DepartmentOnline_delete_instance', 'Online Request', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('DepartmentOnline_delete_instance', 'Online Request');
}


function menuItemCallbackDepartmentOnline_delete_instanceCancel() {
    if (!customBeforeMenuItemClick('DepartmentOnline_delete_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('DepartmentOnline_delete_instance', 'Cancel');
}


function menuItemCallbackDepartmentOnlineDetailOpen_DepartmentOnline_update_instance() {
    if (!customBeforeMenuItemClick('DepartmentOnlineDetail', 'Open DepartmentOnline_update_instance')) {
        return;
    }
    navigateForward('DepartmentOnline_update_instance');
    customAfterMenuItemClick('DepartmentOnlineDetail', 'Open DepartmentOnline_update_instance');
}


function menuItemCallbackDepartmentOnlineDetailOpen_DepartmentOnline_delete_instance() {
    if (!customBeforeMenuItemClick('DepartmentOnlineDetail', 'Open DepartmentOnline_delete_instance')) {
        return;
    }
    navigateForward('DepartmentOnline_delete_instance');
    customAfterMenuItemClick('DepartmentOnlineDetail', 'Open DepartmentOnline_delete_instance');
}


function menuItemCallbackDepartmentOnlineDetailBack() {
    if (!customBeforeMenuItemClick('DepartmentOnlineDetail', 'Back')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('DepartmentOnlineDetail', 'Back');
}
function menuItemCallbackDepartmentOnlineDetailCancel() {
    if (!customBeforeMenuItemClick('DepartmentOnlineDetail', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('DepartmentOnlineDetail', 'Cancel');
}


function menuItemCallbackDepartmentOnlineSubmit() {
    if (!customBeforeMenuItemClick('DepartmentOnline', 'Submit')) {
        return;
    }

    if (saveScreens()) {
        doSubmitWorkflow('DepartmentOnline', 'Submit', '', '');
    }
    customAfterMenuItemClick('DepartmentOnline', 'Submit');
}


function menuItemCallbackDepartmentOnlineCancel_Screen() {
    if (!customBeforeMenuItemClick('DepartmentOnline', 'Cancel_Screen')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('DepartmentOnline', 'Cancel_Screen');
}

function doAddRowAction() {
    var mvc = getCurrentMessageValueCollection();
    var listview = getListviewMessageValue();
    if (listview) {
        var childMVC = new MessageValueCollection();
        var key = guid();
        childMVC.setKey(key);
        childMVC.setState("new");
        childMVC.setParent(listview.getKey());
        childMVC.setParentValue(listview);
        listview.getValue().push(childMVC);
        console.log(workflowMessage.serializeToString());
        if (validateScreen(getCurrentScreen(), mvc)) {
            listViewValuesKey.pop();
            listViewValuesKey.push(childMVC.getKey());
            doListviewAddRowAction();
            console.log(workflowMessage.serializeToString());
        }
    }
}

function doCreateKeyCollectionAction(addScreen) {
    var mvc = getCurrentMessageValueCollection();
    var relationKey = getListViewKey(getCurrentScreen());
    var mv = mvc.getData(relationKey);
    var childMVC = new MessageValueCollection();
    var key = guid();
    childMVC.setKey(key);
    childMVC.setState("new");
    childMVC.setParent(mv.getKey());
    childMVC.setParentValue(mv);
    mv.getValue().push(childMVC);
    setDefaultValues(addScreen);
    // collect default values from the addScreen
    updateMessageValueCollectionFromUI(childMVC, addScreen);
    navigateForward(addScreen, key);
}

function doListviewAddRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (mvc.getState() === "new") {
        // this action is triggered after AddRow action
        if (validateScreen(getCurrentScreen(), mvc)) {
            mvc.setState("add");
            doSaveAction(false);
        }
    }
}

function doListviewUpdateRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("update");            
        }
        doSaveAction(false);
    }
}

function doListviewDeleteRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("delete");            
            doSaveAction(false);
        }
        else {
            var valuesArray = mvc.getParentValue().getValue();
            for (var i = 0; i < valuesArray.length; i++) {
                if (valuesArray[i] == mvc) {
                    valuesArray.splice(i, 1);
                }
            }
            navigateBack(true);
            updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        }        
    }
}

function doSaveActionWithoutReturn() {
   doSaveAction();
   return;
}

function doSaveAction(needValidation) {
    if (!getPreviousScreen()) {
        if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
            doSubmitWorkflow(getCurrentScreen(), "Save", '', '');
            return false;
        }
        return true;
    }
    if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
        navigateBack(false, false);
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        return true;
    }
    return false;
}

function doCancelAction() {
    if (!getPreviousScreen()) {
        closeWorkflow();
        return;
    }
    
    var mvc = getCurrentMessageValueCollection();
    navigateBack(true);
    var mvc1 = getCurrentMessageValueCollection();
    
    //if we are moving onto a listview screen we should delete any newly added rows
    if (mvc != mvc1) {
        //find the items of the listview and if any of them are marked as new, delete them.
        var messValues = mvc1.getValues();
        for (var i = 0; i < messValues.length; i++) {
            if (messValues[i].getType() === "LIST") {
                var listViewValuesArray = messValues[i].getValue()
                for (var j = 0; j < listViewValuesArray.length; j++) {
                    if (listViewValuesArray[j].getState() === "new") {
                        listViewValuesArray.splice(j, 1);
                        j--;
                    }
                }
            }        
        }
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
    }
    else if (mvc.getState() === "update") {
        mvc.setState("");
    }
}

function customNavigationEntry() {
    this.condition;
    this.screen;
}
function customNavigationEntry( a_condition, a_screen ) {
    this.condition = a_condition;
    this.screen = a_screen;
}

/**
 * For the specific pair - screen named 'currentScreenKey' and the action 'actionName', return
 * the list of custom navigation condition-names and their destination screens.
 */
function getCustomNavigations( currentScreenKey, actionName )  {
    var customNavigations = new Array();
    return customNavigations;
}
