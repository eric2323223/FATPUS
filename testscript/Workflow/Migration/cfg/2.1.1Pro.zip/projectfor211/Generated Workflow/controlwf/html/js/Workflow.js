/*
 * Sybase Mobile Workflow version 2.1
 * 
 * Workflow.js
 * This file will be regenerated, so changes made herein will be removed the
 * next time the workflow is regenerated. It is therefore strongly recommended
 * that the user not make changes in this file.
 * 
 * The template used to create this file was compiled on Tue Sep 13 23:29:32 PDT 2011
 *
 * Copyright (c) 2010, 2011 Sybase Inc. All rights reserved.
 */



function menuItemCallbackAllMBODataType_update_instanceOnline_Request() {
    if (!customBeforeMenuItemClick('AllMBODataType_update_instance', 'Online Request')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'AllMBODataType_type_INT_attribKey';
    rmiKeyTypes[0] = 'NUMBER';
    rmiKeys[1] = '_old.AllMBODataType.type_INT';
    rmiKeyTypes[1] = 'NUMBER';
    rmiKeys[2] = 'AllMBODataType_type_LONG_attribKey';
    rmiKeyTypes[2] = 'NUMBER';
    rmiKeys[3] = '_old.AllMBODataType.type_LONG';
    rmiKeyTypes[3] = 'NUMBER';
    rmiKeys[4] = 'AllMBODataType_type_STRING_attribKey';
    rmiKeyTypes[4] = 'TEXT';
    rmiKeys[5] = '_old.AllMBODataType.type_STRING';
    rmiKeyTypes[5] = 'TEXT';
    rmiKeys[6] = 'AllMBODataType_type_DATE_attribKey';
    rmiKeyTypes[6] = 'DATETIME';
    rmiKeys[7] = '_old.AllMBODataType.type_DATE';
    rmiKeyTypes[7] = 'DATETIME';
    rmiKeys[8] = 'AllMBODataType_type_DATETIME_attribKey';
    rmiKeyTypes[8] = 'DATETIME';
    rmiKeys[9] = '_old.AllMBODataType.type_DATETIME';
    rmiKeyTypes[9] = 'DATETIME';
    rmiKeys[10] = 'AllMBODataType_type_TIME_attribKey';
    rmiKeyTypes[10] = 'DATETIME';
    rmiKeys[11] = '_old.AllMBODataType.type_TIME';
    rmiKeyTypes[11] = 'DATETIME';
    rmiKeys[12] = 'AllMBODataType_type_DECIMAL_attribKey';
    rmiKeyTypes[12] = 'NUMBER';
    rmiKeys[13] = '_old.AllMBODataType.type_DECIMAL';
    rmiKeyTypes[13] = 'NUMBER';
    rmiKeys[14] = 'AllMBODataType_type_FLOAT_attribKey';
    rmiKeyTypes[14] = 'NUMBER';
    rmiKeys[15] = '_old.AllMBODataType.type_FLOAT';
    rmiKeyTypes[15] = 'NUMBER';
    rmiKeys[16] = 'AllMBODataType_type_DOUBLE_attribKey';
    rmiKeyTypes[16] = 'NUMBER';
    rmiKeys[17] = '_old.AllMBODataType.type_DOUBLE';
    rmiKeyTypes[17] = 'NUMBER';
    rmiKeys[18] = 'AllMBODataType_type_BOOLEAN_attribKey';
    rmiKeyTypes[18] = 'BOOLEAN';
    rmiKeys[19] = '_old.AllMBODataType.type_BOOLEAN';
    rmiKeyTypes[19] = 'BOOLEAN';
    rmiKeys[20] = 'AllMBODataType_type_BINARY_attribKey';
    rmiKeyTypes[20] = 'TEXT';
    rmiKeys[21] = '_old.AllMBODataType.type_BINARY';
    rmiKeyTypes[21] = 'TEXT';
    rmiKeys[22] = 'AllMBODataType_type_multi_attribKey';
    rmiKeyTypes[22] = 'TEXT';
    rmiKeys[23] = '_old.AllMBODataType.type_multi';
    rmiKeyTypes[23] = 'TEXT';
    rmiKeys[24] = 'AllMBODataType_id_attribKey';
    rmiKeyTypes[24] = 'NUMBER';
    rmiKeys[25] = '_old.AllMBODataType.id';
    rmiKeyTypes[25] = 'NUMBER';
    rmiKeys[26] = 'ErrorLogs';
    rmiKeyTypes[26] = 'LIST';
    rmiInputOnlyKeys[0] = 'AllMBODataType_type_INT_attribKey';
    rmiInputOnlyKeyTypes[0] = 'NUMBER';
    rmiInputOnlyKeys[1] = '_old.AllMBODataType.type_INT';
    rmiInputOnlyKeyTypes[1] = 'NUMBER';
    rmiInputOnlyKeys[2] = 'AllMBODataType_type_LONG_attribKey';
    rmiInputOnlyKeyTypes[2] = 'NUMBER';
    rmiInputOnlyKeys[3] = '_old.AllMBODataType.type_LONG';
    rmiInputOnlyKeyTypes[3] = 'NUMBER';
    rmiInputOnlyKeys[4] = 'AllMBODataType_type_STRING_attribKey';
    rmiInputOnlyKeyTypes[4] = 'TEXT';
    rmiInputOnlyKeys[5] = '_old.AllMBODataType.type_STRING';
    rmiInputOnlyKeyTypes[5] = 'TEXT';
    rmiInputOnlyKeys[6] = 'AllMBODataType_type_DATE_attribKey';
    rmiInputOnlyKeyTypes[6] = 'DATETIME';
    rmiInputOnlyKeys[7] = '_old.AllMBODataType.type_DATE';
    rmiInputOnlyKeyTypes[7] = 'DATETIME';
    rmiInputOnlyKeys[8] = 'AllMBODataType_type_DATETIME_attribKey';
    rmiInputOnlyKeyTypes[8] = 'DATETIME';
    rmiInputOnlyKeys[9] = '_old.AllMBODataType.type_DATETIME';
    rmiInputOnlyKeyTypes[9] = 'DATETIME';
    rmiInputOnlyKeys[10] = 'AllMBODataType_type_TIME_attribKey';
    rmiInputOnlyKeyTypes[10] = 'DATETIME';
    rmiInputOnlyKeys[11] = '_old.AllMBODataType.type_TIME';
    rmiInputOnlyKeyTypes[11] = 'DATETIME';
    rmiInputOnlyKeys[12] = 'AllMBODataType_type_DECIMAL_attribKey';
    rmiInputOnlyKeyTypes[12] = 'NUMBER';
    rmiInputOnlyKeys[13] = '_old.AllMBODataType.type_DECIMAL';
    rmiInputOnlyKeyTypes[13] = 'NUMBER';
    rmiInputOnlyKeys[14] = 'AllMBODataType_type_FLOAT_attribKey';
    rmiInputOnlyKeyTypes[14] = 'NUMBER';
    rmiInputOnlyKeys[15] = '_old.AllMBODataType.type_FLOAT';
    rmiInputOnlyKeyTypes[15] = 'NUMBER';
    rmiInputOnlyKeys[16] = 'AllMBODataType_type_DOUBLE_attribKey';
    rmiInputOnlyKeyTypes[16] = 'NUMBER';
    rmiInputOnlyKeys[17] = '_old.AllMBODataType.type_DOUBLE';
    rmiInputOnlyKeyTypes[17] = 'NUMBER';
    rmiInputOnlyKeys[18] = 'AllMBODataType_type_BOOLEAN_attribKey';
    rmiInputOnlyKeyTypes[18] = 'BOOLEAN';
    rmiInputOnlyKeys[19] = '_old.AllMBODataType.type_BOOLEAN';
    rmiInputOnlyKeyTypes[19] = 'BOOLEAN';
    rmiInputOnlyKeys[20] = 'AllMBODataType_type_BINARY_attribKey';
    rmiInputOnlyKeyTypes[20] = 'TEXT';
    rmiInputOnlyKeys[21] = '_old.AllMBODataType.type_BINARY';
    rmiInputOnlyKeyTypes[21] = 'TEXT';
    rmiInputOnlyKeys[22] = 'AllMBODataType_type_multi_attribKey';
    rmiInputOnlyKeyTypes[22] = 'TEXT';
    rmiInputOnlyKeys[23] = '_old.AllMBODataType.type_multi';
    rmiInputOnlyKeyTypes[23] = 'TEXT';
    rmiInputOnlyKeys[24] = 'AllMBODataType_id_attribKey';
    rmiInputOnlyKeyTypes[24] = 'NUMBER';
    rmiInputOnlyKeys[25] = '_old.AllMBODataType.id';
    rmiInputOnlyKeyTypes[25] = 'NUMBER';
    rmiInputOnlyKeys[26] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[26] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('AllMBODataType_update_instance', 'Online Request', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('AllMBODataType_update_instance', 'Online Request', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('AllMBODataType_update_instance', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('AllMBODataType_update_instance', 'Online Request', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('AllMBODataType_update_instance', 'Online Request');
}


function menuItemCallbackAllMBODataType_update_instanceCancel() {
    if (!customBeforeMenuItemClick('AllMBODataType_update_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('AllMBODataType_update_instance', 'Cancel');
}


function menuItemCallbackAllMBODataType_update_instancebuttonid() {
    if (!customBeforeMenuItemClick('AllMBODataType_update_instance', 'buttonid')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('AllMBODataType_update_instance', 'buttonid');
}


function menuItemCallbackAllMBODataType_delete_instanceOnline_Request() {
    if (!customBeforeMenuItemClick('AllMBODataType_delete_instance', 'Online Request')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'AllMBODataType_id_attribKey';
    rmiKeyTypes[0] = 'NUMBER';
    rmiKeys[1] = '_old.AllMBODataType.id';
    rmiKeyTypes[1] = 'NUMBER';
    rmiKeys[2] = 'ErrorLogs';
    rmiKeyTypes[2] = 'LIST';
    rmiKeys[3] = 'AllMBODataType_type_INT_attribKey';
    rmiKeyTypes[3] = 'NUMBER';
    rmiKeys[4] = '_old.AllMBODataType.type_INT';
    rmiKeyTypes[4] = 'NUMBER';
    rmiKeys[5] = 'AllMBODataType_type_LONG_attribKey';
    rmiKeyTypes[5] = 'NUMBER';
    rmiKeys[6] = '_old.AllMBODataType.type_LONG';
    rmiKeyTypes[6] = 'NUMBER';
    rmiKeys[7] = 'AllMBODataType_type_STRING_attribKey';
    rmiKeyTypes[7] = 'TEXT';
    rmiKeys[8] = '_old.AllMBODataType.type_STRING';
    rmiKeyTypes[8] = 'TEXT';
    rmiKeys[9] = 'AllMBODataType_type_DATE_attribKey';
    rmiKeyTypes[9] = 'DATETIME';
    rmiKeys[10] = '_old.AllMBODataType.type_DATE';
    rmiKeyTypes[10] = 'DATETIME';
    rmiKeys[11] = 'AllMBODataType_type_DATETIME_attribKey';
    rmiKeyTypes[11] = 'DATETIME';
    rmiKeys[12] = '_old.AllMBODataType.type_DATETIME';
    rmiKeyTypes[12] = 'DATETIME';
    rmiKeys[13] = 'AllMBODataType_type_TIME_attribKey';
    rmiKeyTypes[13] = 'DATETIME';
    rmiKeys[14] = '_old.AllMBODataType.type_TIME';
    rmiKeyTypes[14] = 'DATETIME';
    rmiKeys[15] = 'AllMBODataType_type_DECIMAL_attribKey';
    rmiKeyTypes[15] = 'NUMBER';
    rmiKeys[16] = '_old.AllMBODataType.type_DECIMAL';
    rmiKeyTypes[16] = 'NUMBER';
    rmiKeys[17] = 'AllMBODataType_type_FLOAT_attribKey';
    rmiKeyTypes[17] = 'NUMBER';
    rmiKeys[18] = '_old.AllMBODataType.type_FLOAT';
    rmiKeyTypes[18] = 'NUMBER';
    rmiKeys[19] = 'AllMBODataType_type_DOUBLE_attribKey';
    rmiKeyTypes[19] = 'NUMBER';
    rmiKeys[20] = '_old.AllMBODataType.type_DOUBLE';
    rmiKeyTypes[20] = 'NUMBER';
    rmiKeys[21] = 'AllMBODataType_type_BOOLEAN_attribKey';
    rmiKeyTypes[21] = 'BOOLEAN';
    rmiKeys[22] = '_old.AllMBODataType.type_BOOLEAN';
    rmiKeyTypes[22] = 'BOOLEAN';
    rmiKeys[23] = 'AllMBODataType_type_BINARY_attribKey';
    rmiKeyTypes[23] = 'TEXT';
    rmiKeys[24] = '_old.AllMBODataType.type_BINARY';
    rmiKeyTypes[24] = 'TEXT';
    rmiKeys[25] = 'AllMBODataType_type_multi_attribKey';
    rmiKeyTypes[25] = 'TEXT';
    rmiKeys[26] = '_old.AllMBODataType.type_multi';
    rmiKeyTypes[26] = 'TEXT';
    rmiInputOnlyKeys[0] = 'AllMBODataType_id_attribKey';
    rmiInputOnlyKeyTypes[0] = 'NUMBER';
    rmiInputOnlyKeys[1] = '_old.AllMBODataType.id';
    rmiInputOnlyKeyTypes[1] = 'NUMBER';
    rmiInputOnlyKeys[2] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[2] = 'LIST';
    rmiInputOnlyKeys[3] = 'AllMBODataType_type_INT_attribKey';
    rmiInputOnlyKeyTypes[3] = 'NUMBER';
    rmiInputOnlyKeys[4] = '_old.AllMBODataType.type_INT';
    rmiInputOnlyKeyTypes[4] = 'NUMBER';
    rmiInputOnlyKeys[5] = 'AllMBODataType_type_LONG_attribKey';
    rmiInputOnlyKeyTypes[5] = 'NUMBER';
    rmiInputOnlyKeys[6] = '_old.AllMBODataType.type_LONG';
    rmiInputOnlyKeyTypes[6] = 'NUMBER';
    rmiInputOnlyKeys[7] = 'AllMBODataType_type_STRING_attribKey';
    rmiInputOnlyKeyTypes[7] = 'TEXT';
    rmiInputOnlyKeys[8] = '_old.AllMBODataType.type_STRING';
    rmiInputOnlyKeyTypes[8] = 'TEXT';
    rmiInputOnlyKeys[9] = 'AllMBODataType_type_DATE_attribKey';
    rmiInputOnlyKeyTypes[9] = 'DATETIME';
    rmiInputOnlyKeys[10] = '_old.AllMBODataType.type_DATE';
    rmiInputOnlyKeyTypes[10] = 'DATETIME';
    rmiInputOnlyKeys[11] = 'AllMBODataType_type_DATETIME_attribKey';
    rmiInputOnlyKeyTypes[11] = 'DATETIME';
    rmiInputOnlyKeys[12] = '_old.AllMBODataType.type_DATETIME';
    rmiInputOnlyKeyTypes[12] = 'DATETIME';
    rmiInputOnlyKeys[13] = 'AllMBODataType_type_TIME_attribKey';
    rmiInputOnlyKeyTypes[13] = 'DATETIME';
    rmiInputOnlyKeys[14] = '_old.AllMBODataType.type_TIME';
    rmiInputOnlyKeyTypes[14] = 'DATETIME';
    rmiInputOnlyKeys[15] = 'AllMBODataType_type_DECIMAL_attribKey';
    rmiInputOnlyKeyTypes[15] = 'NUMBER';
    rmiInputOnlyKeys[16] = '_old.AllMBODataType.type_DECIMAL';
    rmiInputOnlyKeyTypes[16] = 'NUMBER';
    rmiInputOnlyKeys[17] = 'AllMBODataType_type_FLOAT_attribKey';
    rmiInputOnlyKeyTypes[17] = 'NUMBER';
    rmiInputOnlyKeys[18] = '_old.AllMBODataType.type_FLOAT';
    rmiInputOnlyKeyTypes[18] = 'NUMBER';
    rmiInputOnlyKeys[19] = 'AllMBODataType_type_DOUBLE_attribKey';
    rmiInputOnlyKeyTypes[19] = 'NUMBER';
    rmiInputOnlyKeys[20] = '_old.AllMBODataType.type_DOUBLE';
    rmiInputOnlyKeyTypes[20] = 'NUMBER';
    rmiInputOnlyKeys[21] = 'AllMBODataType_type_BOOLEAN_attribKey';
    rmiInputOnlyKeyTypes[21] = 'BOOLEAN';
    rmiInputOnlyKeys[22] = '_old.AllMBODataType.type_BOOLEAN';
    rmiInputOnlyKeyTypes[22] = 'BOOLEAN';
    rmiInputOnlyKeys[23] = 'AllMBODataType_type_BINARY_attribKey';
    rmiInputOnlyKeyTypes[23] = 'TEXT';
    rmiInputOnlyKeys[24] = '_old.AllMBODataType.type_BINARY';
    rmiInputOnlyKeyTypes[24] = 'TEXT';
    rmiInputOnlyKeys[25] = 'AllMBODataType_type_multi_attribKey';
    rmiInputOnlyKeyTypes[25] = 'TEXT';
    rmiInputOnlyKeys[26] = '_old.AllMBODataType.type_multi';
    rmiInputOnlyKeyTypes[26] = 'TEXT';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('AllMBODataType_delete_instance', 'Online Request', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('AllMBODataType_delete_instance', 'Online Request', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('AllMBODataType_delete_instance', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('AllMBODataType_delete_instance', 'Online Request', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('AllMBODataType_delete_instance', 'Online Request');
}


function menuItemCallbackAllMBODataType_delete_instanceCancel() {
    if (!customBeforeMenuItemClick('AllMBODataType_delete_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('AllMBODataType_delete_instance', 'Cancel');
}


function menuItemCallbackAllMBODataTypeDetailOpen_AllMBODataType_update_instance() {
    if (!customBeforeMenuItemClick('AllMBODataTypeDetail', 'Open AllMBODataType_update_instance')) {
        return;
    }
    navigateForward('AllMBODataType_update_instance');
    customAfterMenuItemClick('AllMBODataTypeDetail', 'Open AllMBODataType_update_instance');
}


function menuItemCallbackAllMBODataTypeDetailOpen_AllMBODataType_delete_instance() {
    if (!customBeforeMenuItemClick('AllMBODataTypeDetail', 'Open AllMBODataType_delete_instance')) {
        return;
    }
    navigateForward('AllMBODataType_delete_instance');
    customAfterMenuItemClick('AllMBODataTypeDetail', 'Open AllMBODataType_delete_instance');
}


function menuItemCallbackAllMBODataTypeDetailBack() {
    if (!customBeforeMenuItemClick('AllMBODataTypeDetail', 'Back')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('AllMBODataTypeDetail', 'Back');
}
function menuItemCallbackAllMBODataTypeDetailCancel() {
    if (!customBeforeMenuItemClick('AllMBODataTypeDetail', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('AllMBODataTypeDetail', 'Cancel');
}


function menuItemCallbackAllMBODataTypeSubmit() {
    if (!customBeforeMenuItemClick('AllMBODataType', 'Submit')) {
        return;
    }

    if (saveScreens()) {
        doSubmitWorkflow('AllMBODataType', 'Submit', '', '');
    }
    customAfterMenuItemClick('AllMBODataType', 'Submit');
}


function menuItemCallbackAllMBODataTypeCancel_Screen() {
    if (!customBeforeMenuItemClick('AllMBODataType', 'Cancel Screen')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('AllMBODataType', 'Cancel Screen');
}

function doAddRowAction(addScreen) {
    var mvc = getCurrentMessageValueCollection();
    var relationKey = getListViewKey(getCurrentScreen());
    var mv = mvc.getData(relationKey);
    var childMVC = new MessageValueCollection();
    var key = guid();
    childMVC.setKey(key);
    childMVC.setState("new");
    childMVC.setParent(mv.getKey());
    childMVC.setParentValue(mv);
    mv.getValue().push(childMVC);
    setDefaultValues(addScreen);
    // collect default values from the addScreen
    updateMessageValueCollectionFromUI(childMVC, addScreen);
    navigateForward(addScreen, key);
}

function doListviewAddRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (mvc.getState() === "new") {
        // this action is triggered after AddRow action
        if (validateScreen(getCurrentScreen(), mvc)) {
            mvc.setState("add");
            doSaveAction(false);
        }
    }
}

function doListviewUpdateRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("update");            
        }
        doSaveAction(false);
    }
}

function doListviewDeleteRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("delete");            
            doSaveAction(false);
        }
        else {
            var valuesArray = mvc.getParentValue().getValue();
            for (var i = 0; i < valuesArray.length; i++) {
                if (valuesArray[i] == mvc) {
                    valuesArray.splice(i, 1);
                }
            }
            navigateBack(true);
            updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        }        
    }
}

function doSaveActionWithoutReturn() {
   doSaveAction();
   return;
}

function doSaveAction(needValidation) {
    if (!getPreviousScreen()) {
        if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
            doSubmitWorkflow(getCurrentScreen(), "Save", '', '');
            return false;
        }
        return true;
    }
    if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
        navigateBack(false);
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        return true;
    }
    return false;
}

function doCancelAction() {
    if (!getPreviousScreen()) {
        closeWorkflow();
        return;
    }
    var mvc = getCurrentMessageValueCollection();
    navigateBack(true);
    var mvc1 = getCurrentMessageValueCollection();
    if (mvc.getState() === "add" || mvc.getState() === "new") {
        mvc1.getData(mvc.getParent()).getValue().pop();
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
    } else if (mvc.getState() === "update") {
        mvc.setState("");
    }
}

function customNavigationEntry() {
    this.condition;
    this.screen;
}
function customNavigationEntry( a_condition, a_screen ) {
    this.condition = a_condition;
    this.screen = a_screen;
}

/**
 * For the specific pair - screen named 'currentScreenKey' and the action 'actionName', return
 * the list of custom navigation condition-names and their destination screens.
 */
function getCustomNavigations( currentScreenKey, actionName )  {
    var customNavigations = new Array();
    return customNavigations;
}
