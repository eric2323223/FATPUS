/*
 * Sybase Mobile Workflow version 2.0.0
 * 
 * Workflow.js
 * This file will be regenerated, so changes made herein will be removed the
 * next time the workflow is regenerated. It is therefore strongly recommended
 * that the user not make changes in this file.
 * 
 * Copyright (c) 2010 Sybase Inc. All rights reserved.
 */



function menuItemCallbackDepartment1_update_instanceOnline_Request() {
    if (!customBeforeMenuItemClick('Department1_update_instance', 'Online_Request')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'Department1_dept_name_attribKey';
    rmiKeyTypes[0] = 'TEXT';
    rmiKeys[1] = '_old.Department1.dept_name';
    rmiKeyTypes[1] = 'TEXT';
    rmiKeys[2] = 'Department1_dept_head_id_attribKey';
    rmiKeyTypes[2] = 'NUMBER';
    rmiKeys[3] = '_old.Department1.dept_head_id';
    rmiKeyTypes[3] = 'NUMBER';
    rmiKeys[4] = 'Department1_dept_id_attribKey';
    rmiKeyTypes[4] = 'NUMBER';
    rmiKeys[5] = '_old.Department1.dept_id';
    rmiKeyTypes[5] = 'NUMBER';
    rmiKeys[6] = 'ErrorLogs';
    rmiKeyTypes[6] = 'LIST';
    rmiKeys[7] = 'Department1_products_relationshipKey';
    rmiKeyTypes[7] = 'LIST';
    rmiKeys[8] = '_old.Department1.products.Department1_products_relationshipKey';
    rmiKeyTypes[8] = 'LIST';
    rmiInputOnlyKeys[0] = 'Department1_dept_name_attribKey';
    rmiInputOnlyKeyTypes[0] = 'TEXT';
    rmiInputOnlyKeys[1] = '_old.Department1.dept_name';
    rmiInputOnlyKeyTypes[1] = 'TEXT';
    rmiInputOnlyKeys[2] = 'Department1_dept_head_id_attribKey';
    rmiInputOnlyKeyTypes[2] = 'NUMBER';
    rmiInputOnlyKeys[3] = '_old.Department1.dept_head_id';
    rmiInputOnlyKeyTypes[3] = 'NUMBER';
    rmiInputOnlyKeys[4] = 'Department1_dept_id_attribKey';
    rmiInputOnlyKeyTypes[4] = 'NUMBER';
    rmiInputOnlyKeys[5] = '_old.Department1.dept_id';
    rmiInputOnlyKeyTypes[5] = 'NUMBER';
    rmiInputOnlyKeys[6] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[6] = 'LIST';
    rmiInputOnlyKeys[7] = 'Department1_products_relationshipKey';
    rmiInputOnlyKeyTypes[7] = 'LIST';
    rmiInputOnlyKeys[8] = '_old.Department1.products.Department1_products_relationshipKey';
    rmiInputOnlyKeyTypes[8] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department1_update_instance', 'Online_Request', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department1_update_instance', 'Online_Request', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (saveScreens(true)) {
        doOnlineRequest('Department1_update_instance', 'Online_Request', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Department1_update_instance', 'Online_Request');
}


function menuItemCallbackDepartment1_update_instanceCancel() {
    if (!customBeforeMenuItemClick('Department1_update_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department1_update_instance', 'Cancel');
}


function menuItemCallbackDepartment1_delete_instanceOnline_Request() {
    if (!customBeforeMenuItemClick('Department1_delete_instance', 'Online_Request')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'Department1_dept_id_attribKey';
    rmiKeyTypes[0] = 'NUMBER';
    rmiKeys[1] = '_old.Department1.dept_id';
    rmiKeyTypes[1] = 'NUMBER';
    rmiKeys[2] = 'ErrorLogs';
    rmiKeyTypes[2] = 'LIST';
    rmiKeys[3] = 'Department1_dept_name_attribKey';
    rmiKeyTypes[3] = 'TEXT';
    rmiKeys[4] = '_old.Department1.dept_name';
    rmiKeyTypes[4] = 'TEXT';
    rmiKeys[5] = 'Department1_dept_head_id_attribKey';
    rmiKeyTypes[5] = 'NUMBER';
    rmiKeys[6] = '_old.Department1.dept_head_id';
    rmiKeyTypes[6] = 'NUMBER';
    rmiKeys[7] = 'Department1_products_relationshipKey';
    rmiKeyTypes[7] = 'LIST';
    rmiKeys[8] = '_old.Department1.products.Department1_products_relationshipKey';
    rmiKeyTypes[8] = 'LIST';
    rmiInputOnlyKeys[0] = 'Department1_dept_id_attribKey';
    rmiInputOnlyKeyTypes[0] = 'NUMBER';
    rmiInputOnlyKeys[1] = '_old.Department1.dept_id';
    rmiInputOnlyKeyTypes[1] = 'NUMBER';
    rmiInputOnlyKeys[2] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[2] = 'LIST';
    rmiInputOnlyKeys[3] = 'Department1_dept_name_attribKey';
    rmiInputOnlyKeyTypes[3] = 'TEXT';
    rmiInputOnlyKeys[4] = '_old.Department1.dept_name';
    rmiInputOnlyKeyTypes[4] = 'TEXT';
    rmiInputOnlyKeys[5] = 'Department1_dept_head_id_attribKey';
    rmiInputOnlyKeyTypes[5] = 'NUMBER';
    rmiInputOnlyKeys[6] = '_old.Department1.dept_head_id';
    rmiInputOnlyKeyTypes[6] = 'NUMBER';
    rmiInputOnlyKeys[7] = 'Department1_products_relationshipKey';
    rmiInputOnlyKeyTypes[7] = 'LIST';
    rmiInputOnlyKeys[8] = '_old.Department1.products.Department1_products_relationshipKey';
    rmiInputOnlyKeyTypes[8] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department1_delete_instance', 'Online_Request', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department1_delete_instance', 'Online_Request', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (saveScreens(true)) {
        doOnlineRequest('Department1_delete_instance', 'Online_Request', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Department1_delete_instance', 'Online_Request');
}


function menuItemCallbackDepartment1_delete_instanceCancel() {
    if (!customBeforeMenuItemClick('Department1_delete_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department1_delete_instance', 'Cancel');
}


function menuItemCallbackDepartment1DetailSubmit() {
    if (!customBeforeMenuItemClick('Department1Detail', 'Submit')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'Department1_dept_id_attribKey';
    rmiKeyTypes[0] = 'NUMBER';
    rmiKeys[1] = '_old.Department1.dept_id';
    rmiKeyTypes[1] = 'NUMBER';
    rmiKeys[2] = 'Department1_dept_name_attribKey';
    rmiKeyTypes[2] = 'TEXT';
    rmiKeys[3] = '_old.Department1.dept_name';
    rmiKeyTypes[3] = 'TEXT';
    rmiKeys[4] = 'Department1_dept_head_id_attribKey';
    rmiKeyTypes[4] = 'NUMBER';
    rmiKeys[5] = '_old.Department1.dept_head_id';
    rmiKeyTypes[5] = 'NUMBER';
    rmiKeys[6] = 'Department1_products_relationshipKey';
    rmiKeyTypes[6] = 'LIST';
    rmiKeys[7] = '_old.Department1.products.Department1_products_relationshipKey';
    rmiKeyTypes[7] = 'LIST';
    rmiInputOnlyKeys[0] = 'Department1_dept_id_attribKey';
    rmiInputOnlyKeyTypes[0] = 'NUMBER';
    rmiInputOnlyKeys[1] = '_old.Department1.dept_id';
    rmiInputOnlyKeyTypes[1] = 'NUMBER';
    rmiInputOnlyKeys[2] = 'Department1_dept_name_attribKey';
    rmiInputOnlyKeyTypes[2] = 'TEXT';
    rmiInputOnlyKeys[3] = '_old.Department1.dept_name';
    rmiInputOnlyKeyTypes[3] = 'TEXT';
    rmiInputOnlyKeys[4] = 'Department1_dept_head_id_attribKey';
    rmiInputOnlyKeyTypes[4] = 'NUMBER';
    rmiInputOnlyKeys[5] = '_old.Department1.dept_head_id';
    rmiInputOnlyKeyTypes[5] = 'NUMBER';
    rmiInputOnlyKeys[6] = 'Department1_products_relationshipKey';
    rmiInputOnlyKeyTypes[6] = 'LIST';
    rmiInputOnlyKeys[7] = '_old.Department1.products.Department1_products_relationshipKey';
    rmiInputOnlyKeyTypes[7] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department1Detail', 'Submit', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department1Detail', 'Submit', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (saveScreens(true)) {
        doOnlineRequest('Department1Detail', 'Submit', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Department1Detail', 'Submit');
}


function menuItemCallbackDepartment1DetailOpen_Product() {
    if (!customBeforeMenuItemClick('Department1Detail', 'Open_Product')) {
        return;
    }
    navigateForward('Product');
    customAfterMenuItemClick('Department1Detail', 'Open_Product');
}


function menuItemCallbackDepartment1DetailOpen_Department1_update_instance() {
    if (!customBeforeMenuItemClick('Department1Detail', 'Open_Department1_update_instance')) {
        return;
    }
    navigateForward('Department1_update_instance');
    customAfterMenuItemClick('Department1Detail', 'Open_Department1_update_instance');
}


function menuItemCallbackDepartment1DetailOpen_Department1_delete_instance() {
    if (!customBeforeMenuItemClick('Department1Detail', 'Open_Department1_delete_instance')) {
        return;
    }
    navigateForward('Department1_delete_instance');
    customAfterMenuItemClick('Department1Detail', 'Open_Department1_delete_instance');
}


function menuItemCallbackDepartment1DetailBack() {
    if (!customBeforeMenuItemClick('Department1Detail', 'Back')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('Department1Detail', 'Back');
}
function menuItemCallbackDepartment1DetailCancel() {
   if (!customBeforeMenuItemClick('Department1Detail', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department1Detail', 'Cancel');
}


function menuItemCallbackProductAdd() {
    if (!customBeforeMenuItemClick('Product', 'Add')) {
        return;
    }
    doAddRowAction('Product_add');
    customAfterMenuItemClick('Product', 'Add');
}


function menuItemCallbackProductBack() {
    if (!customBeforeMenuItemClick('Product', 'Back')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('Product', 'Back');
}
function menuItemCallbackProductCancel() {
   if (!customBeforeMenuItemClick('Product', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Product', 'Cancel');
}


function menuItemCallbackProduct_addAdd_Key_Collection() {
    if (!customBeforeMenuItemClick('Product_add', 'Add_Key_Collection')) {
        return;
    }
    doListviewAddRowAction();
    customAfterMenuItemClick('Product_add', 'Add_Key_Collection');
}


function menuItemCallbackProduct_addCancel() {
    if (!customBeforeMenuItemClick('Product_add', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Product_add', 'Cancel');
}


function menuItemCallbackProduct_update_instanceUpdate_Key_Collection() {
    if (!customBeforeMenuItemClick('Product_update_instance', 'Update_Key_Collection')) {
        return;
    }
    doListviewUpdateRowAction();
    customAfterMenuItemClick('Product_update_instance', 'Update_Key_Collection');
}


function menuItemCallbackProduct_update_instanceCancel() {
    if (!customBeforeMenuItemClick('Product_update_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Product_update_instance', 'Cancel');
}


function menuItemCallbackProductDetailOpen_Screen_Product_update_instance() {
    if (!customBeforeMenuItemClick('ProductDetail', 'Open_Screen_Product_update_instance')) {
        return;
    }
    navigateForward('Product_update_instance');
    customAfterMenuItemClick('ProductDetail', 'Open_Screen_Product_update_instance');
}


function menuItemCallbackProductDetailProduct_delete_instance() {
    if (!customBeforeMenuItemClick('ProductDetail', 'Product_delete_instance')) {
        return;
    }
    doListviewDeleteRowAction();
    customAfterMenuItemClick('ProductDetail', 'Product_delete_instance');
}


function menuItemCallbackProductDetailBack() {
    if (!customBeforeMenuItemClick('ProductDetail', 'Back')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('ProductDetail', 'Back');
}
function menuItemCallbackProductDetailCancel() {
   if (!customBeforeMenuItemClick('ProductDetail', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('ProductDetail', 'Cancel');
}


function menuItemCallbackDepartment1Submit() {
    if (!customBeforeMenuItemClick('Department1', 'Submit')) {
        return;
    }

    if (saveScreens()) {
        doSubmitWorkflow('Department1', 'Submit', '', '');
    }
    customAfterMenuItemClick('Department1', 'Submit');
}


function menuItemCallbackDepartment1Cancel_Screen() {
    if (!customBeforeMenuItemClick('Department1', 'Cancel_Screen')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department1', 'Cancel_Screen');
}

function doAddRowAction(addScreen) {
    var mvc = getCurrentMessageValueCollection();
    var relationKey = getListViewKey(getCurrentScreen());
    var mv = mvc.getData(relationKey);
    var childMVC = new MessageValueCollection();
    var key = guid();
    childMVC.setKey(key);
    childMVC.setState("new");
    childMVC.setParent(mv.getKey());
    childMVC.setParentValue(mv);
    mv.getValue().push(childMVC);
    // collect default values from the addScreen
    updateMessageValueCollectionFromUI(childMVC, addScreen);
    navigateForward(addScreen, key);
}

function doListviewAddRowAction() {
    var mvc = getCurrentMessageValueCollection();
    if (mvc.getState() === "new") {
        // this action is triggered after AddRow action
        if (validateScreen(getCurrentScreen(), mvc)) {
            mvc.setState("add");
            doSaveAction(false);
        }
    }
}

function doListviewUpdateRowAction() {
    var mvc = getCurrentMessageValueCollection();
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("update");            
        }
        doSaveAction(false);
    }
}

function doListviewDeleteRowAction() {
    var mvc = getCurrentMessageValueCollection();
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("delete");            
            doSaveAction(false);
        }
        else {
            var valuesArray = mvc.getParentValue().getValue();
            for (var i = 0; i < valuesArray.length; i++) {
                if (valuesArray[i] == mvc) {
                    valuesArray.splice(i, 1);
                }
            }
            navigateBack(true);
            updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        }        
    }
}

function doSaveActionWithoutReturn() {
   doSaveAction();
   return;
}

function doSaveAction(needValidation) {
    if (!getPreviousScreen()) {
        if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
            doSubmitWorkflow(getCurrentScreen(), "Save", '', '');
            return false;
        }
        return true;
    }
    if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
        navigateBack(false);
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        return true;
    }
    return false;
}

function doCancelAction() {
    if (!getPreviousScreen()) {
        closeWorkflow();
        return;
    }
    var mvc = getCurrentMessageValueCollection();
    navigateBack(true);
    var mvc1 = getCurrentMessageValueCollection();
    if (mvc.getState() === "add") {
        mvc1.getData(mvc.getParent()).getValue().pop();
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
    } else if (mvc.getState() === "update") {
        mvc.setState("");
    }
}
