
Sybase.widget("sy.comboBox", {
	htmlValueChanged:function(newValue) {
		var options =  this.element.select[0].options;		
		for( var i = 0; i < options.length; i++ ) {
			if ( options[i].text ==  newValue ) {
				 this.element.select[0].selectedIndex = i;
				 this.element.selectBt[0].innerHTML = newValue;
				 break;
			}
		}
	},
    _init:function() {
        var self = this;
        self.isOpen = false;
        this.element.label =this.element.children('label')
        this.element.select =  this.element.children('select');
        this.element.select[0].style.display = 'none';
        var id = this.element.label[0].getAttribute('for');
        this.element.selectBt = Sybase('<div></div>');
        var sel = this.element.selectBt[0];
        if ( this.element.select[0].options != null && this.element.select[0].options.length > 0 
             && this.element.select[0].options[0].text != null ) {
            this.element.selectBt[0].innerHTML = this.element.select[0].options[0].text;
            this.element.selectBt.attr('id', id);
        }
        this.element.selectBt.attr('ignored', 'true');
        this.element.selectBt.attr('class',"input " + this.element.select[0].className);
        
        this.element.append( this.element.selectBt);
        this.element.selectBt.bind( 'click' , function() {
            if ( self.isOpen || self.element.select[0].getAttribute('disabled') ) return ;
              self.isOpen = self.openPopup();
        });
		var listener = createHTMLValueChangedListener(self, sel, self.htmlValueChanged);
		addHTMLValueChangedListener(listener);        
    },
    
    openPopup:function(){
        var self = this;
        self.divSelDlg = Sybase('<div class="valuepicker">');
        var origHeight = Sybase(self.element[0].parentNode).height();
        this.element.after(  self.divSelDlg );
        var width =  window.innerWidth - 40;
         self.divSelDlg.css('width',width  +'px');
        /* create titile section */
        self.createTitleSection();
        
        /* Add picker main section */
        self.createMainSection();
        return true;
    },
    
    closePopup:function(){
    	var self = this;
        self.element[0].parentNode.removeChild(Sybase('div.valuepicker')[0]);
        self.isOpen = false; 
    },
  
    createTitleSection:function() {
    	var self = this;
        var div = Sybase('<div class="valuePickerTile">');
        this.divSelDlg.append ( div );
        var icon = Sybase('<input type="text"  class="titleIcon" left" readonly value="" >');
        div.append( icon);
        var title = Sybase('<label class="title"></label>')
        
        title[0].innerHTML = this.element.label[0].innerHTML;
        div.append( title)
        div.bind( 'click' , function() {
            if ( self.isOpen ) 
              self.closePopup();
        });
    },
    
    createMainSection:function(){
         var self = this;
         var div = Sybase('<div class="mainSection">');
         this.divSelDlg.append( div);
         div.css('background','white');
         var selectChoices = "";
      
         var htmlP0 = '<div class="radiobutton"><label class="left">';
         var htmlP1 = '</label><input type="radio"  name="XXXX" /></div>'
         var html = "";
        
         var options =  this.element.select[0].options;
         for( var i = 0; i <  options.length; i++ ) {
             if (options[i].text==  this.element.selectBt[0].innerHTML ) {
                 html = html + htmlP0 + options[i].text + '</label><input type="radio" checked name="XXXX" /></div>';
             }else {
                 html = html + htmlP0 + options[i].text + htmlP1 ;
             } 
         }
     
         div[0].innerHTML = html;
     
         Sybase('div.radiobutton').radioBt({separatorLine:true,
                                            textColor:'black',
                                            onSelection: function( newValue)  { 
                                                 self.element.selectBt[0].innerHTML = newValue;
                                                 for( var i = 0; i < options.length; i++ ) {
                                                     if ( options[i].text ==  newValue ) {
                                                         self.element.select[0].selectedIndex = i;
                                                         break;
                                                     }
                                                  }
                                                 self.closePopup(); 
                                                }
                                            });
         var h = Sybase('div.radiobutton').length;
         h = h * 43 + 50 + 10;
         this.divSelDlg.css('height', h +'px');
         var mainH = h- 60;
         div.css('height', mainH +'px');
         div.css('width', self.divSelDlg.css('width'));
         
         self.calculatePosition(this.divSelDlg, h);
         
    },
    
    calculatePosition:function(dialog, height){
    	var topH = screen.height/2 - height/2 - 20;
    	if (topH < 0) topH = 5;
    	dialog.css('top', topH +'px');
    },

    options: {
        value:null,
        title: null,
        onDone:null
    }

});
