/*
 * Sybase Mobile Workflow version 2.0.0
 * 
 * WorkflowMessage.js
 * This file will not be regenerated, so it is possible to modify it, but it
 * is not recommended.
 * 
 * Copyright (c) 2010 Sybase Inc. All rights reserved.
 */

function MessageValue() { 
    this.key;
    this.value;
    this.type;
}

MessageValue.prototype.getKey = function() { return this.key; };
MessageValue.prototype.setKey = function(key) { this.key = key; };

MessageValue.prototype.getValue = function() { return this.value; };
MessageValue.prototype.setValue = function(value) { this.value = value; };

MessageValue.prototype.getType = function() { return this.type; };
MessageValue.prototype.setType = function(type) { this.type = type; };

function MessageValueCollection() {
    this.key;
    this.state;
    this.parent;
    this.parentValue;
    this.values;
    this.storage = {};
}

MessageValueCollection.prototype.getKey = function() { return this.key; };
MessageValueCollection.prototype.setKey = function(key) { this.key = key; };

// The valid values for the 'state' property are: "add", "delete", "new", "update", ""
MessageValueCollection.prototype.getState = function() { return this.state; };
MessageValueCollection.prototype.setState = function(state) { this.state = state; };

MessageValueCollection.prototype.getParent = function() { return this.parent; };
MessageValueCollection.prototype.setParent = function(parent) { this.parent = parent; };

MessageValueCollection.prototype.getParentValue = function() { return this.parentValue; };
MessageValueCollection.prototype.setParentValue = function(parentValue) { this.parentValue = parentValue; };

MessageValueCollection.prototype.add = function(key, value) { this.storage[key] = value; };
MessageValueCollection.prototype.clear = function() { this.storage = {}; };
MessageValueCollection.prototype.getData = function(key) { return this.storage[key]; };
MessageValueCollection.prototype.remove = function(key) { delete this.storage[key]; };

MessageValueCollection.prototype.getCount = function() {
    var numValues = 0;
    var property;
    for (property in this.storage) {
        if (this.storage.hasOwnProperty(property)) {
            numValues += 1;
        } 
    }
    return numValues;    
};

MessageValueCollection.prototype.getKeys = function() {
    var keysArray = [];
    var property;
    for (property in this.storage) {
        if (this.storage.hasOwnProperty(property)) {
            keysArray[keysArray.length] = property;
        }
    }
    return keysArray;       
};

MessageValueCollection.prototype.getValues = function() {
    var valuesArray = [];
    var property;
    for (property in this.storage) {
        if (this.storage.hasOwnProperty(property)) {
            valuesArray[valuesArray.length] = this.storage[property];
        }
    }
    return valuesArray;
};


function WorkflowMessage(messageAsString) {
    this.header;
    this.requestAction;
    this.values;
    this.workflowScreen;
    this.createFromString(messageAsString);
}

WorkflowMessage.prototype.getHeader = function() { return this.header ? this.header : ""; };
WorkflowMessage.prototype.setHeader = function(header) { this.header = header; };
WorkflowMessage.prototype.getRequestAction = function() { return this.requestAction ? this.requestAction : ""; };
WorkflowMessage.prototype.setRequestAction = function(requestAction) { this.requestAction = requestAction; };
WorkflowMessage.prototype.getValues = function() { return this.values; };
WorkflowMessage.prototype.getWorkflowScreen = function() { return this.workflowScreen ? this.workflowScreen : ""; };
WorkflowMessage.prototype.setWorkflowScreen = function(workflowScreen) { this.workflowScreen = workflowScreen; };

WorkflowMessage.prototype.createFromString = function(messageAsString) {
    var parser;
    var document;
    if (messageAsString === "")
    {
        messageAsString = "<XmlWidgetMessage></XmlWidgetMessage>";
    }
    if (window.DOMParser) {
        parser = new DOMParser();
        if (isBlackBerry()) {
            document = parser.parseFromString(messageAsString, "application/xhtml+xml");
        }
        else {
            document = parser.parseFromString(messageAsString, "text/xml");
        }
    }
    else if (window.ActiveXObject) {
        document = new ActiveXObject("Microsoft.XMLDOM");
        document.async="false";
        document.loadXML(messageAsString);
    }
    else {
        logToWorkflow("Error:  DOM parser not available", "ERROR");
        return;
    }
    var workflowMessage = document.firstChild;
    var headers = workflowMessage.getElementsByTagName("Header");
    var workflowScreens = workflowMessage.getElementsByTagName("WidgetScreen");
    var requestActions = workflowMessage.getElementsByTagName("RequestAction");
    var valuess = workflowMessage.getElementsByTagName("Values");
    if (headers && headers.length > 0 && headers.item(0).firstChild) {
        var header = headers.item(0);
        this.setHeader(header.firstChild.nodeValue.toString());
    }
    else {
        this.setHeader("");
    }
    
    if (workflowScreens && workflowScreens.length > 0 && workflowScreens.item(0).firstChild) {
        var workflowScreen = workflowScreens.item(0);
        this.setWorkflowScreen(workflowScreen.firstChild.nodeValue.toString());
    }
    else {
        this.setWorkflowScreen("");
    }
    if (valuess && valuess.length > 0 && valuess.item(0).firstChild) {
        var valuesChild = valuess.item(0);
        this.values = new MessageValueCollection();
        this.parseMessageValueCollection(valuesChild, this.values);
    }
    else {
        this.values = new MessageValueCollection();
    }
};

WorkflowMessage.prototype.parseMessageValueCollection = function(valuesNode, messageValueCollection) {
    var valueIdx;
    var numValues = valuesNode.childNodes.length;
    for (valueIdx = 0; valueIdx < numValues; valueIdx++) {
        var childItem = valuesNode.childNodes.item(valueIdx);
        if (childItem.nodeName === "Value") {
            var value = new MessageValue();
            value.setKey(childItem.getAttribute("key").toString());
            value.setType(childItem.getAttribute("type").toString());
            if (value.getType() === "LIST") {
                var numCollections = childItem.childNodes.length;
                var collections = new Array(numCollections);
                var collIdx;
                for (collIdx = 0; collIdx < numCollections; collIdx++) {
                    var collection = new MessageValueCollection();
                    var grandchildItem = childItem.childNodes.item(collIdx);
                    collection.setKey(grandchildItem.getAttribute("key"));
                    collection.setState(grandchildItem.getAttribute("state"));
                    collection.setParent(value.getKey());
                    collection.setParentValue(value);
                    this.parseMessageValueCollection(grandchildItem, collection);
                    collections[collIdx] = collection;
                }
                // value.value = serializeList(collections);
                value.value = collections;
            }
            else {
                var vNode;
                try {
                    var l = childItem.childNodes.length;
                    if (l) {
                        vNode = childItem.childNodes.item(0);
                        value.value = vNode.nodeValue.toString();
                    }
                    else {
                        value.value = "";
                    }
                }
                catch (e) {
                    showAlertDialog('Troubles parsing ' + vNode.nodeValue + " : " + e.message);
                }
            }
            messageValueCollection.add(value.getKey(), value);
        }
        else if (childItem.nodeName === "Values") {
            var valuesChild = new MessageValueCollection();
            valuesChild.setKey(childItem.getAttribute("key"));
            valuesChild.setState(childItem.getAttribute("state"));
            this.parseMessageValueCollection(childItem, valuesChild); 
            messageValueCollection.add(valuesChild.getKey(), valuesChild);
        }
    }    
};

WorkflowMessage.prototype.serializeToString = function() {
    var message = "<XmlWidgetMessage><Header>" + this.getHeader() + "</Header>";
    message += "<WidgetScreen>" + this.getWorkflowScreen() + "</WidgetScreen>";
    message += "<RequestAction>" + this.getRequestAction() + "</RequestAction>";
    message += "<Values>" + this.serializeValues(this.getValues(), "") + "</Values></XmlWidgetMessage>";
    return message;
};

WorkflowMessage.prototype.serializeValues = function(values, prefix) {
    var mess = "";
    var idx;
    var count = values.getCount();
    var keys = values.getKeys();
    for (idx = 0; idx < count; idx++) {
        var data = values.getData(keys[idx]);
        if (!isArray(data.getValue())) {
            mess += '<Value key="' + keys[idx] + '" type="' + data.getType() + '">' + escapeValue(data.getValue()) + '</Value>';
        }
        else {
            mess += '<Value key="' + keys[idx] + '" type="LIST">';
            var idx2;
            for (idx2 = 0; idx2 < data.getValue().length; idx2++) {
                mess += '<Values key="' + data.getValue()[idx2].getKey() +'" state="'+ data.getValue()[idx2].getState() + '">' +  this.serializeValues(data.getValue()[idx2], prefix + "." + data.getKey() + "[" + idx2 + "]") + '</Values>';
            }
            mess += '</Value>';
        }
    }
    return mess;
};

WorkflowMessage.prototype.updateValues = function(sourceValues, listViewValuesKey) {
	var values = this.values;
	if (listViewValuesKey) {
		var i;
		for (i = 0; i < listViewValuesKey.length; i++) {
			if (listViewValuesKey[i]) {
				values = narrowTo(values, listViewValuesKey[i]);
			}
		}
	}

    var count = sourceValues.getCount();
    var keys = sourceValues.getKeys();
    for (idx = 0; idx < count; idx++) {
        var oldData = values.getData(keys[idx]);
        if (oldData) {
            values.remove(oldData.getKey());
        }
        var newData = sourceValues.getData(keys[idx]);
        values.add(newData.getKey(), newData);
    }
};


function isArray(testObject) {
    return testObject && !(testObject.propertyIsEnumerable('length')) && typeof testObject === 'object' && typeof testObject.length === 'number';
}


function narrowTo(values, prefix) {
    //see if there is a value with a key == to prefix and return it
    var data = values.getData(prefix);
    if (data) {
        return data;
    }
    
    //if not, loop through any lists and recurse.
    var count = values.getCount();
    var keys = values.getKeys();
    var more = [];
    var valueIdx;
    for (valueIdx = 0; valueIdx < count; valueIdx++) {
        data = values.getData(keys[valueIdx]);
        if (isArray(data.value)) { //we have a list
            //does this list have a Values key that matches the prefix?
            var valuesIdx;
            var value;
            for (valuesIdx = 0; valuesIdx < data.value.length; valuesIdx++) { //for each values in a list
                value = data.value[valuesIdx];
                if (value.getKey() == prefix) {
                    return value;
                }
                // more indepth search may need to be done, but first let's finish search on the same level
                if (isArray(value)) {
                    more.push(value);
                }
            }
        }
    }
    var ret;
    var idx;
    for (idx = 0; idx < more.length; idx++) {
        ret = narrowTo(more[idx], prefix);
        if (ret) {
            return ret;
        }
    }
    return ret;
}