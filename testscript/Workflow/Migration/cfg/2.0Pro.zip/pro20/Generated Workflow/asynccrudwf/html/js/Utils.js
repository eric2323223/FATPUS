/*
 * Sybase Mobile Workflow version 2.0.0
 * 
 * Utils.js
 * This file will not be regenerated, so it is possible to modify it, but it
 * is not recommended.
 * 
 * Copyright (c) 2010 Sybase Inc. All rights reserved.
 */

//globals
curScreenKey = "";
supUserName = "";
previousScreenName = [];
listViewValuesKey = [];
workflowMessage = "";
lang = "";
resources = null;
logLevel = 1;
disableControls = false;  //used for mark as processed option

UIUpdateHandlers = [];
UIScreenListeners = [];
hasjQueryMobile = false;
isCustomLookAndFeel = false;
isJQueryMobileLookAndFeel = false;


function onWorkflowLoad() {
    requestID = 0;
    if (!(typeof jQuery === "undefined") &&  !(typeof jQuery.mobile === "undefined")) {
        hasjQueryMobile = true;
        isJQueryMobileLookAndFeel = true;
    }
    updateStyleSheetForiOS();
    updateForBB50WithTouchScreen();
    try {
        if (!customBeforeWorkflowLoad()) {
            return;
        }
        logLevel = getURLParam("loglevel");
        if (logLevel >= 4) { logToWorkflow("entering onWorkflowLoad()", "DEBUG", false); }
        
        if (! hasjQueryMobile ){
            hideAllDivs();
        }
        
        var screenNameToShow = getURLParam("screenToShow");
        supUserName = getURLParam("supusername");
        lang = getURLParam("lang");
        if (lang) {
            resources = new Resources(lang);
            if (!resources.hasLocale(lang)) {
                resources = null;
            }
        }
        disableControls = parseBoolean(getURLParam("isalreadyprocessed"));
        var loadTransformData = parseBoolean(getURLParam("loadtransformdata"));  //TODO revisit this once the bug for Sync Submit on a cred or act screen works.
        var ignoreTransformScreen = parseBoolean(getURLParam("ignoretransformscreen")); 
        logToWorkflow("URL " + window.location.href, "DEBUG", false);
        var response;
        if (loadTransformData && !ignoreTransformScreen) { //request the workflow message
            if (isWindowsMobile() || isWindows()) {
                var xmlhttp = getXMLHTTPRequest();
                if (isWindowsMobile()) {
                    xmlhttp.open("GET", "/sup.amp?querytype=loadtransformdata&version=2.0", false);
                }
                else {
                    xmlhttp.open("GET", "transform.xml", false);
                }
                xmlhttp.send("");
                if (xmlhttp.status === 200 || xmlhttp.status === 0) { //Win32 returns 200 for OK, WM returns 0 for OK
                    response = xmlhttp.responseText;
                    processWorkflowMessage(response);
                }
                else {
                    logToWorkflow("Error:  Unable to retrieve the message from the server", "ERROR", true);
                }
            }
            else { //must be BlackBerry or iOS
                var xmlhttp = getXMLHTTPRequest();
                xmlhttp.open("GET", "http://localhost/sup.amp?querytype=loadtransformdata&version=2.0", false);
                xmlhttp.send("");
                response = xmlhttp.responseText;
                processWorkflowMessage(response);
            }
        }//starting screen is the email starting screen
        else { //create an empty workflow message
            workflowMessage = new WorkflowMessage("");
            if (screenNameToShow === undefined) {
                showAlertDialog("Please specify a valid screen key via ?screentoshow=ScreenKeyName or ?loadtransformdata=true");
                return;
            }
            navigateForward(screenNameToShow, undefined);
        }
        
        //check if there is a user name credential
        if (supUserName) {
            var form = document.getElementById(screenNameToShow + "Form");
            if (form) {
                if (form.elements.length > 0) {
                    var i;
                    for (i = 0; i < form.elements.length; i++) {
                        var formEl = form.elements[i];
                        var credStr = getAttribute(formEl, "credential");
                        if (credStr) { // we are dealing with a username or password credential
                            if (credStr === "username") {
                                setHTMLValue(formEl, supUserName);
                            }
                        }
                    }
                }
            }
        }
        if (   hasjQueryMobile  ) {
            jqueryMobileOnPageLoad();
        }
    
        customAfterWorkflowLoad();
    }
    catch (excep) {
        logToWorkflow("Error: " + excep.message, "ERROR", true);
    }
    if (logLevel >= 4) { logToWorkflow("exiting onWorkflowLoad()", "DEBUG", false); }
}


function updateStyleSheetForiOS() {
    if (hasjQueryMobile) {
        return;
    }
    if (!isIOS()) {
        return;
    }
    var styleSheet = document.styleSheets[0];
    var ssRules = styleSheet.cssRules;
    var i;
    for (i = 0; i < ssRules.length; i++) {
        var selText = ssRules[i].selectorText.toLowerCase();
        if ((selText === "table.listview tr.evenrow:hover") || (selText === "table.listview tr.oddrow:hover")) {
            var hoverRule = ssRules[i];
            hoverRule.style.backgroundColor="";
            hoverRule.style.color="";
        }
    }
}

function updateForBB50WithTouchScreen() {
    if (isBlackBerry5WithTouchScreen()) {
         var i;
         for (i = 0; i < document.forms.length; i++) {
             var j;
             var formEl = document.forms[i];
             for (j = 0; j < document.forms[i].elements.length; j++) {
                 var formEl = document.forms[i].elements[j];
                 if ((formEl.type === "date") || (formEl.type === "datetime") || (formEl.type === "datetime-local") || (formEl.type === "time")) {
                     if (formEl.readOnly === true) {
                         formEl.type = "text";  //cr 661977
                     }
                 }
             }
         }
    }
}

function processWorkflowMessage(incomingWorkflowMessage) {
    if (logLevel >= 4) { logToWorkflow("entering processWorkflowMessage()", "DEBUG", false); }
    var dataSize = incomingWorkflowMessage.length;
    if (isWindowsMobile() && (incomingWorkflowMessage.length > 500000)) {
        var answer = confirm("Workflow messages larger than 500,000 bytes are unlikely to be successfully parsed on this device.  The message size is " + dataSize + ".  Do you wish to continue?");
        if (!answer) {
            return;
        }   
    }
    if ((incomingWorkflowMessage.indexOf("<XmlWidgetMessage>") === 0)
                || (incomingWorkflowMessage.indexOf("<XmlWorkflowMessage>") === 0)) {
        if (workflowMessage) { 
            var newWorkflowMessage = new WorkflowMessage(incomingWorkflowMessage);
            workflowMessage.setWorkflowScreen(newWorkflowMessage.getWorkflowScreen());
            workflowMessage.setHeader(newWorkflowMessage.getHeader());
            workflowMessage.updateValues(newWorkflowMessage.getValues(), listViewValuesKey);
        }
        else {
            workflowMessage = new WorkflowMessage(incomingWorkflowMessage);
        }
        var workFlowScreenToOpen = workflowMessage.getWorkflowScreen();
        if (workFlowScreenToOpen && workFlowScreenToOpen !== getCurrentScreen()) {
            navigateForward(workFlowScreenToOpen, undefined);
        }
        else {
            updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        }
    }
    else {  //it is an error message to be displayed
        showErrorFromNative(incomingWorkflowMessage); 
    }  
    if (logLevel >= 4) { logToWorkflow("exiting processWorkflowMessage()", "DEBUG", false); }
}


function hideAllDivs() {
    if (logLevel >= 4) { logToWorkflow("entering hideAllDivs()", "DEBUG", false); }
    var divs = document.getElementsByTagName('div');
    var i;
    for (i = 0; i < divs.length; i++) {
        var id =  getAttribute( divs[i], 'id');
        if (id !== null && id.lastIndexOf('ScreenDiv') > 0) { 
            divs[i].style.display = "none";
        }
    } 
    if (logLevel >= 4) { logToWorkflow("exiting hideAllDivs()", "DEBUG", false); }
}

function addNativeMenuItemsForScreen(screenToShow, subMenuName, okaction) {
    if (logLevel >= 4) { logToWorkflow("entering addNativeMenuItemsForScreen()", "DEBUG", false); }
    var divToShow = screenToShow + "ScreenDiv";
    var toShowEl = document.getElementById(divToShow);
    if (toShowEl) {
        if (isBlackBerry() || isWindowsMobile()) {
            var menuToHideEl = document.getElementById(divToShow + "Menu");
            if (menuToHideEl) {
                menuToHideEl.style.display = "none";
            }
            var menuItemNamesStr = getAttribute(toShowEl, "sup_menuitems");
            var hasMenuItems = false;
            if (menuItemNamesStr) {
                var menuItemNames = menuItemNamesStr.split(',');
                var menuStr = "{\"menuitems\":[";
                var i;                                
                for (i = 0; i < menuItemNames.length; i++) {
                    var menuItemName = menuItemNames[i++];
                    var menuItemKey = menuItemNames[i];
                    var methodName = convertToValidJavaScriptName('menuItemCallback' + screenToShow + menuItemKey);
                    if (i === 1) {  //first value will be the default value
                        menuStr = menuStr + "{\"name\":\"" + menuItemName + "\",\"action\":\"" + methodName + "()\",\"default\":\"true\"},";
                    }
                    else {
                        menuStr = menuStr + "{\"name\":\"" + menuItemName + "\",\"action\":\"" + methodName + "()\"},";
                    }
                }
                if (menuStr.length > 15) {
                    hasMenuItems = true;
                    menuStr = menuStr.substring(0, menuStr.length - 1);
                    menuStr = menuStr + "],\"lang\":\"" + lang + "\",\"submenuname\":\"";
                    if (subMenuName) {
                        menuStr = menuStr + subMenuName;
                    }
                    else {
                        if (resources) {
                            menuStr = menuStr + resources.getString("MENU");
                        }
                        else {
                            menuStr = menuStr + "Menu";
                        }
                    }
                    if (isWindowsMobile()) {
                        if (!okaction) {
                            okaction = getAttribute(toShowEl, "sup_okaction");
                        }
                        if (!okaction) {
                            okaction = "doSaveAction()";
                        }
                        menuStr = menuStr + "\",\"OK\":\"" + okaction;
                    }
                    menuStr = menuStr + "\"}";
                    var request = "http://localhost/sup.amp?querytype=addallmenuitems&version=2.0&menuitems=" + encodeURIComponent(menuStr);
                    if (isWindowsMobile()) {
                        var xmlhttp = getXMLHTTPRequest();
                        xmlhttp.open("POST", "/sup.amp?querytype=addallmenuitems&version=2.0", false);
                        xmlhttp.send("menuitems=" + encodeURIComponent(menuStr));
                    }
                    else {
                        var xmlhttp = getXMLHTTPRequest();
                        xmlhttp.open("POST", "http://localhost/sup.amp?querytype=addallmenuitems&version=2.0", true);
                        xmlhttp.send("menuitems=" + encodeURIComponent(menuStr));
                    }
                }
            }
            if (!hasMenuItems) {
                removeAllMenuItems();
            }
        }
    }
    if (logLevel >= 4) { logToWorkflow("exiting addNativeMenuItemsForScreen()", "DEBUG", false); }
}

function showScreen(screenToShow, screenToHide) {
    if (logLevel >= 4) { logToWorkflow("entering showScreen()", "DEBUG", false); }
        if (!customBeforeShowScreen(screenToShow, screenToHide)) {
        if (logLevel >= 4) { logToWorkflow("exiting showScreen()", "DEBUG", false); }
        return;
    }
    var divToShow = screenToShow + "ScreenDiv";
    var divToHide;
    if (screenToHide) {
        divToHide = screenToHide + "ScreenDiv";
    }
    var toShowEl = document.getElementById(divToShow);
    if (toShowEl) {
        var helpElem = document.getElementById(divToShow.substring(0, divToShow.length - 9) + "Form_help");
        if (helpElem) {
            setValidationText(helpElem, ""); //to remove any messages added by onCustomNavigate
        }
        
        if (! hasjQueryMobile ){
            toShowEl.style.display = "block";
            if ( toShowEl.offsetHeight < screen.height ) {
                toShowEl.style.height = screen.height +'px';
            }
        }
        
    }
    else {
        showAlertDialog("Please specify a valid screen to show via ?screenToShow=ScreenKeyName");
    }
    
    if (divToHide && ( ! hasjQueryMobile )) {
        document.getElementById(divToHide).style.display = "none";
    }
    document.title = divToShow.substring(0, divToShow.length - 9);
    var i;
    for (i = 0; i < UIScreenListeners.length; i++ ) {
        var listener = UIScreenListeners[ i];
        var obj  = {
            screenToShow : screenToShow,
            screenToHide : screenToHide
        };
        listener.call( this, obj );
    }
    if (!isIOS()) { //give focus to an element  //has no affect on an IOS device
        var form = document.getElementById(screenToShow + "Form");
        if (form) {
            var i;
            for (i = 0; i < form.elements.length; i++) {
                var formEl = form.elements[i];
                if (formEl.focus) {
                    formEl.focus();
                    break;
                }
            }
        }
    }
    customAfterShowScreen(screenToShow, screenToHide);

    if (logLevel >= 4) { logToWorkflow("exiting showScreen()", "DEBUG", false); }
}


function setDefaultValues(screenKey) {
    if (logLevel >= 4) { logToWorkflow("entering setDefaultValues()", "DEBUG", false); }
    //loop through the form elements of type date or datetime-local
    var form = document.getElementById(screenKey + "Form");
    if (form && (form.elements.length > 0)) {
        var i;
        for (i = 0; i < form.elements.length; i++) {
            var formEl = form.elements[i];
            var defaultValue = getAttribute(formEl, "defaultValue");
            var type = getAttribute(formEl, "sup_html_type");
            var valueToShow;
            if (defaultValue) {//if the element is a datetime-local and contains now or today in the defaultValue
                if (type === "date") {
                    var dateNowStr = getDateFromExpression(defaultValue);
                    defaultValue = getDateString(dateNowStr);
                    formEl.value = defaultValue;
                }
                else if (type === "datetime-local") {
                    var idxOfToday = defaultValue.indexOf("today");
                    if (idxOfToday === 0) {
                        var dateNowStr = getDateTimeToday(formEl, defaultValue);
                        formEl.value = dateNowStr;
                    }
                    var idxOfNow = defaultValue.indexOf("now");
                    if (idxOfNow === 0) {
                        var dateNowStr = getDateTimeNow(formEl, defaultValue);
                        formEl.value = dateNowStr;
                    }
                }
            } //if we have a defaultvalue
            else { //TODO CONFIRM THAT THE absence of a default value means to show current date and time
                if (type === "date") {
                    if (formEl.value === "") {
                        var dateNow = new Date();
                        valueToShow = getDateString(dateNow);
                        formEl.value = valueToShow;
                    }
                }
                if (type === "datetime-local") {
                    if (formEl.value === "") {  
                        var dateNow = new Date();
                        dateNow.setTime(dateNow.getTime() + (dateNow.getTimezoneOffset() * 60 * 1000));
                        valueToShow = getDateTimeStringToDisplay(dateNow, getAttribute(formEl, "sup_precision"));
                        formEl.value = valueToShow;
                    }
                }
                if (type === "range") {
                    var minValue = getAttribute(formEl, "min");
                    if (minValue) {
                       formEl.value = minValue; 
                    }
                }
            }
        } //elements in a form
    }
    if (logLevel >= 4) { logToWorkflow("exiting setDefaultValues()", "DEBUG", false); }
}


function getDateTimeToday(formEl, defaultValue) {
    var dateNow = new Date();
    dateNow.setHours(12);
    dateNow.setMinutes(0);
    dateNow.setSeconds(0);
    dateNow.setMilliseconds(0);
    if (defaultValue.length > 5) {
        var offset = defaultValue.substring(5);
        offset = offset.replace("+", "");
        var dateNowMS = dateNow.getTime();
        dateNowMS = dateNowMS + offset * 1000;
        dateNow.setTime(dateNowMS);
    }
    //now adjust to UTC
    dateNow.setTime(dateNow.getTime() + (dateNow.getTimezoneOffset() * 60 * 1000));
    var prec = "";
    if (formEl) {
        prec = getAttribute(formEl, "sup_precision");
    }
    defaultValue = getDateTimeStringToDisplay(dateNow, prec);
    return defaultValue;
}

function getDateTimeNow(formEl, defaultValue) {
    var dateNow = new Date();
    //now adjust to UTC
    dateNow.setTime(dateNow.getTime() + (dateNow.getTimezoneOffset() * 60 * 1000));
    return getDateTimeStringToDisplay(dateNow, getAttribute(formEl, "sup_precision"));
}


function addZero(value) {
    if (logLevel >= 4) { logToWorkflow("entering addZero()", "DEBUG", false); }
    value = value + "";
    var ret = (value.length === 1) ? "0" + value : value;
    if (logLevel >= 4) { logToWorkflow("exiting addZero()", "DEBUG", false); }
    return ret;
}


function addListViewHeader(linesStr) {
    var lines = linesStr.split("&?")[4].split("&;");
    var hdrHTML = "<thead>";
    var linesIdx;
    for (linesIdx = 0; linesIdx < lines.length; linesIdx++) {
        hdrHTML = hdrHTML + "<tr>";
        var lineDetails = lines[linesIdx];
        var fields = lineDetails.split("&,");
        var fieldIdx;
        for (fieldIdx = 0; fieldIdx < fields.length; fieldIdx = fieldIdx + 5) {
            var fieldHeaderTitle = fields[fieldIdx + 2];
            if (fieldHeaderTitle.length === 0) {
                continue;
            }
            var fieldHeaderWidth = fields[fieldIdx + 1];
            hdrHTML = hdrHTML + '<th align="left" colspan="'+ fieldHeaderWidth + '%">' + fieldHeaderTitle + '</th>';
        }
    }
    hdrHTML = hdrHTML + "</tr></thead>";
    return hdrHTML;
}


function addListViewItem(linesTxt, onClk, altRowColor, even, firstRow) {
    if (logLevel >= 4) { logToWorkflow("entering addListViewItem()", "DEBUG", false); }
    var trHTML = "";
    var i;
    for (i = 0; i < linesTxt.length; i++) {
        var fields = linesTxt[i];
        var className = "";
        var firstLine = (i === 0);
        var lastLine = (i === linesTxt.length - 1)
        if (firstRow) {
            if (firstLine && lastLine) {
                className = " class=\"firstAndLastLine\"";
            }
            else if (firstLine) {
                className = " class=\"firstLine\"";
            }
            else if (lastLine) {
                className = " class=\"lastLine\"";
            }
        }
        else if (lastLine) {
            className = " class=\"lastLine\"";
        }
        var altRow = " class=\"oddrow\"";
        var trStyle = "";
        if (even) {
            altRow = " class=\"evenrow\"";
            if (!document.styleSheets  || !document.styleSheets[0].addRule) { //Windows Mobile and BB 5 do not appear to support dynamically modifing the stylesheet
                if ((altRowColor !== "null") && (altRowColor.length > 0)) {
                    trStyle = " style=\"background: " + altRowColor + "\" ";
                }
            }
        }
        if (onClk && !isWindowsMobile()) {
            trHTML = trHTML + "<tr onclick=\"" + onClk + "\"" + altRow + trStyle + ">";
        }
        else {
            trHTML = trHTML + "<tr" + altRow + trStyle + ">";
        }
        var j;
        for (j = 0; j < fields.length; j++) {
            var field = fields[j];
            var font = field.font;
            var fontStart = "";
            var fontEnd = "";
            //if (isIOS()) {   // iphone automatically changes address, email, phone number to a link.  Adding no width space will prevent this but on some devices it appears as a square
                //field.value = '\u2060' + field.value;
            //}
            if (font === "Bold") { 
                fontStart = "<b>";
                fontEnd = "</b>";
            }
            else if (font === "Italic") {
                fontStart = "<i>";
                fontEnd = "</i>";
            }
            else if (font === "normal") {
                fontStart = "<plain>";
                fontEnd = "</plain>";
            }
            if (field.dataType === "DATE") {
                var strIdx = field.value.indexOf("T");
                if (strIdx !== -1) {
                    field.value = field.value.substr(0, strIdx);
                }
            }
            else if (field.dataType === "TIME") {
                var strIdx = field.value.indexOf("T");
                if (strIdx !== -1) {
                    field.value = field.value.substr(strIdx+1);
                }
            } else if (field.dataType === "DATETIME") {
                var aDate = new Date(parseDateTime(null, field.value));
                field.value = getDateTimeStringToDisplay(aDate);
            }
            if (isWindowsMobile()) {   //Windows mobile does not appear to support an onclick handler on the row ... so use an anchor
                if (onClk) {
                    trHTML = trHTML + "<td" + className + " colspan='" + field.width + "%'><a href=\"javascript:" + onClk + "\">" + fontStart + field.value + fontEnd + "</a></td>";
                }
                else {
                    trHTML = trHTML + "<td" + className + " colspan='" + field.width + "%'>" + field.value + "</td>";               
                }
            }
            else {
                trHTML = trHTML + "<td" + className + " colspan='" + field.width + "%'>" + fontStart + field.value + fontEnd + "</td>";
            }
        }
        trHTML = trHTML + "</tr>";
    }
    if (logLevel >= 4) { logToWorkflow("exiting addListViewItem()", "DEBUG", false); }
    return trHTML;
}

function delayedSetValue(screenKey, elemId, val) {
    if (logLevel >= 4) { logToWorkflow("entering delayedSetValue()", "DEBUG", false); }
    var form = document.getElementById(screenKey + "Form");
    var elem = getFormElementById(form, elemId);
    elem.value = val;
    if (logLevel >= 4) { logToWorkflow("exiting delayedSetValue()", "DEBUG", false); }
}


function getCredInfo() {
    if (logLevel >= 4) { logToWorkflow("entering getCredInfo()", "DEBUG", false); }
    var credInfo = "";
    if (curScreenKey) {
        var form = document.forms[curScreenKey + "Form"];
        if (form) {
            if (form.elements.length > 0) {
                var i;
                for (i = 0; i < form.elements.length; i++) {
                    var formEl = form.elements[i];
                    var credStr = getAttribute(formEl, "credential");
                    if (credStr) { // we are dealing with a username or password credential
                        if (credStr === "username") {
                            credInfo = "supusername=" + formEl.value + "&";
                            supUserName = formEl.value;
                        }
                        else if (credStr === "password") {
                            credInfo += "suppassword=" + formEl.value + "&";
                        }
                    }
                }
            }
        }
    }
    if (credInfo) {
        credInfo = credInfo + "version=2.0";
    }
    if (logLevel >= 4) { logToWorkflow("exiting getCredInfo()", "DEBUG", false); }
    return credInfo;
}


function handleCredentialChange() {
    if (logLevel >= 4) { logToWorkflow("entering handleCredentialChange()", "DEBUG", false); }
    //need to post credentials with each navigation if any
    var credInfo = getCredInfo();
    var requestData = credInfo ? credInfo : "";
    if (requestData) {    
        if (isWindowsMobile())  {
            var xmlhttp = getXMLHTTPRequest();
            xmlhttp.open("POST", "/sup.amp?querytype=formredirect&version=2.0", false);
            xmlhttp.send(requestData);
        }
        else if (!isWindows()) {
            var xmlhttp = getXMLHTTPRequest();
            xmlhttp.open("POST", "http://localhost/sup.amp?querytype=formredirect&version=2.0", true);
            xmlhttp.send(requestData);
        }
    }
    if (logLevel >= 4) { logToWorkflow("exiting handleCredentialChange()", "DEBUG", false); }
}

function windowOpen(sUrl) {
    if (logLevel >= 4) { logToWorkflow("entering windowOpen()", "DEBUG", false); }
    window.open(sUrl);
    if (logLevel >= 4) { logToWorkflow("exiting windowOpen()", "DEBUG", false); }
}

function showErrorFromNative(errMsg) {
    if (logLevel >= 4) { logToWorkflow("entering showErrorFromNative()", "DEBUG", false); }
    reportErrorFromNative(errMsg);
    if (logLevel >= 4) { logToWorkflow("exiting showErrorFromNative()", "DEBUG", false); }
}

function reportErrorFromNative(errString) {
    if (logLevel >= 4) { logToWorkflow("entering reportErrorFromNative()", "DEBUG", false); }
    var callbackMethod = getURLParamFromNativeError("onErrorCallback", errString);
    var errorCode = getURLParamFromNativeError("errCode", errString);
    var onErrorMsg = getURLParamFromNativeError("onErrorMsg", errString);
    var nativeMsg = getURLParamFromNativeError("nativeErrMsg", errString);
    if (callbackMethod) {
        window[callbackMethod].call(this, errorCode, onErrorMsg, nativeMsg); 
    }
    else if (onErrorMsg) {
        showAlertDialog(onErrorMsg);
    }
    else if (nativeMsg) {
        showAlertDialog(nativeMsg);
    }
    if (logLevel >= 4) { logToWorkflow("exiting reportErrorFromNative()", "DEBUG", false); }
}


function getURLParamFromNativeError(paramName, url) {
    if (logLevel >= 4) { logToWorkflow("entering getURLParamFromNativeError()", "DEBUG", false); }
    var indxofS, idxofE;
    var pName, pValue;
    var paramSection;
    var ret;

    paramSection = decodeURIComponent(url);
    var idxofA = paramSection.indexOf("&");
    if (idxofA > 0) {//there is one or more parameters in the & section
        var paramSectionsAmp = paramSection.substring(idxofA + 1);
        var ampSections = paramSection.split("&");
        if (ampSections.length === 1) {
            idxofE = paramSectionsAmp.indexOf("=");
            pName = paramSectionsAmp.substring(0, idxofE);
            if (pName.toLowerCase() === paramName.toLowerCase()) {
                pValue = paramSectionsAmp.substring(idxofE + 1);
                ret = decodeURIComponent( pValue);
                if (logLevel >= 4) { logToWorkflow("exiting getURLParamFromNativeError()", "DEBUG", false); }
                return ret;
            }
        }
        else {  //multiple parameters in the & section
            for (indxofS in ampSections) {
                idxofE = ampSections[indxofS].indexOf("=");
                pName = ampSections[indxofS].substring(0, idxofE);
                if (pName.toLowerCase() === paramName.toLowerCase()) {
                    pValue = ampSections[indxofS].substring(idxofE + 1);
                    ret = decodeURIComponent( pValue) ;
                    if (logLevel >= 4) { logToWorkflow("exiting getURLParamFromNativeError()", "DEBUG", false); }
                    return ret;
                }
            }
        }
        //ok did not find paramName in & section look for it at the start
        idxofE = paramSection.indexOf("=");
        pName = paramSection.substring(0, idxofE);
        if (pName.toLowerCase() === paramName.toLowerCase()) {
            pValue = paramSection.substring(idxofE + 1, idxofA);
            ret = decodeURIComponent( pValue );
            if (logLevel >= 4) { logToWorkflow("exiting getURLParamFromNativeError()", "DEBUG", false); }
            return ret;
        }
    }
    else { //only one param
        idxofE = paramSection.indexOf("=");
        pName = paramSection.substring(0, idxofE);
        if (pName.toLowerCase() === paramName.toLowerCase()) {
            pValue = paramSection.substring(idxofE + 1);
            ret = decodeURIComponent( pValue );
            if (logLevel >= 4) { logToWorkflow("exiting getURLParamFromNativeError()", "DEBUG", false); }
            return ret;
        }
    }
    if (logLevel >= 4) { logToWorkflow("exiting getURLParamFromNativeError()", "DEBUG", false); }
    return pValue;
}


function setSelectsSelectedIndex(select, aValue) {
    if (logLevel >= 4) { logToWorkflow("entering setSelectsSelectedIndex()", "DEBUG", false); }
    var i;
    for (i = 0; i < select.options.length; i++) {
        if (select.options[i].value === aValue) {
            select.selectedIndex = i;
        }
    }
    if (logLevel >= 4) { logToWorkflow("exiting setSelectsSelectedIndex()", "DEBUG", false); }
}


function reportRMIError(errorCode, onErrorMsg, nativeMsg) {
    if (onErrorMsg) {
        showAlertDialog(onErrorMsg);
    }
    else if (nativeMsg) {
        showAlertDialog(nativeMsg);
    }
}