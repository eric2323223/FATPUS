/*
 * Sybase Mobile Workflow version 2.0.0
 * 
 * Workflow.js
 * This file will be regenerated, so changes made herein will be removed the
 * next time the workflow is regenerated. It is therefore strongly recommended
 * that the user not make changes in this file.
 * 
 * Copyright (c) 2010 Sybase Inc. All rights reserved.
 */



function menuItemCallbackStart_ScreenCancel() {
    if (!customBeforeMenuItemClick('Start_Screen', 'Cancel')) {
        return;
    }
    closeWorkflow();
    customAfterMenuItemClick('Start_Screen', 'Cancel');
}


function menuItemCallbackStart_ScreenOpen_Department_create() {
    if (!customBeforeMenuItemClick('Start_Screen', 'Open_Department_create')) {
        return;
    }
    navigateForward('Department_create');
    customAfterMenuItemClick('Start_Screen', 'Open_Department_create');
}


function menuItemCallbackActivate_ScreenCancel() {
    if (!customBeforeMenuItemClick('Activate_Screen', 'Cancel')) {
        return;
    }
    closeWorkflow();
    customAfterMenuItemClick('Activate_Screen', 'Cancel');
}


function menuItemCallbackActivate_Screenactivate() {
    if (!customBeforeMenuItemClick('Activate_Screen', 'activate')) {
        return;
    }

    if (saveScreens()) {
        doSubmitWorkflow('Activate_Screen', 'activate', '', '');
    }
    customAfterMenuItemClick('Activate_Screen', 'activate');
}


function menuItemCallbackCredential_Request_ScreenSave_Screen() {
    if (!customBeforeMenuItemClick('Credential_Request_Screen', 'Save_Screen')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('Credential_Request_Screen', 'Save_Screen');
}
function menuItemCallbackCredential_Request_ScreenCancel() {
   if (!customBeforeMenuItemClick('Credential_Request_Screen', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Credential_Request_Screen', 'Cancel');
}


function menuItemCallbackDepartment_createSubmit_Workflow() {
    if (!customBeforeMenuItemClick('Department_create', 'Submit_Workflow')) {
        return;
    }

    if (saveScreens()) {
        doSubmitWorkflow('Department_create', 'Submit_Workflow', '', '');
    }
    customAfterMenuItemClick('Department_create', 'Submit_Workflow');
}


function menuItemCallbackDepartment_createCancel() {
    if (!customBeforeMenuItemClick('Department_create', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department_create', 'Cancel');
}

function doAddRowAction(addScreen) {
    var mvc = getCurrentMessageValueCollection();
    var relationKey = getListViewKey(getCurrentScreen());
    var mv = mvc.getData(relationKey);
    var childMVC = new MessageValueCollection();
    var key = guid();
    childMVC.setKey(key);
    childMVC.setState("new");
    childMVC.setParent(mv.getKey());
    childMVC.setParentValue(mv);
    mv.getValue().push(childMVC);
    // collect default values from the addScreen
    updateMessageValueCollectionFromUI(childMVC, addScreen);
    navigateForward(addScreen, key);
}

function doListviewAddRowAction() {
    var mvc = getCurrentMessageValueCollection();
    if (mvc.getState() === "new") {
        // this action is triggered after AddRow action
        if (validateScreen(getCurrentScreen(), mvc)) {
            mvc.setState("add");
            doSaveAction(false);
        }
    }
}

function doListviewUpdateRowAction() {
    var mvc = getCurrentMessageValueCollection();
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("update");            
        }
        doSaveAction(false);
    }
}

function doListviewDeleteRowAction() {
    var mvc = getCurrentMessageValueCollection();
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("delete");            
            doSaveAction(false);
        }
        else {
            var valuesArray = mvc.getParentValue().getValue();
            for (var i = 0; i < valuesArray.length; i++) {
                if (valuesArray[i] == mvc) {
                    valuesArray.splice(i, 1);
                }
            }
            navigateBack(true);
            updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        }        
    }
}

function doSaveActionWithoutReturn() {
   doSaveAction();
   return;
}

function doSaveAction(needValidation) {
    if (!getPreviousScreen()) {
        if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
            doSubmitWorkflow(getCurrentScreen(), "Save", '', '');
            return false;
        }
        return true;
    }
    if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
        navigateBack(false);
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        return true;
    }
    return false;
}

function doCancelAction() {
    if (!getPreviousScreen()) {
        closeWorkflow();
        return;
    }
    var mvc = getCurrentMessageValueCollection();
    navigateBack(true);
    var mvc1 = getCurrentMessageValueCollection();
    if (mvc.getState() === "add") {
        mvc1.getData(mvc.getParent()).getValue().pop();
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
    } else if (mvc.getState() === "update") {
        mvc.setState("");
    }
}
