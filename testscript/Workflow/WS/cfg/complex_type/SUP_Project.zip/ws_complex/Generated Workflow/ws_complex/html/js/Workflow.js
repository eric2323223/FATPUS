/*
 * Sybase Mobile Workflow version 2.0.0
 * 
 * Workflow.js
 * This file will be regenerated, so changes made herein will be removed the
 * next time the workflow is regenerated. It is therefore strongly recommended
 * that the user not make changes in this file.
 * 
 * Copyright (c) 2010 Sybase Inc. All rights reserved.
 */



function menuItemCallbackStart_ScreenCancel() {
    if (!customBeforeMenuItemClick('Start_Screen', 'Cancel')) {
        return;
    }
    closeWorkflow();
    customAfterMenuItemClick('Start_Screen', 'Cancel');
}


function menuItemCallbackStart_ScreenOpen_GetAllType_insertAllType() {
    if (!customBeforeMenuItemClick('Start_Screen', 'Open_GetAllType_insertAllType')) {
        return;
    }
    navigateForward('GetAllType_insertAllType');
    customAfterMenuItemClick('Start_Screen', 'Open_GetAllType_insertAllType');
}


function menuItemCallbackStart_ScreengetAll() {
    if (!customBeforeMenuItemClick('Start_Screen', 'getAll')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Start_Screen', 'getAll', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Start_Screen', 'getAll', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    doOnlineRequest('Start_Screen', 'getAll', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    customAfterMenuItemClick('Start_Screen', 'getAll');
}


function menuItemCallbackGetAllType_insertAllTypeOnline_Request() {
    if (!customBeforeMenuItemClick('GetAllType_insertAllType', 'Online_Request')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'alltype_IntType_attribKey';
    rmiKeyTypes[0] = 'NUMBER';
    rmiKeys[1] = 'alltype_StringType_attribKey';
    rmiKeyTypes[1] = 'TEXT';
    rmiKeys[2] = 'alltype_BooleanType_attribKey';
    rmiKeyTypes[2] = 'BOOLEAN';
    rmiKeys[3] = 'alltype_DecimalType_attribKey';
    rmiKeyTypes[3] = 'NUMBER';
    rmiKeys[4] = 'alltype_FloatType_attribKey';
    rmiKeyTypes[4] = 'NUMBER';
    rmiKeys[5] = 'alltype_DoubleType_attribKey';
    rmiKeyTypes[5] = 'NUMBER';
    rmiKeys[6] = 'alltype_DateTimeType_attribKey';
    rmiKeyTypes[6] = 'DATETIME';
    rmiKeys[7] = 'alltype_TimeType_attribKey';
    rmiKeyTypes[7] = 'DATETIME';
    rmiKeys[8] = 'alltype_DateType_attribKey';
    rmiKeyTypes[8] = 'DATETIME';
    rmiKeys[9] = 'alltype_HexBinaryType_attribKey';
    rmiKeyTypes[9] = 'TEXT';
    rmiKeys[10] = 'alltype_Base64BinaryType_attribKey';
    rmiKeyTypes[10] = 'TEXT';
    rmiKeys[11] = 'alltype_AnyURIType_attribKey';
    rmiKeyTypes[11] = 'TEXT';
    rmiKeys[12] = 'alltype_QNameType_attribKey';
    rmiKeyTypes[12] = 'TEXT';
    rmiKeys[13] = 'alltype_AnyTypeType_attribKey';
    rmiKeyTypes[13] = 'TEXT';
    rmiKeys[14] = 'ErrorLogs';
    rmiKeyTypes[14] = 'LIST';
    rmiInputOnlyKeys[0] = 'alltype_IntType_attribKey';
    rmiInputOnlyKeyTypes[0] = 'NUMBER';
    rmiInputOnlyKeys[1] = 'alltype_StringType_attribKey';
    rmiInputOnlyKeyTypes[1] = 'TEXT';
    rmiInputOnlyKeys[2] = 'alltype_BooleanType_attribKey';
    rmiInputOnlyKeyTypes[2] = 'BOOLEAN';
    rmiInputOnlyKeys[3] = 'alltype_DecimalType_attribKey';
    rmiInputOnlyKeyTypes[3] = 'NUMBER';
    rmiInputOnlyKeys[4] = 'alltype_FloatType_attribKey';
    rmiInputOnlyKeyTypes[4] = 'NUMBER';
    rmiInputOnlyKeys[5] = 'alltype_DoubleType_attribKey';
    rmiInputOnlyKeyTypes[5] = 'NUMBER';
    rmiInputOnlyKeys[6] = 'alltype_DateTimeType_attribKey';
    rmiInputOnlyKeyTypes[6] = 'DATETIME';
    rmiInputOnlyKeys[7] = 'alltype_TimeType_attribKey';
    rmiInputOnlyKeyTypes[7] = 'DATETIME';
    rmiInputOnlyKeys[8] = 'alltype_DateType_attribKey';
    rmiInputOnlyKeyTypes[8] = 'DATETIME';
    rmiInputOnlyKeys[9] = 'alltype_HexBinaryType_attribKey';
    rmiInputOnlyKeyTypes[9] = 'TEXT';
    rmiInputOnlyKeys[10] = 'alltype_Base64BinaryType_attribKey';
    rmiInputOnlyKeyTypes[10] = 'TEXT';
    rmiInputOnlyKeys[11] = 'alltype_AnyURIType_attribKey';
    rmiInputOnlyKeyTypes[11] = 'TEXT';
    rmiInputOnlyKeys[12] = 'alltype_QNameType_attribKey';
    rmiInputOnlyKeyTypes[12] = 'TEXT';
    rmiInputOnlyKeys[13] = 'alltype_AnyTypeType_attribKey';
    rmiInputOnlyKeyTypes[13] = 'TEXT';
    rmiInputOnlyKeys[14] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[14] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('GetAllType_insertAllType', 'Online_Request', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('GetAllType_insertAllType', 'Online_Request', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    doOnlineRequest('GetAllType_insertAllType', 'Online_Request', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    customAfterMenuItemClick('GetAllType_insertAllType', 'Online_Request');
}


function menuItemCallbackGetAllType_insertAllTypeCancel() {
    if (!customBeforeMenuItemClick('GetAllType_insertAllType', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('GetAllType_insertAllType', 'Cancel');
}


function menuItemCallbackGetAllTypeDetailBack() {
    if (!customBeforeMenuItemClick('GetAllTypeDetail', 'Back')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('GetAllTypeDetail', 'Back');
}
function menuItemCallbackGetAllTypeDetailCancel() {
   if (!customBeforeMenuItemClick('GetAllTypeDetail', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('GetAllTypeDetail', 'Cancel');
}


function menuItemCallbackGetAllTypeSubmit() {
    if (!customBeforeMenuItemClick('GetAllType', 'Submit')) {
        return;
    }

    if (saveScreens()) {
        doSubmitWorkflow('GetAllType', 'Submit', '', '');
    }
    customAfterMenuItemClick('GetAllType', 'Submit');
}


function menuItemCallbackGetAllTypeCancel_Screen() {
    if (!customBeforeMenuItemClick('GetAllType', 'Cancel_Screen')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('GetAllType', 'Cancel_Screen');
}

function doAddRowAction(addScreen) {
    var mvc = getCurrentMessageValueCollection();
    var relationKey = getListViewKey(getCurrentScreen());
    var mv = mvc.getData(relationKey);
    var childMVC = new MessageValueCollection();
    var key = guid();
    childMVC.setKey(key);
    childMVC.setState("new");
    childMVC.setParent(mv.getKey());
    mv.getValue().push(childMVC);
    // collect default values from the addScreen
    updateMessageValueCollectionFromUI(childMVC, addScreen);
    navigateForward(addScreen, key);
}

function doListviewAddRowAction() {
    var mvc = getCurrentMessageValueCollection();
    if (mvc.getState() === "new") {
        // this action is triggered after AddRow action
        if (validateScreen(getCurrentScreen(), mvc)) {
            mvc.setState("add");
            doSaveAction(false);
        }
    }
}

function doListviewUpdateRowAction() {
    var mvc = getCurrentMessageValueCollection();
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("update");            
        }
        doSaveAction(false);
    }
}

function doListviewDeleteRowAction() {
    var mvc = getCurrentMessageValueCollection();
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("delete");            
        }
        doSaveAction(false);
    }
}

function doSaveActionWithoutReturn() {
   doSaveAction();
   return;
}

function doSaveAction(needValidation) {
    if (!getPreviousScreen()) {
        if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
            doSubmitWorkflow(getCurrentScreen(), "Save", '', '');
            return false;
        }
        return true;
    }
    if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
        navigateBack(false);
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        return true;
    }
    return false;
}

function doCancelAction() {
    if (!getPreviousScreen()) {
        closeWorkflow();
        return;
    }
    var mvc = getCurrentMessageValueCollection();
    navigateBack(true);
    var mvc1 = getCurrentMessageValueCollection();
    if (mvc.getState() === "add") {
        mvc1.getData(mvc.getParent()).getValue().pop();
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
    } else if (mvc.getState() === "update") {
        mvc.setState("");
    }
}
