/*
 * Sybase Mobile Workflow version 2.1
 * 
 * Workflow.js
 * This file will be regenerated, so changes made herein will be removed the
 * next time the workflow is regenerated. It is therefore strongly recommended
 * that the user not make changes in this file.
 * 
 * The template used to create this file was compiled on Mon Aug 29 16:54:18 PDT 2011
 *
 * Copyright (c) 2010, 2011 Sybase Inc. All rights reserved.
 */



function menuItemCallbackStart_ScreenCancel_Screen() {
    if (!customBeforeMenuItemClick('Start_Screen', 'Cancel Screen')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Start_Screen', 'Cancel Screen');
}


function menuItemCallbackStart_ScreenOpen_Sort1Object_sort() {
    if (!customBeforeMenuItemClick('Start_Screen', 'Open Sort1Object_sort')) {
        return;
    }
    navigateForward('Sort1Object_sort');
    customAfterMenuItemClick('Start_Screen', 'Open Sort1Object_sort');
}


function menuItemCallbackSort1Object_sortSubmit_Workflow() {
    if (!customBeforeMenuItemClick('Sort1Object_sort', 'Submit Workflow')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'Sort1Object_sort_arg0_paramKey';
    rmiKeyTypes[0] = 'LIST';
    rmiKeys[1] = 'ErrorLogs';
    rmiKeyTypes[1] = 'LIST';
    rmiInputOnlyKeys[0] = 'Sort1Object_sort_arg0_paramKey';
    rmiInputOnlyKeyTypes[0] = 'LIST';
    rmiInputOnlyKeys[1] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[1] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Sort1Object_sort', 'Submit Workflow', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Sort1Object_sort', 'Submit Workflow', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('Sort1Object_sort', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('Sort1Object_sort', 'Submit Workflow', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Sort1Object_sort', 'Submit Workflow');
}


function menuItemCallbackSort1Object_sortSpecify_arg0() {
    if (!customBeforeMenuItemClick('Sort1Object_sort', 'Specify arg0')) {
        return;
    }
    navigateForward('arg0');
    customAfterMenuItemClick('Sort1Object_sort', 'Specify arg0');
}


function menuItemCallbackSort1Object_sortCancel() {
    if (!customBeforeMenuItemClick('Sort1Object_sort', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Sort1Object_sort', 'Cancel');
}


function menuItemCallbackarg0Add() {
    if (!customBeforeMenuItemClick('arg0', 'Add')) {
        return;
    }
    doAddRowAction('arg0_add');
    customAfterMenuItemClick('arg0', 'Add');
}


function menuItemCallbackarg0Save_Screen() {
    if (!customBeforeMenuItemClick('arg0', 'Save Screen')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('arg0', 'Save Screen');
}


function menuItemCallbackarg0Cancel_Screen() {
    if (!customBeforeMenuItemClick('arg0', 'Cancel Screen')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('arg0', 'Cancel Screen');
}


function menuItemCallbackarg0_addCreate() {
    if (!customBeforeMenuItemClick('arg0_add', 'Create')) {
        return;
    }
    doListviewAddRowAction("Sort1Object_sort_arg0_paramKey");
    customAfterMenuItemClick('arg0_add', 'Create');
}


function menuItemCallbackarg0_addCancel() {
    if (!customBeforeMenuItemClick('arg0_add', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('arg0_add', 'Cancel');
}


function menuItemCallbackarg0DetailDelete() {
    if (!customBeforeMenuItemClick('arg0Detail', 'Delete')) {
        return;
    }
    doListviewDeleteRowAction("Sort1Object_sort_arg0_paramKey");
    customAfterMenuItemClick('arg0Detail', 'Delete');
}


function menuItemCallbackarg0DetailOpen_arg0_update_instance() {
    if (!customBeforeMenuItemClick('arg0Detail', 'Open arg0_update_instance')) {
        return;
    }
    navigateForward('arg0_update_instance');
    customAfterMenuItemClick('arg0Detail', 'Open arg0_update_instance');
}


function menuItemCallbackarg0DetailBack() {
    if (!customBeforeMenuItemClick('arg0Detail', 'Back')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('arg0Detail', 'Back');
}


function menuItemCallbackarg0DetailCancel() {
    if (!customBeforeMenuItemClick('arg0Detail', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('arg0Detail', 'Cancel');
}


function menuItemCallbackarg0_update_instanceUpdate() {
    if (!customBeforeMenuItemClick('arg0_update_instance', 'Update')) {
        return;
    }
    doListviewUpdateRowAction("Sort1Object_sort_arg0_paramKey");
    customAfterMenuItemClick('arg0_update_instance', 'Update');
}


function menuItemCallbackarg0_update_instanceCancel() {
    if (!customBeforeMenuItemClick('arg0_update_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('arg0_update_instance', 'Cancel');
}
function menuItemCallbackErrorListCancel() {
    if (!customBeforeMenuItemClick('ErrorList', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('ErrorList', 'Cancel');
}
function menuItemCallbackErrorDetailCancel() {
    if (!customBeforeMenuItemClick('ErrorDetail', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('ErrorDetail', 'Cancel');
}

function doAddRowAction(addScreen) {
    var mvc = getCurrentMessageValueCollection();
    var relationKey = getListViewKey(getCurrentScreen());
    var mv = mvc.getData(relationKey);
    var childMVC = new MessageValueCollection();
    var key = guid();
    childMVC.setKey(key);
    childMVC.setState("new");
    childMVC.setParent(mv.getKey());
    childMVC.setParentValue(mv);
    mv.getValue().push(childMVC);
    setDefaultValues(addScreen);
    // collect default values from the addScreen
    updateMessageValueCollectionFromUI(childMVC, addScreen);
    navigateForward(addScreen, key);
}

function doListviewAddRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (mvc.getState() === "new") {
        // this action is triggered after AddRow action
        if (validateScreen(getCurrentScreen(), mvc)) {
            mvc.setState("add");
            doSaveAction(false);
        }
    }
}

function doListviewUpdateRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("update");            
        }
        doSaveAction(false);
    }
}

function doListviewDeleteRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("delete");            
            doSaveAction(false);
        }
        else {
            var valuesArray = mvc.getParentValue().getValue();
            for (var i = 0; i < valuesArray.length; i++) {
                if (valuesArray[i] == mvc) {
                    valuesArray.splice(i, 1);
                }
            }
            navigateBack(true);
            updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        }        
    }
}

function doSaveActionWithoutReturn() {
   doSaveAction();
   return;
}

function doSaveAction(needValidation) {
    if (!getPreviousScreen()) {
        if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
            doSubmitWorkflow(getCurrentScreen(), "Save", '', '');
            return false;
        }
        return true;
    }
    if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
        navigateBack(false);
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        return true;
    }
    return false;
}

function doCancelAction() {
    if (!getPreviousScreen()) {
        closeWorkflow();
        return;
    }
    var mvc = getCurrentMessageValueCollection();
    navigateBack(true);
    var mvc1 = getCurrentMessageValueCollection();
    if (mvc.getState() === "add" || mvc.getState() === "new") {
        mvc1.getData(mvc.getParent()).getValue().pop();
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
    } else if (mvc.getState() === "update") {
        mvc.setState("");
    }
}

function customNavigationEntry() {
    this.condition;
    this.screen;
}
function customNavigationEntry( a_condition, a_screen ) {
    this.condition = a_condition;
    this.screen = a_screen;
}

/**
 * For the specific pair - screen named 'currentScreenKey' and the action 'actionName', return
 * the list of custom navigation condition-names and their destination screens.
 */
function getCustomNavigations( currentScreenKey, actionName )  {
    var customNavigations = new Array();
    return customNavigations;
}
