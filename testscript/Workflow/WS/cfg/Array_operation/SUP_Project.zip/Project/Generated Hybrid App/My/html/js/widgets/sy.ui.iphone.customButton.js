$.widget("sy.customButton", $.mobile.widget, {
    _create: function(){
        var self = this,
        customBtDiv  = this.element.wrap( "<div class='ui-custom-button'>" ),
        label =this.element.attr('value');
        
        button = ( $( "<a>", {
					"href": "#",
					"role": "button",
				}) )
				.text(label )
				.insertBefore( customBtDiv )
				.buttonMarkup({
					theme:'a'
				});
				
		var imgSrc = this.element.attr('src');
		var img = null; 
		
		if (  this.element.attr('type') === 'image'  ){
		
		    var innerSpan = button.find('.ui-btn-inner');
		    if ( innerSpan.length > 0 ) {
		    
		        var span = ($("<span>", {"class": "ui-button-image"}));
		        innerSpan.append( span);
		        img  = $("<img>", {"src":imgSrc,
		                              "height":this.element.attr('height'),
		                              "width":this.element.attr('width'),
		                              "class":"ui-image"
		                              });
		                              
		        span.append( img );
		    }
		}
		var pos = this.element.attr('label-position');
	    var innerLabel = button.find('.ui-btn-text');
		
		if ( innerLabel && innerLabel.length > 0 ) {
		     innerLabel.addClass('label-'+ pos);
		}
		
		if ( ( pos == 'center_top' || pos === 'center_bottom' )  ){
		     innerLabel.addClass('label-center');
		}
		
		if (pos === 'center_bottom' && span  ) {
		    span.insertBefore( button.find('.ui-btn-text'));
		    
		}
		button.bind('click', function() { self.element.click() });
		this.refresh();
    },
    
    refresh: function() {
    	var btImage =  this.element.closest('.ui-custom-button').find('img.ui-image');
    	btImage.attr('src', this.element.attr('src'));
    },
	options: {
		theme: null
	}
});