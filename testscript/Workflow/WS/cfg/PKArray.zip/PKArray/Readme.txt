if input array {"1","2","3"} return "correct"
else return "wrong"