/*
 * Sybase Mobile Workflow version 2.0.1
 * 
 * Workflow.js
 * This file will be regenerated, so changes made herein will be removed the
 * next time the workflow is regenerated. It is therefore strongly recommended
 * that the user not make changes in this file.
 * 
 * Copyright (c) 2010 Sybase Inc. All rights reserved.
 */



function menuItemCallbackCustomer_update_instanceOnline_Request() {
    if (!customBeforeMenuItemClick('Customer_update_instance', 'Online_Request')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'Customer_fname_attribKey';
    rmiKeyTypes[0] = 'TEXT';
    rmiKeys[1] = '_old.Customer.fname';
    rmiKeyTypes[1] = 'TEXT';
    rmiKeys[2] = 'Customer_lname_attribKey';
    rmiKeyTypes[2] = 'TEXT';
    rmiKeys[3] = '_old.Customer.lname';
    rmiKeyTypes[3] = 'TEXT';
    rmiKeys[4] = 'Customer_address_attribKey';
    rmiKeyTypes[4] = 'TEXT';
    rmiKeys[5] = '_old.Customer.address';
    rmiKeyTypes[5] = 'TEXT';
    rmiKeys[6] = 'Customer_city_attribKey';
    rmiKeyTypes[6] = 'TEXT';
    rmiKeys[7] = '_old.Customer.city';
    rmiKeyTypes[7] = 'TEXT';
    rmiKeys[8] = 'Customer_state_attribKey';
    rmiKeyTypes[8] = 'TEXT';
    rmiKeys[9] = '_old.Customer.state';
    rmiKeyTypes[9] = 'TEXT';
    rmiKeys[10] = 'Customer_zip_attribKey';
    rmiKeyTypes[10] = 'TEXT';
    rmiKeys[11] = '_old.Customer.zip';
    rmiKeyTypes[11] = 'TEXT';
    rmiKeys[12] = 'Customer_phone_attribKey';
    rmiKeyTypes[12] = 'TEXT';
    rmiKeys[13] = '_old.Customer.phone';
    rmiKeyTypes[13] = 'TEXT';
    rmiKeys[14] = 'Customer_company_name_attribKey';
    rmiKeyTypes[14] = 'TEXT';
    rmiKeys[15] = '_old.Customer.company_name';
    rmiKeyTypes[15] = 'TEXT';
    rmiKeys[16] = 'Customer_id_attribKey';
    rmiKeyTypes[16] = 'NUMBER';
    rmiKeys[17] = '_old.Customer.id';
    rmiKeyTypes[17] = 'NUMBER';
    rmiKeys[18] = 'ErrorLogs';
    rmiKeyTypes[18] = 'LIST';
    rmiKeys[19] = 'Customer_salesOrders_relationshipKey';
    rmiKeyTypes[19] = 'LIST';
    rmiKeys[20] = '_old.Customer.salesOrders.Customer_salesOrders_relationshipKey';
    rmiKeyTypes[20] = 'LIST';
    rmiInputOnlyKeys[0] = 'Customer_fname_attribKey';
    rmiInputOnlyKeyTypes[0] = 'TEXT';
    rmiInputOnlyKeys[1] = '_old.Customer.fname';
    rmiInputOnlyKeyTypes[1] = 'TEXT';
    rmiInputOnlyKeys[2] = 'Customer_lname_attribKey';
    rmiInputOnlyKeyTypes[2] = 'TEXT';
    rmiInputOnlyKeys[3] = '_old.Customer.lname';
    rmiInputOnlyKeyTypes[3] = 'TEXT';
    rmiInputOnlyKeys[4] = 'Customer_address_attribKey';
    rmiInputOnlyKeyTypes[4] = 'TEXT';
    rmiInputOnlyKeys[5] = '_old.Customer.address';
    rmiInputOnlyKeyTypes[5] = 'TEXT';
    rmiInputOnlyKeys[6] = 'Customer_city_attribKey';
    rmiInputOnlyKeyTypes[6] = 'TEXT';
    rmiInputOnlyKeys[7] = '_old.Customer.city';
    rmiInputOnlyKeyTypes[7] = 'TEXT';
    rmiInputOnlyKeys[8] = 'Customer_state_attribKey';
    rmiInputOnlyKeyTypes[8] = 'TEXT';
    rmiInputOnlyKeys[9] = '_old.Customer.state';
    rmiInputOnlyKeyTypes[9] = 'TEXT';
    rmiInputOnlyKeys[10] = 'Customer_zip_attribKey';
    rmiInputOnlyKeyTypes[10] = 'TEXT';
    rmiInputOnlyKeys[11] = '_old.Customer.zip';
    rmiInputOnlyKeyTypes[11] = 'TEXT';
    rmiInputOnlyKeys[12] = 'Customer_phone_attribKey';
    rmiInputOnlyKeyTypes[12] = 'TEXT';
    rmiInputOnlyKeys[13] = '_old.Customer.phone';
    rmiInputOnlyKeyTypes[13] = 'TEXT';
    rmiInputOnlyKeys[14] = 'Customer_company_name_attribKey';
    rmiInputOnlyKeyTypes[14] = 'TEXT';
    rmiInputOnlyKeys[15] = '_old.Customer.company_name';
    rmiInputOnlyKeyTypes[15] = 'TEXT';
    rmiInputOnlyKeys[16] = 'Customer_id_attribKey';
    rmiInputOnlyKeyTypes[16] = 'NUMBER';
    rmiInputOnlyKeys[17] = '_old.Customer.id';
    rmiInputOnlyKeyTypes[17] = 'NUMBER';
    rmiInputOnlyKeys[18] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[18] = 'LIST';
    rmiInputOnlyKeys[19] = 'Customer_salesOrders_relationshipKey';
    rmiInputOnlyKeyTypes[19] = 'LIST';
    rmiInputOnlyKeys[20] = '_old.Customer.salesOrders.Customer_salesOrders_relationshipKey';
    rmiInputOnlyKeyTypes[20] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Customer_update_instance', 'Online_Request', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Customer_update_instance', 'Online_Request', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('Customer_update_instance', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('Customer_update_instance', 'Online_Request', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Customer_update_instance', 'Online_Request');
}


function menuItemCallbackCustomer_update_instanceCancel() {
    if (!customBeforeMenuItemClick('Customer_update_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Customer_update_instance', 'Cancel');
}


function menuItemCallbackCustomer_delete_instanceOnline_Request() {
    if (!customBeforeMenuItemClick('Customer_delete_instance', 'Online_Request')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'Customer_id_attribKey';
    rmiKeyTypes[0] = 'NUMBER';
    rmiKeys[1] = '_old.Customer.id';
    rmiKeyTypes[1] = 'NUMBER';
    rmiKeys[2] = 'ErrorLogs';
    rmiKeyTypes[2] = 'LIST';
    rmiKeys[3] = 'Customer_fname_attribKey';
    rmiKeyTypes[3] = 'TEXT';
    rmiKeys[4] = '_old.Customer.fname';
    rmiKeyTypes[4] = 'TEXT';
    rmiKeys[5] = 'Customer_lname_attribKey';
    rmiKeyTypes[5] = 'TEXT';
    rmiKeys[6] = '_old.Customer.lname';
    rmiKeyTypes[6] = 'TEXT';
    rmiKeys[7] = 'Customer_address_attribKey';
    rmiKeyTypes[7] = 'TEXT';
    rmiKeys[8] = '_old.Customer.address';
    rmiKeyTypes[8] = 'TEXT';
    rmiKeys[9] = 'Customer_city_attribKey';
    rmiKeyTypes[9] = 'TEXT';
    rmiKeys[10] = '_old.Customer.city';
    rmiKeyTypes[10] = 'TEXT';
    rmiKeys[11] = 'Customer_state_attribKey';
    rmiKeyTypes[11] = 'TEXT';
    rmiKeys[12] = '_old.Customer.state';
    rmiKeyTypes[12] = 'TEXT';
    rmiKeys[13] = 'Customer_zip_attribKey';
    rmiKeyTypes[13] = 'TEXT';
    rmiKeys[14] = '_old.Customer.zip';
    rmiKeyTypes[14] = 'TEXT';
    rmiKeys[15] = 'Customer_phone_attribKey';
    rmiKeyTypes[15] = 'TEXT';
    rmiKeys[16] = '_old.Customer.phone';
    rmiKeyTypes[16] = 'TEXT';
    rmiKeys[17] = 'Customer_company_name_attribKey';
    rmiKeyTypes[17] = 'TEXT';
    rmiKeys[18] = '_old.Customer.company_name';
    rmiKeyTypes[18] = 'TEXT';
    rmiKeys[19] = 'Customer_salesOrders_relationshipKey';
    rmiKeyTypes[19] = 'LIST';
    rmiKeys[20] = '_old.Customer.salesOrders.Customer_salesOrders_relationshipKey';
    rmiKeyTypes[20] = 'LIST';
    rmiInputOnlyKeys[0] = 'Customer_id_attribKey';
    rmiInputOnlyKeyTypes[0] = 'NUMBER';
    rmiInputOnlyKeys[1] = '_old.Customer.id';
    rmiInputOnlyKeyTypes[1] = 'NUMBER';
    rmiInputOnlyKeys[2] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[2] = 'LIST';
    rmiInputOnlyKeys[3] = 'Customer_fname_attribKey';
    rmiInputOnlyKeyTypes[3] = 'TEXT';
    rmiInputOnlyKeys[4] = '_old.Customer.fname';
    rmiInputOnlyKeyTypes[4] = 'TEXT';
    rmiInputOnlyKeys[5] = 'Customer_lname_attribKey';
    rmiInputOnlyKeyTypes[5] = 'TEXT';
    rmiInputOnlyKeys[6] = '_old.Customer.lname';
    rmiInputOnlyKeyTypes[6] = 'TEXT';
    rmiInputOnlyKeys[7] = 'Customer_address_attribKey';
    rmiInputOnlyKeyTypes[7] = 'TEXT';
    rmiInputOnlyKeys[8] = '_old.Customer.address';
    rmiInputOnlyKeyTypes[8] = 'TEXT';
    rmiInputOnlyKeys[9] = 'Customer_city_attribKey';
    rmiInputOnlyKeyTypes[9] = 'TEXT';
    rmiInputOnlyKeys[10] = '_old.Customer.city';
    rmiInputOnlyKeyTypes[10] = 'TEXT';
    rmiInputOnlyKeys[11] = 'Customer_state_attribKey';
    rmiInputOnlyKeyTypes[11] = 'TEXT';
    rmiInputOnlyKeys[12] = '_old.Customer.state';
    rmiInputOnlyKeyTypes[12] = 'TEXT';
    rmiInputOnlyKeys[13] = 'Customer_zip_attribKey';
    rmiInputOnlyKeyTypes[13] = 'TEXT';
    rmiInputOnlyKeys[14] = '_old.Customer.zip';
    rmiInputOnlyKeyTypes[14] = 'TEXT';
    rmiInputOnlyKeys[15] = 'Customer_phone_attribKey';
    rmiInputOnlyKeyTypes[15] = 'TEXT';
    rmiInputOnlyKeys[16] = '_old.Customer.phone';
    rmiInputOnlyKeyTypes[16] = 'TEXT';
    rmiInputOnlyKeys[17] = 'Customer_company_name_attribKey';
    rmiInputOnlyKeyTypes[17] = 'TEXT';
    rmiInputOnlyKeys[18] = '_old.Customer.company_name';
    rmiInputOnlyKeyTypes[18] = 'TEXT';
    rmiInputOnlyKeys[19] = 'Customer_salesOrders_relationshipKey';
    rmiInputOnlyKeyTypes[19] = 'LIST';
    rmiInputOnlyKeys[20] = '_old.Customer.salesOrders.Customer_salesOrders_relationshipKey';
    rmiInputOnlyKeyTypes[20] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Customer_delete_instance', 'Online_Request', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Customer_delete_instance', 'Online_Request', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('Customer_delete_instance', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('Customer_delete_instance', 'Online_Request', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Customer_delete_instance', 'Online_Request');
}


function menuItemCallbackCustomer_delete_instanceCancel() {
    if (!customBeforeMenuItemClick('Customer_delete_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Customer_delete_instance', 'Cancel');
}


function menuItemCallbackCustomerDetailSubmit() {
    if (!customBeforeMenuItemClick('CustomerDetail', 'Submit')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'ErrorLogs';
    rmiKeyTypes[0] = 'LIST';
    rmiKeys[1] = 'Customer_id_attribKey';
    rmiKeyTypes[1] = 'NUMBER';
    rmiKeys[2] = '_old.Customer.id';
    rmiKeyTypes[2] = 'NUMBER';
    rmiKeys[3] = 'Customer_fname_attribKey';
    rmiKeyTypes[3] = 'TEXT';
    rmiKeys[4] = '_old.Customer.fname';
    rmiKeyTypes[4] = 'TEXT';
    rmiKeys[5] = 'Customer_lname_attribKey';
    rmiKeyTypes[5] = 'TEXT';
    rmiKeys[6] = '_old.Customer.lname';
    rmiKeyTypes[6] = 'TEXT';
    rmiKeys[7] = 'Customer_address_attribKey';
    rmiKeyTypes[7] = 'TEXT';
    rmiKeys[8] = '_old.Customer.address';
    rmiKeyTypes[8] = 'TEXT';
    rmiKeys[9] = 'Customer_city_attribKey';
    rmiKeyTypes[9] = 'TEXT';
    rmiKeys[10] = '_old.Customer.city';
    rmiKeyTypes[10] = 'TEXT';
    rmiKeys[11] = 'Customer_state_attribKey';
    rmiKeyTypes[11] = 'TEXT';
    rmiKeys[12] = '_old.Customer.state';
    rmiKeyTypes[12] = 'TEXT';
    rmiKeys[13] = 'Customer_zip_attribKey';
    rmiKeyTypes[13] = 'TEXT';
    rmiKeys[14] = '_old.Customer.zip';
    rmiKeyTypes[14] = 'TEXT';
    rmiKeys[15] = 'Customer_phone_attribKey';
    rmiKeyTypes[15] = 'TEXT';
    rmiKeys[16] = '_old.Customer.phone';
    rmiKeyTypes[16] = 'TEXT';
    rmiKeys[17] = 'Customer_company_name_attribKey';
    rmiKeyTypes[17] = 'TEXT';
    rmiKeys[18] = '_old.Customer.company_name';
    rmiKeyTypes[18] = 'TEXT';
    rmiKeys[19] = 'Customer_salesOrders_relationshipKey';
    rmiKeyTypes[19] = 'LIST';
    rmiKeys[20] = '_old.Customer.salesOrders.Customer_salesOrders_relationshipKey';
    rmiKeyTypes[20] = 'LIST';
    rmiInputOnlyKeys[0] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[0] = 'LIST';
    rmiInputOnlyKeys[1] = 'Customer_id_attribKey';
    rmiInputOnlyKeyTypes[1] = 'NUMBER';
    rmiInputOnlyKeys[2] = '_old.Customer.id';
    rmiInputOnlyKeyTypes[2] = 'NUMBER';
    rmiInputOnlyKeys[3] = 'Customer_fname_attribKey';
    rmiInputOnlyKeyTypes[3] = 'TEXT';
    rmiInputOnlyKeys[4] = '_old.Customer.fname';
    rmiInputOnlyKeyTypes[4] = 'TEXT';
    rmiInputOnlyKeys[5] = 'Customer_lname_attribKey';
    rmiInputOnlyKeyTypes[5] = 'TEXT';
    rmiInputOnlyKeys[6] = '_old.Customer.lname';
    rmiInputOnlyKeyTypes[6] = 'TEXT';
    rmiInputOnlyKeys[7] = 'Customer_address_attribKey';
    rmiInputOnlyKeyTypes[7] = 'TEXT';
    rmiInputOnlyKeys[8] = '_old.Customer.address';
    rmiInputOnlyKeyTypes[8] = 'TEXT';
    rmiInputOnlyKeys[9] = 'Customer_city_attribKey';
    rmiInputOnlyKeyTypes[9] = 'TEXT';
    rmiInputOnlyKeys[10] = '_old.Customer.city';
    rmiInputOnlyKeyTypes[10] = 'TEXT';
    rmiInputOnlyKeys[11] = 'Customer_state_attribKey';
    rmiInputOnlyKeyTypes[11] = 'TEXT';
    rmiInputOnlyKeys[12] = '_old.Customer.state';
    rmiInputOnlyKeyTypes[12] = 'TEXT';
    rmiInputOnlyKeys[13] = 'Customer_zip_attribKey';
    rmiInputOnlyKeyTypes[13] = 'TEXT';
    rmiInputOnlyKeys[14] = '_old.Customer.zip';
    rmiInputOnlyKeyTypes[14] = 'TEXT';
    rmiInputOnlyKeys[15] = 'Customer_phone_attribKey';
    rmiInputOnlyKeyTypes[15] = 'TEXT';
    rmiInputOnlyKeys[16] = '_old.Customer.phone';
    rmiInputOnlyKeyTypes[16] = 'TEXT';
    rmiInputOnlyKeys[17] = 'Customer_company_name_attribKey';
    rmiInputOnlyKeyTypes[17] = 'TEXT';
    rmiInputOnlyKeys[18] = '_old.Customer.company_name';
    rmiInputOnlyKeyTypes[18] = 'TEXT';
    rmiInputOnlyKeys[19] = 'Customer_salesOrders_relationshipKey';
    rmiInputOnlyKeyTypes[19] = 'LIST';
    rmiInputOnlyKeys[20] = '_old.Customer.salesOrders.Customer_salesOrders_relationshipKey';
    rmiInputOnlyKeyTypes[20] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('CustomerDetail', 'Submit', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('CustomerDetail', 'Submit', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('CustomerDetail', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('CustomerDetail', 'Submit', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('CustomerDetail', 'Submit');
}


function menuItemCallbackCustomerDetailOpen_Sales_order() {
    if (!customBeforeMenuItemClick('CustomerDetail', 'Open_Sales_order')) {
        return;
    }
    navigateForward('Sales_order');
    customAfterMenuItemClick('CustomerDetail', 'Open_Sales_order');
}


function menuItemCallbackCustomerDetailOpen_Customer_update_instance() {
    if (!customBeforeMenuItemClick('CustomerDetail', 'Open_Customer_update_instance')) {
        return;
    }
    navigateForward('Customer_update_instance');
    customAfterMenuItemClick('CustomerDetail', 'Open_Customer_update_instance');
}


function menuItemCallbackCustomerDetailOpen_Customer_delete_instance() {
    if (!customBeforeMenuItemClick('CustomerDetail', 'Open_Customer_delete_instance')) {
        return;
    }
    navigateForward('Customer_delete_instance');
    customAfterMenuItemClick('CustomerDetail', 'Open_Customer_delete_instance');
}


function menuItemCallbackCustomerDetailBack() {
    if (!customBeforeMenuItemClick('CustomerDetail', 'Back')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('CustomerDetail', 'Back');
}
function menuItemCallbackCustomerDetailCancel() {
   if (!customBeforeMenuItemClick('CustomerDetail', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('CustomerDetail', 'Cancel');
}


function menuItemCallbackSales_orderAdd() {
    if (!customBeforeMenuItemClick('Sales_order', 'Add')) {
        return;
    }
    doAddRowAction('Sales_order_add');
    customAfterMenuItemClick('Sales_order', 'Add');
}


function menuItemCallbackSales_orderBack() {
    if (!customBeforeMenuItemClick('Sales_order', 'Back')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('Sales_order', 'Back');
}
function menuItemCallbackSales_orderCancel() {
   if (!customBeforeMenuItemClick('Sales_order', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Sales_order', 'Cancel');
}


function menuItemCallbackSales_order_addAdd_Key_Collection() {
    if (!customBeforeMenuItemClick('Sales_order_add', 'Add_Key_Collection')) {
        return;
    }
    doListviewAddRowAction("Customer_salesOrders_relationshipKey");
    customAfterMenuItemClick('Sales_order_add', 'Add_Key_Collection');
}


function menuItemCallbackSales_order_addCancel() {
    if (!customBeforeMenuItemClick('Sales_order_add', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Sales_order_add', 'Cancel');
}


function menuItemCallbackSales_order_update_instanceUpdate_Key_Collection() {
    if (!customBeforeMenuItemClick('Sales_order_update_instance', 'Update_Key_Collection')) {
        return;
    }
    doListviewUpdateRowAction("Customer_salesOrders_relationshipKey");
    customAfterMenuItemClick('Sales_order_update_instance', 'Update_Key_Collection');
}


function menuItemCallbackSales_order_update_instanceCancel() {
    if (!customBeforeMenuItemClick('Sales_order_update_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Sales_order_update_instance', 'Cancel');
}


function menuItemCallbackSales_orderDetailOpen_Screen_Sales_order_update_instance() {
    if (!customBeforeMenuItemClick('Sales_orderDetail', 'Open_Screen_Sales_order_update_instance')) {
        return;
    }
    navigateForward('Sales_order_update_instance');
    customAfterMenuItemClick('Sales_orderDetail', 'Open_Screen_Sales_order_update_instance');
}


function menuItemCallbackSales_orderDetailSales_order_delete_instance() {
    if (!customBeforeMenuItemClick('Sales_orderDetail', 'Sales_order_delete_instance')) {
        return;
    }
    doListviewDeleteRowAction("Customer_salesOrders_relationshipKey");
    customAfterMenuItemClick('Sales_orderDetail', 'Sales_order_delete_instance');
}


function menuItemCallbackSales_orderDetailBack() {
    if (!customBeforeMenuItemClick('Sales_orderDetail', 'Back')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('Sales_orderDetail', 'Back');
}
function menuItemCallbackSales_orderDetailCancel() {
   if (!customBeforeMenuItemClick('Sales_orderDetail', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Sales_orderDetail', 'Cancel');
}


function menuItemCallbackCustomerSubmit() {
    if (!customBeforeMenuItemClick('Customer', 'Submit')) {
        return;
    }

    if (saveScreens()) {
        doSubmitWorkflow('Customer', 'Submit', '', '');
    }
    customAfterMenuItemClick('Customer', 'Submit');
}


function menuItemCallbackCustomerCancel_Screen() {
    if (!customBeforeMenuItemClick('Customer', 'Cancel_Screen')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Customer', 'Cancel_Screen');
}

function doAddRowAction(addScreen) {
    var mvc = getCurrentMessageValueCollection();
    var relationKey = getListViewKey(getCurrentScreen());
    var mv = mvc.getData(relationKey);
    var childMVC = new MessageValueCollection();
    var key = guid();
    childMVC.setKey(key);
    childMVC.setState("new");
    childMVC.setParent(mv.getKey());
    childMVC.setParentValue(mv);
    mv.getValue().push(childMVC);
    setDefaultValues(addScreen);
    // collect default values from the addScreen
    updateMessageValueCollectionFromUI(childMVC, addScreen);
    navigateForward(addScreen, key);
}

function doListviewAddRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (mvc.getState() === "new") {
        // this action is triggered after AddRow action
        if (validateScreen(getCurrentScreen(), mvc)) {
            mvc.setState("add");
            doSaveAction(false);
        }
    }
}

function doListviewUpdateRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("update");            
        }
        doSaveAction(false);
    }
}

function doListviewDeleteRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("delete");            
            doSaveAction(false);
        }
        else {
            var valuesArray = mvc.getParentValue().getValue();
            for (var i = 0; i < valuesArray.length; i++) {
                if (valuesArray[i] == mvc) {
                    valuesArray.splice(i, 1);
                }
            }
            navigateBack(true);
            updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        }        
    }
}

function doSaveActionWithoutReturn() {
   doSaveAction();
   return;
}

function doSaveAction(needValidation) {
    if (!getPreviousScreen()) {
        if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
            doSubmitWorkflow(getCurrentScreen(), "Save", '', '');
            return false;
        }
        return true;
    }
    if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
        navigateBack(false);
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        return true;
    }
    return false;
}

function doCancelAction() {
    if (!getPreviousScreen()) {
        closeWorkflow();
        return;
    }
    var mvc = getCurrentMessageValueCollection();
    navigateBack(true);
    var mvc1 = getCurrentMessageValueCollection();
    if (mvc.getState() === "add" || mvc.getState() === "new") {
        mvc1.getData(mvc.getParent()).getValue().pop();
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
    } else if (mvc.getState() === "update") {
        mvc.setState("");
    }
}
