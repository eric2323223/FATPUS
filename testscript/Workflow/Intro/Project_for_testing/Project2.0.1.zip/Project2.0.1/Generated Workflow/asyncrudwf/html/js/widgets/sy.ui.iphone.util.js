  function adjustNavigationBar( divPage  ) {
      
      //1. adjust the header bar.
      var header = $(divPage).children(".ui-header");
      if ( header.length > 0 ) {
          var rightbt = header.children(".ui-btn-right");
          var leftbt = header.children(".ui-btn-left");
          var title = header.children(".ui-title");
           
          //keep default width, otherwise, when rotation, we don't know real width
          var defLeftW = leftbt.attr('defaultWidth');
          if (! defLeftW ) {
              defLeftW = leftbt.width();
              leftbt.attr('defaultWidth', defLeftW );
          }
 
          var defTitleW =   title.attr('defaultWidth');
          if ( !defTitleW ){
              defTitleW = title.width();
              title.attr('defaultWidth',   defTitleW);
          }
          
          if ( rightbt.length > 0 ) {
              var defRightW = rightbt.attr('defaultWidth');
              if (! defRightW ) {
                  defRightW = rightbt.width();
                  rightbt.attr('defaultWidth', defRightW );
              } 
               
              var emptySpace = header.width()- defLeftW  - defTitleW - defRightW -20; //bt ( 5px + border 2X1 ) X2 + title marge 3X2 = 20px
              var half = parseInt( emptySpace/2 -1);
                 
            
              if (emptySpace > 0 ) {   //we have more space on the bar.
                  title.css("width", defTitleW +'px');  //restore the original width 
                  leftbt.css("width", defLeftW +'px');  
                  rightbt.css("width", defRightW +'px'); 
                 
                   //Try to put title at the center of the screen instead of between two buttons.
                  var headerWidth = header.width();
                  var num1 = parseInt( defLeftW ) + 7;
                  var num2 =  parseInt( defRightW  ) + 7;
                  if ( num1  < headerWidth/2 && num2  < headerWidth/2 ) {
                      var margForCentrTitle =parseInt( headerWidth )/2 - 7 - parseInt( defLeftW )- parseInt(defTitleW )/2 ;
                      if ( margForCentrTitle < 0 ) {
                          title.css("margin-left", '3px');
                      }else {
                          var overlap=  parseInt( headerWidth ) - parseInt( defLeftW ) - 7 - parseInt( defRightW ) - 7 - margForCentrTitle - parseInt( defTitleW );
                          if (overlap < 0 ) {
                               margForCentrTitle = margForCentrTitle + overlap;
                          }
                          title.css("margin-left",margForCentrTitle+'px');
                      }
                  }else if (  num1 > headerWidth/2 )  {
                      title.css("margin-left",'0px'); //center the title.
                  }else if ( num2 > headerWidth/2 ) {
                      emptySpace = emptySpace -2;
                      title.css("margin-left", emptySpace +'px'); //center the title.
                  }else {
                       title.css("margin-left",half +'px'); //center the title.
                  }
                        
              }else {  // we don't have enough space,need to squeeze left button and title just as iphone app does for their navigation bar.
                  title.css("margin-left",'3px');
                  var lfbt = parseInt( defLeftW) +parseInt( half);
                  var squeezeSize = 0;
                  if ( lfbt < 60 ) { //minimum we need 60 px for the button.
                      leftbt.css( "width", "60px");
                      squeezeSize  = lfbt - 60;
                  }else {
                       leftbt.css( "width", lfbt +"px");
                  }
               
                  var tl =  parseInt( defTitleW ) +parseInt( half);
               
                  if (tl < 60 ) {
                      title.css( 'width', "60px");
                     squeezeSize = squeezeSize + tl - 60;
                  }else {
                      title.css( 'width', tl  +"px");
                  }
                  rightbt.css( 'width',defRightW  +"px");
                  if ( squeezeSize < 0  ) { 
                      var  maxW = 0;
                      var obj = null;
                      if ( leftbt.width() > maxW ) {
                           maxW = leftbt.width();
                           obj = leftbt;
                      } 
                      
                      if ( rightbt.width() > maxW ) {
                           maxW = rightbt.width();
                           obj = rightbt;
                      }
                      if ( title.width() > maxW ) {
                           maxW = title.width();
                           obj = title;
                      }
                      if ( obj != null ) {
                          var newW =  maxW + squeezeSize;
                          obj.css('width',newW );
                      }
                  }
              } //end of emptySpace < 0 
          }else if (leftbt.length > 0 ) { //no right button, only left button and title.
              var emptySpace = header.width()- defLeftW  - defTitleW -13; //left bt start at 5px + border 2px + title margin 2X3px = 13px
              var half = parseInt( emptySpace/2 -1);
              if ( emptySpace < 0 ) {  //squeeze title and left button.
                  title.css("margin-left",'3px');
                  var lf = parseInt( defLeftW) +parseInt( half);
                  leftbt.css("width", lf+ "px")
                      
                  var tl =  parseInt( defTitleW ) +parseInt( half);
                  title.css("width", tl+ "px")
              }else {
                  title.css("margin-left",half +'px');  //center the title
                  title.css("width", defTitleW +'px');  
                  leftbt.css("width", defLeftW +'px');  
                     
                  //Try to put title at the center of the screen instead of between two buttons.
                  var headerWidth = header.width();
                  var num1 = parseInt( defLeftW ) + 7;
                  if ( num1 < headerWidth/2 ){
                      var margForCentrTitle =parseInt( headerWidth )/2 - 7 - parseInt( defLeftW ) - parseInt(defTitleW )/2 ;
                      if ( margForCentrTitle < 0 ) {
                          title.css("margin-left", '0px');
                      }else {
                          title.css("margin-left",margForCentrTitle+'px');
                      }
                  }else {
                      title.css("margin-left",'0px'); //center the title.
                  }
              }
          }
      }
      //2. adjust footer bar
      
      var footer = $(divPage).children(".ui-bar");
      if ( footer.length > 0 ) {
          var bts =  footer.find( "[data-role='button']");
          var bt1W=0, bt2W=0, bt3W=0;
          var hasActionSheetBt = false;
          if ( bts.length > 1 ) {   //if we have 2 or 3 buttons on the footer, 
              bt1W  =  $(bts[0]).attr("defaultWidth");
              if ( !bt1W ) {
                  bt1W =  $(bts[0]).width();
                  $(bts[0]).attr("defaultWidth", bt1W);
              }
              bt2W  =  $(bts[1]).attr("defaultWidth");
              if ( !bt2W ) {
                  bt2W =  $(bts[1]).width();
                  $(bts[1]).attr("defaultWidth", bt2W);
              }
          }
          if ( bts.length > 2 ) {
              bt3W  =  $(bts[2]).attr("defaultWidth");
              hasActionSheetBt = $(bts[1]).attr('id').indexOf('ActionSheet') > 0;
                 
              if ( !bt3W ) {
                  bt3W =  $(bts[2]).width();
                  $(bts[2]).attr("defaultWidth", bt3W);
                  if ( !hasActionSheetBt ) {
                      $(bts[1]).addClass('ui-btn-center');
                  }
              } 
          }
          var  emptySpace = footer.width() - bt1W - bt2W - bt3W - 6 ;
          if ( emptySpace > 0){
             
              if ( bts.length == 3 ) {
                  if ( hasActionSheetBt ) {
                     $(bts[1]).css('margin-left', parseInt( emptySpace/2 -1 ) + 'px'); //center the center button.
                     $(bts[0]).css('width', parseInt( bt1W)); //restore other buttons' width.
                     $(bts[2]).css('width', parseInt( bt3W ));
                  }else {
                     $(bts[1]).css('margin-left', parseInt( emptySpace/2 -1 ) + 'px'); //center the center button.
                     $(bts[0]).css('width', parseInt( bt1W)); //restore other buttons' width.
                     $(bts[1]).css('width', parseInt( bt2W));
                     $(bts[2]).css('width', parseInt( bt3W ));
                  }
              }else if ( bts.length == 2 ){
                  $(bts[0]).css('width', parseInt( bt1W)); //restore other buttons' width.
                  $(bts[1]).css('width', parseInt( bt2W ));
              }
          }else {   //we need to squeeze the buttons. 
              if ( bts.length == 3) {
                  $(bts[1]).css('margin-left','10px');
                  $(bts[1]).css('margin-right','0px');
                  var squeezeSize = 0;
                 if ( hasActionSheetBt ) { //try only shrink left and right button.
                      emptySpace =  emptySpace - 20;
                      var half =  emptySpace/2;
                     var bt0 = parseInt(bt1W) + parseInt(half ); 
                      if ( bt0 < 60 ) {
                          $(bts[0]).css('width', '60px' );
                            squeezeSize  = bt0 - 60 ;
                      }else{
                          $(bts[0]).css('width', bt0 +'px');
                      }
                      var bt2 = parseInt( bt3W ) + parseInt( half );
                      
                      if (  bt2 < 60 ) {
                          $(bts[2]).css('width', '60px' );
                           squeezeSize =  squeezeSize +  bt2 - 60 ;
                      }else {
                          $(bts[2]).css('width',bt2 +'px');
                      }
                  }else {
                      var reduceSize= ( emptySpace - 10 )/3 -5;
                      var bt0 = parseInt( bt1W )  + parseInt(reduceSize ) ; 
                      if (  bt0  < 60 ) {
                          $(bts[0]).css('width','60px');
                          squeezeSize = bt0 - 60 ;
                      }else {
                          $(bts[0]).css('width', bt0 +'px');
                      }
                      
                      var bt1 = parseInt( bt2W)  + parseInt( reduceSize ) ; 
                      if ( bt1 < 60 ) {
                          $(bts[1]).css('width', '60px');
                          squeezeSize = squeezeSize + bt1 - 60 
                      }else {
                          $(bts[1]).css('width', bt1 +'px');
                      }
                      var bt2 = parseInt( bt3W ) + parseInt(reduceSize );
                      
                       if ( bt2 < 60 ) {
                          $(bts[2]).css('width', '60px');
                          squeezeSize = squeezeSize+ bt2 - 60; 
                      }else {
                          $(bts[2]).css('width',  bt2 +'px');
                      }
                  }
                  if (squeezeSize < 0 ) {
                      var i;
                      var maxIdx =0;
                      var  maxW = 0;
                      for( i=0; i < 3 ; i++ ) {
                          var w  = $(bts[i]).width();
                          if ( w > maxW ) {
                             maxW = w ;
                             maxIdx = i;
                          }
                      }
                      var newW = $(bts[maxIdx]).width() + parseInt(squeezeSize );
                      $(bts[maxIdx]).css( 'width',  newW +'px');
                  }
              } else if ( bts.length == 2 ){
                  var bt0 = parseInt( bt1W) + parseInt( emptySpace/2-5 );
                  var bt1 = parseInt( bt2W) + parseInt( emptySpace/2-5 );
                  if ( bt0 < 60 ) {
                      $(bts[0]).css('width', '60px');
                      var newW = bt1 +  bt0 - 60 ;
                      $(bts[1]).css('width', newW +'px' );
                  }else {
                       $(bts[0]).css('width', bt0 +'px');
                  }
                  if ( bt1 < 60 ) {
                      $(bts[1]).css('width', '60px');
                      var newW = bt0 +  bt1 - 60 ;
                      $(bts[0]).css('width', newW +'px' );
                  }else {
                       $(bts[1]).css('width', bt1 +'px');
                  }
              }
          } 
      }          
  }  /* end of the function */
  
  /* this function used by Blackberry and Android for setting the right height for background */   
  function  setPageHeight( jqmActivePage ) {
      var contentH = jqmActivePage.find( "[data-role='content']").height() + 32;
      var screenH = screen.height;
      if ( contentH < screenH ) {
          jqmActivePage.css('height',screenH +'px');
      }else {
          jqmActivePage.css('height',contentH +'px');
      }
  }           
  
  /* this function used by iOS for page scrolling with header bar and footer at fixed position */            
  function showScroller( iScroller, isShow, page, isResize ) {
  
      if ( iScroller == null ) {
           iScroller = new iScroll();
      }
      var divPage =  document.getElementById( page );
      if ( divPage == null ) {
          return;
      }
      if ( isShow ) {
          //adjust the buttons on the navigation bar to void them overlapping.
          adjustNavigationBar( divPage )
          iScroller.showPage(page );
      } else if ( !isShow ) {
          iScroller.hidePage( page );
      }
  }

  function showDialog( iScroller, dialog ) {
      if ( iScroller == null ) iScroller = new iScroll();
      iScroller.showPage(dialog.get(0), true);
  }
  
  /*  CR662931-1  */
  function onFrameResize() {
     if (logLevel >= 4) { logToWorkflow("in onFrameResize window.innerWidth="+ window.innerWidth + " window.innerHeight="+ window.innerHeight, "DEBUG", false); }
     showScroller(iScroller, true, getCurrentScreen() + "ScreenDiv");
  }  