/*
 * Sybase Mobile Workflow version 2.1
 * 
 * Custom.js
 * This file will not be regenerated, and it is expected that the user will
 * include customized code herein.
 *
 * The template used to create this file was compiled on Sun Aug 21 16:47:10 PDT 2011
 * 
 * Copyright (c) 2010,2011 Sybase Inc. All rights reserved.
 */

//var myGlobalVariable = "";		// example global variable

var Cases = ["SyncCreate", "AsyncDelete"];
var CurrentCase = 0;
var NextCase = CurrentCase + 1; 
var Result = "";
var SICases = ["SyncUpdate", "AddListview"];


//Use this method to add custom html to the top or bottom of a form
function customBeforeWorkflowLoad() {
    // please note that there is no screen available before loading workflow finishes
    return true;
}

function customAfterWorkflowLoad() {
/*
    var screenKey = getCurrentScreen();
    var form = document.forms[screenKey + "Form"];
    if (form) {
        var topOfFormElem = document.getElementById("topOf" + screenKey + "Form");
        topOfFormElem.innerHTML = "Use this screen to ..."; 
        var bottomOfFormElem = document.getElementById("bottomOf" + screenKey + "Form");
        bottomOfFormElem.innerHTML = "<a href=\"help.html\">Click here to open help</a>";
    }
*/
}


//Use this method to execute code before a submit occurs. One example of such a usecase would be
//adding custom validation to a page. 
//You can also modify the workflow message before it is sent to the server, like for a computed value.
//Return false to prevent the submit from occurring. 
function customBeforeSubmit(screenKey, actionName, workflowMessageToSend) {
/*
    if (screenKey == "Create" && (actionName == "Submit")) {
        var form = document.forms[screenKey + "Form"];
        if (form) {
            var itemCostVal = form.ExpenseTracking_create_itemCost_paramKey.value;
            if (itemCostVal >= 1000) {
                showAlertDialog("Warning, Items costing $1000 or more must also be approved by the accounting department.");
                return true;
            }
        }
    }
*/
/*
	// examine/save/modify the data before the submit action
	if ((screenKey === "Search") && (actionName === "By_First_Name")) {
		// ** Style 1 **
		// store data in a simple global variable by using 'var myGlobalVariable' at the top of this file.
		myGlobalVariable = new Date();

		// ** Style 2 **
		// store data in the HTML 'form' variable
		var form = document.forms[screenKey + "Form"];
		if (form) {
			form.MyGetTheServerData_Var1 = "a value to save away";
			form.MyGetTheServerData_TimeStamp = new Date();
		}

		// ** Style 3 **
		// Can also manipulate the workflow message itself
		var myNewValue1 = new MessageValue();
		myNewValue1.setKey("myKey1");
		myNewValue1.setValue(42);
		myNewValue1.setType("NUMBER");

		var myNewValue2 = new MessageValue();
		myNewValue2.setKey("myKey2");
		myNewValue2.setValue( new Date() );
		myNewValue2.setType("DATETIME");

		var mvc = workflowMessageToSend.getValues();
		if( mvc ) {
			mvc.add( myNewValue1.getKey(), myNewValue1 );
			mvc.add( myNewValue2.getKey(), myNewValue2 );
		}
	}	
*/
//	alert("screenKey: " + screenKey + ", actionName: " + actionName);
	
    return true;
}

//Use this method to execute code after a submit occurs.
function customAfterSubmit(screenKey, actionName) {
/*
	// Examine/save/modify the data after the event processing
	if((screenKey === "Search") && (actionName === "By_First_Name")) {
		// ** Style 1 **
		// the 'myGlobalVariable'
		var timeDiff1 = new Date() - myGlobalVariable;

		// ** Style 2 **
		// the HTML 'form' variable
		var form = document.forms[screenKey + "Form"];
		if (form) {
			// do something with the time difference...
			var timeDiff2 = new Date() - form.MyGetTheServerData_TimeStamp;
		}

		// ** Style 3 **
		// pull data out of the workflow message itself
		var mvc = getCurrentMessageValueCollection();
		if( mvc ) {
			var myValue0 = mvc.getData( "firstNameKey" );
			var myValue1 = mvc.getData( "privateServerData1" );
			var myValue2 = mvc.getData( "privateServerData2" );
		}
	}
*/
	if((screenKey === "Department_delete") && (actionName === "Delete")){
		Result = Result + "AsyncDelete=Pass;";
		end();
//		alert(Result);
		return; 
	}
	
	if((screenKey === "DepartmentDetail") && (actionName === "Submit")){
		Result = Result + "AddListview=Pass;";
		end();
		return; 
	}
	
	
}


//Use this method to add custom code to a forward screen transition. If you return false, the screen
//transition will not occur.
function customBeforeNavigateForward(screenKey, destScreenKey) {
/*
    if (screenKey == "Desc" && (destScreenKey === "Create"))
    {
        var form = document.forms[screenKey + "Form"];
        if (form)
        {
            var desc = form.ExpenseTracking_create_itemDesc_paramKey.value;
            var reason = form.ExpenseTracking_create_reason_paramKey.value;
            if (desc.length == 0 && (reason.length == 0 )) {
                var helpElem = document.getElementById(screenKey + "Form_help");
                setValidationText(helpElem, "Desc or reason must be provided.  Preferably both.");
                return false;
            }
        }
    }
*/
    return true;
}

//Use this method to add custom code after a forward screen transition
function customAfterNavigateForward(screenKey, destScreenKey) {
}

//Use this method to add custom code to a backward screen transition. If you return false, the screen
//transition will not occur.
function customBeforeNavigateBackward(screenKey, isCancelled) {
    return true;
}

//Use this method to add custom code after a backward screen transition
function customAfterNavigateBackward(screenKey, isCancelled) {
}

//Use this method to add custom code when a screen is shown. If you return false, the default
//behavior will not occur.
function customBeforeShowScreen(screenToShow, screenToHide) {

	
    return true;
}

function setCredential(){
	
	document.getElementById("usernamekey").value = "supAdmin"; 
	document.getElementById("passwordkey").value = "s3pAdmin";
}

function clickMenu(screenKey, menuItem){

	if(isWindowsMobile()){
		menuItem = screenKey + menuItem;
		var menu = document.getElementById(menuItem);
		menu.click();
	}else{
		menuItem = screenKey + "ScreenDiv" + menuItem;
		var menu = document.getElementById(menuItem);
		var evt = document.createEvent("MouseEvents");
		evt.initMouseEvent("click", true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
		menu.dispatchEvent(evt); 
	}
}

//function clickMenu(menuItem){
//
//	var menu = document.getElementById(menuItem);
//	
//	
//	var evt = document.createEvent("MouseEvents");
//	evt.initMouseEvent("click", true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
//	menu.dispatchEvent(evt);
//}

function setDeptCreatePara(dept_id, dept_name, head_id){
	document.getElementById("Department_create_dept_id_paramKey").value = dept_id; 
	document.getElementById("Department_create_dept_name_paramKey").value = dept_name;
	document.getElementById("Department_create_dept_head_id_paramKey").value = head_id;
}

function setDeptDeletePara(dept_id){
	document.getElementById("Department_delete_dept_id_paramKey").value = dept_id; 
}

function setDeptUpdatePara(dept_name, head_id){
	document.getElementById("Department_dept_name_attribKey").value = dept_name;
	document.getElementById("Department_dept_head_id_attribKey").value = head_id;
}

function setEmpAddPara(emp_id, manager_id, emp_fname, emp_lname, 
		dept_id, street, city, state, zip_code, phone, status, 
		ss_number, salary, start_date, termination_date, 
		birth_date, bene_health_ins, bene_life_ins, bene_day_care, sex){
	document.getElementById("Employee_create_emp_id_paramKey").value = emp_id; 
	document.getElementById("Employee_create_manager_id_paramKey").value = manager_id; 
	document.getElementById("Employee_create_emp_fname_paramKey").value = emp_fname; 
	document.getElementById("Employee_create_emp_lname_paramKey").value = emp_lname; 
	document.getElementById("Employee_create_dept_id_paramKey").value = dept_id; 
	document.getElementById("Employee_create_street_paramKey").value = street; 
	document.getElementById("Employee_create_city_paramKey").value = city; 
	document.getElementById("Employee_create_zip_code_paramKey").value = zip_code; 
	document.getElementById("Employee_create_state_paramKey").value = state; 
	document.getElementById("Employee_create_phone_paramKey").value = phone; 
	document.getElementById("Employee_create_status_paramKey").value = status; 
	document.getElementById("Employee_create_ss_number_paramKey").value = ss_number; 
	document.getElementById("Employee_create_salary_paramKey").value = salary; 
	document.getElementById("Employee_create_start_date_paramKey").value = start_date; 
	document.getElementById("Employee_create_termination_date_paramKey").value = termination_date; 
	document.getElementById("Employee_create_birth_date_paramKey").value = birth_date; 
	document.getElementById("Employee_create_bene_health_ins_paramKey").value = bene_health_ins; 
	document.getElementById("Employee_create_bene_life_ins_paramKey").value = bene_life_ins; 
	document.getElementById("Employee_create_bene_day_care_paramKey").value = bene_day_care; 
	document.getElementById("Employee_create_sex_paramKey").value = sex; 
	
}

//Use this method to add custom code after a screen is shown.
function customAfterShowScreen(screenToShow, screenToHide) {
	if((screenToShow == "Activate_Screen") && (screenToHide == "")){
		setTimeout("setCredential()", 3000); 
		setTimeout("clickMenu(\"Activate_Screen\", \"Activate\")", 5000); 
		return;
	}
	
	if(screenToShow == "Start_Screen"){
		if(CurrentCase > Cases.length-1){
			end();
			setTimeout("clickMenu(\"Start_Screen\", \"Close\")", 4000); 
			return;
		}
		if(Cases[CurrentCase] == "SyncCreate"){
			setTimeout("clickMenu(\"Start_Screen\", \"OpenDepartment_create\")", 5000); 
			return;
		}else if(Cases[CurrentCase] == "AsyncDelete"){
			setTimeout("clickMenu(\"Start_Screen\", \"OpenDepartment_delete\")", 5000); 
			return;
		}
		
		return;
	}
	
	

	if((screenToShow == "Department_create")&& (screenToHide == "Start_Screen")){
		setTimeout("setDeptCreatePara(301, \"sup\", \"501\")", 3000);
		setTimeout("clickMenu(\"Department_create\", \"Create\")", 5000);
		return;
	}
	
	if((screenToShow == "Department_delete")&& (screenToHide == "Start_Screen")){
//		setTimeout("setDeptDeletePara(301)", 3000);
//		setTimeout("clickMenu(\"Department_delete\", \"Delete\")", 5000);
//		return;
	}
	
	
	if((screenToShow == "Success")){
		if(Cases[CurrentCase] == "SyncCreate"){
			Result = Result + Cases[CurrentCase]+"=Pass;";
			setTimeout("navigateForward(\"Start_Screen\")", 3000);
			CurrentCase++;
		}else if(SICases[CurrentCase] == "SyncUpdate"){
			Result = Result + SICases[CurrentCase]+"=Pass;";
			setTimeout("navigateForward(\"DepartmentDetail\")", 3000);
			CurrentCase++;
		}
		return;
	}
	if((screenToShow == "ErrorList")){
		if(Cases[CurrentCase] == "SyncCreate"){
			Result = Result + Cases[CurrentCase]+"=Fail;";
			setTimeout("navigateForward(\"Start_Screen\")", 3000);
			CurrentCase++;
		}
		return;
	}
	
	if((screenToShow == "DepartmentDetail") && ((screenToHide == "") || (screenToHide == "Sucess"))){
		if(CurrentCase > SICases.length-1){
			end();
		}
		if(SICases[CurrentCase] == "SyncUpdate"){
			setTimeout("clickMenu(\"DepartmentDetail\", \"OpenDepartment_update_instance\")", 5000); 
			return;
		}
		if(SICases[CurrentCase] == "AddListview"){
			setTimeout("clickMenu(\"DepartmentDetail\", \"OpenEmployee\")", 5000); 
			return;
		}
		
	}
	
	if((screenToShow == "Employee") && (screenToHide == "DepartmentDetail")){
		
		alert(document.getElementById("Department_employees_relationshipKey").innerHTML);

		setTimeout("clickMenu(\"Employee\", \"Add\")", 5000); 
		return; 
	}
	
	if((screenToShow == "Employee_add") && (screenToHide == "Employee")){
		setTimeout("setEmpAddPara(100, 501, \"Mark\", \"Ma\", 302, \"2nd Keji Road\", \"Xian\", \"SX\", \"710075\", \"88351521\", \"A\",\"666\", \"15000\", \"2007-04-19\", \"2012-01-01\", \"1981-01-21\", \"Y\", \"Y\", \"Y\", \"M\")", 3000);
		setTimeout("clickMenu(\"Employee_add\", \"Create\")", 5000); 
		return; 
	}
	
	if((screenToShow == "Employee") && (screenToHide == "Employee_add")){
		setTimeout("clickMenu(\"Employee\", \"Back\")", 4000); 
		return; 
	}
	
	if((screenToShow == "DepartmentDetail") && (screenToHide == "Employee")){
		setTimeout("clickMenu(\"DepartmentDetail\", \"Submit\")", 4000); 
		return; 
	}
	
	if((screenToShow == "Department_update_instance")&& (screenToHide == "DepartmentDetail")){
		setTimeout("setDeptUpdatePara(\"updated\", 701)", 3000);
		setTimeout("clickMenu(\"Department_update_instance\", \"Update\")", 6000);
		return;
	}

	
	
	
	
}

//Use this method to add custom validate code to a screen
function customValidateScreen(screenKey, values) {
/*
    var rc = true;
    if (screenKey === "Create")
    {
        var form = document.forms[screenKey + "Form"];
        if (form)
        {
            var cost = form.ExpenseTracking_create_itemCost_paramKey.value;
            var LName = form.ExpenseTracking_create_lastName_paramKey.value;
            if (cost > 500 && (LName === "van Leeuwen")) {
                var helpElem = document.getElementById(screenKey + "_" + controlKey + "_help");
                setValidationText(helpElem, "Sorry Dan, you are on a short leash with the company credit card.");
                return false;
            }
        }
    }
*/
    return true;
}

//Use this method to add custom code when a menu item is clicked. If you return false, the default
//behavior will not be executed.
function customBeforeMenuItemClick(screen, menuItem) {
/*
    if (screen === "Create" && menuItem === "Quit") {
        return confirm("Are you sure you want to quit?");
    }
*/
    return true;
}


//Use this method to add custom code after a menu item has been clicked and the default behavior
//has been executed.
function customAfterMenuItemClick(screen, menuItem) {
}

//Use this method to add custom code before a screen is saved. If you return false, the default
//behavior will not be executed. 
function customBeforeSave(screen) {
    return true;
}

//Use this method to add custom code after a screen is saved.
function customAfterSave() {
}
/**
 * Handle whether to execute a conditional navigation.
 * @param currentScreenKey The current screen
 * @param actionName The originating action of the workflow message
 * @param defaultNextScreen The original default next screen, which will be executed if this returns false.
 * @param conditionName The name of the check to perform, in the context of this screen and action.  Set in the IDE.
 * @param workflowMessage The incoming workflow for any calculations.
 * @returns (true) in order to execute the matching workflow screen.  By default this returns (false).
 */
function customConditionalNavigation( currentScreenKey, actionName, defaultNextScreen, conditionName, workflowMessage ) {
/*
    // example code
    if((currentScreenKey === SERVERINITIATEDFLAG) && (actionName === '')) {
        // conditional start screen uses this magic screen key and the empty action name.
        if( conditionName === 'Marge') {
            // custom logic
            return true;
        }
        else if(conditionName === 'Lisa'){
            // custom logic
            // return true or false
            return false;
        }
    }
    else if((currentScreenKey === 'Search') && (actionName === 'By_First_Name')) {
        if( conditionName === 'Marge') {
            // custom logic
            return true;
        }
        else if(conditionName === 'Lisa'){
            // custom logic
            // return true or false
            return false;
        }
        else if(conditionName === 'Maggie'){
            // custom logic
            // return true or false
            return true;
        }
    }
	else if((defaultNextScreen === 'Employees') || (currentScreenKey === 'Search')) {
		if( conditionName === 'Marge') {
			// custom logic
			return true;
		}
		else if(conditionName === 'Lisa'){
			// custom logic
			// return true or false
			return false;
		}
		else if(conditionName === 'Maggie'){
			// custom logic
			// return true or false
			return true;
		}
	}
*/    
    // default case is to NOT change the flow
    return false;
}

//Use this method to add custom code when a native error is reported. If you return false, the default
//behavior will not be executed.
function customBeforeReportErrorFromNative(errorString) {
/*
    var callbackMethod = getURLParamFromNativeError("onErrorCallback", errorString);
    var errorCode = getURLParamFromNativeError("errCode", errorString);
    var onErrorMsg = getURLParamFromNativeError("onErrorMsg", errorString);
    var nativeMsg = getURLParamFromNativeError("nativeErrMsg", errorString);
    if (onErrorMsg || nativeMsg) {
        closeWorkflow();
    }
*/
    return true;
}

//Use this method to add custom code after a native error is reported
function customAfterReportErrorFromNative(errorString) {
}

//Use this method to add custom code after data is received
function customAfterDataReceived(incomingWorkflowMessage) {
}


/**
* Loaded in ExternalResource.js
*/
function uploadData(d)
{
// var fakeXHR;
var options =
{
method : "POST",
async : false,
data : (d),
// data : ("user=eric;age=10"),
headers : ("Content-Type", "application/x-www-form-urlencoded" ),
// complete : function(response) { fakeXHR = response; }
}
;

getExternalResource(server(), options);
// var strText = fakeXHR.responseText;
// alert(strText);
// return strText;
}

function end()
{
uploadData(Result);
uploadData("EOM=true");
}

function uploadIdValue(screen, id)
{
var element = getElementInScreen(screen, id);
var data = "screen=" + screen + ";id=" + id + ";value=" + element.value;
uploadData(data);
}

function server()
{
return "http://10.56.252.114:8008";
}

function getElementInScreen(screen, id){
var fullScreenName = screen+"ScreenDiv"
var elm;
var elms = document.getElementById(fullScreenName).getElementsByTagName("*");
alert(elms.length);
for (var i = 0; i < elms.length; i++) {
if (elms[i].id == id) {
elm = elms[i];
break;
}
}
return elm;

}
