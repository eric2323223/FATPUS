/*
 * Sybase Mobile Workflow version 2.1
 * 
 * Workflow.js
 * This file will be regenerated, so changes made herein will be removed the
 * next time the workflow is regenerated. It is therefore strongly recommended
 * that the user not make changes in this file.
 * 
 * The template used to create this file was compiled on Sun Aug 21 16:47:10 PDT 2011
 *
 * Copyright (c) 2010, 2011 Sybase Inc. All rights reserved.
 */



function menuItemCallbackStart_ScreenCancelScreen() {
    if (!customBeforeMenuItemClick('Start_Screen', 'CancelScreen')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Start_Screen', 'CancelScreen');
}


function menuItemCallbackStart_ScreengetById() {
    if (!customBeforeMenuItemClick('Start_Screen', 'getById')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'deptidkey';
    rmiKeyTypes[0] = 'NUMBER';
    rmiInputOnlyKeys[0] = 'deptidkey';
    rmiInputOnlyKeyTypes[0] = 'NUMBER';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Start_Screen', 'getById', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Start_Screen', 'getById', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('Start_Screen', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('Start_Screen', 'getById', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Start_Screen', 'getById');
}


function menuItemCallbackDepartment_update_instanceUpdate() {
    if (!customBeforeMenuItemClick('Department_update_instance', 'Update')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'Department_dept_name_attribKey';
    rmiKeyTypes[0] = 'TEXT';
    rmiKeys[1] = '_old.Department.dept_name';
    rmiKeyTypes[1] = 'TEXT';
    rmiKeys[2] = 'Department_dept_head_id_attribKey';
    rmiKeyTypes[2] = 'NUMBER';
    rmiKeys[3] = '_old.Department.dept_head_id';
    rmiKeyTypes[3] = 'NUMBER';
    rmiKeys[4] = 'Department_dept_id_attribKey';
    rmiKeyTypes[4] = 'NUMBER';
    rmiKeys[5] = '_old.Department.dept_id';
    rmiKeyTypes[5] = 'NUMBER';
    rmiKeys[6] = 'ErrorLogs';
    rmiKeyTypes[6] = 'LIST';
    rmiKeys[7] = 'Department_employees_relationshipKey';
    rmiKeyTypes[7] = 'LIST';
    rmiKeys[8] = '_old.Department.employees.Department_employees_relationshipKey';
    rmiKeyTypes[8] = 'LIST';
    rmiInputOnlyKeys[0] = 'Department_dept_name_attribKey';
    rmiInputOnlyKeyTypes[0] = 'TEXT';
    rmiInputOnlyKeys[1] = '_old.Department.dept_name';
    rmiInputOnlyKeyTypes[1] = 'TEXT';
    rmiInputOnlyKeys[2] = 'Department_dept_head_id_attribKey';
    rmiInputOnlyKeyTypes[2] = 'NUMBER';
    rmiInputOnlyKeys[3] = '_old.Department.dept_head_id';
    rmiInputOnlyKeyTypes[3] = 'NUMBER';
    rmiInputOnlyKeys[4] = 'Department_dept_id_attribKey';
    rmiInputOnlyKeyTypes[4] = 'NUMBER';
    rmiInputOnlyKeys[5] = '_old.Department.dept_id';
    rmiInputOnlyKeyTypes[5] = 'NUMBER';
    rmiInputOnlyKeys[6] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[6] = 'LIST';
    rmiInputOnlyKeys[7] = 'Department_employees_relationshipKey';
    rmiInputOnlyKeyTypes[7] = 'LIST';
    rmiInputOnlyKeys[8] = '_old.Department.employees.Department_employees_relationshipKey';
    rmiInputOnlyKeyTypes[8] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department_update_instance', 'Update', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department_update_instance', 'Update', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('Department_update_instance', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('Department_update_instance', 'Update', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Department_update_instance', 'Update');
}


function menuItemCallbackDepartment_update_instanceCancel() {
    if (!customBeforeMenuItemClick('Department_update_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department_update_instance', 'Cancel');
}


function menuItemCallbackDepartment_delete_instanceDelete() {
    if (!customBeforeMenuItemClick('Department_delete_instance', 'Delete')) {
        return;
    }
    var rmiKeys = [];
    var rmiKeyTypes = [];
    var rmiInputOnlyKeys = [];
    var rmiInputOnlyKeyTypes = [];
    rmiKeys[0] = 'Department_dept_id_attribKey';
    rmiKeyTypes[0] = 'NUMBER';
    rmiKeys[1] = '_old.Department.dept_id';
    rmiKeyTypes[1] = 'NUMBER';
    rmiKeys[2] = 'ErrorLogs';
    rmiKeyTypes[2] = 'LIST';
    rmiKeys[3] = 'Department_dept_name_attribKey';
    rmiKeyTypes[3] = 'TEXT';
    rmiKeys[4] = '_old.Department.dept_name';
    rmiKeyTypes[4] = 'TEXT';
    rmiKeys[5] = 'Department_dept_head_id_attribKey';
    rmiKeyTypes[5] = 'NUMBER';
    rmiKeys[6] = '_old.Department.dept_head_id';
    rmiKeyTypes[6] = 'NUMBER';
    rmiKeys[7] = 'Department_employees_relationshipKey';
    rmiKeyTypes[7] = 'LIST';
    rmiKeys[8] = '_old.Department.employees.Department_employees_relationshipKey';
    rmiKeyTypes[8] = 'LIST';
    rmiInputOnlyKeys[0] = 'Department_dept_id_attribKey';
    rmiInputOnlyKeyTypes[0] = 'NUMBER';
    rmiInputOnlyKeys[1] = '_old.Department.dept_id';
    rmiInputOnlyKeyTypes[1] = 'NUMBER';
    rmiInputOnlyKeys[2] = 'ErrorLogs';
    rmiInputOnlyKeyTypes[2] = 'LIST';
    rmiInputOnlyKeys[3] = 'Department_dept_name_attribKey';
    rmiInputOnlyKeyTypes[3] = 'TEXT';
    rmiInputOnlyKeys[4] = '_old.Department.dept_name';
    rmiInputOnlyKeyTypes[4] = 'TEXT';
    rmiInputOnlyKeys[5] = 'Department_dept_head_id_attribKey';
    rmiInputOnlyKeyTypes[5] = 'NUMBER';
    rmiInputOnlyKeys[6] = '_old.Department.dept_head_id';
    rmiInputOnlyKeyTypes[6] = 'NUMBER';
    rmiInputOnlyKeys[7] = 'Department_employees_relationshipKey';
    rmiInputOnlyKeyTypes[7] = 'LIST';
    rmiInputOnlyKeys[8] = '_old.Department.employees.Department_employees_relationshipKey';
    rmiInputOnlyKeyTypes[8] = 'LIST';
    var workflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department_delete_instance', 'Delete', rmiKeys, rmiKeyTypes);
    var inputOnlyWorkflowMessageToSend = getMessageValueCollectionForOnlineRequest('Department_delete_instance', 'Delete', rmiInputOnlyKeys, rmiInputOnlyKeyTypes);
    if (validateScreen('Department_delete_instance', getCurrentMessageValueCollection(), rmiKeys) && 
        saveScreens(true)) {
        doOnlineRequest('Department_delete_instance', 'Delete', 60, 0, '', null, workflowMessageToSend, inputOnlyWorkflowMessageToSend.serializeToString());
    }
    customAfterMenuItemClick('Department_delete_instance', 'Delete');
}


function menuItemCallbackDepartment_delete_instanceCancel() {
    if (!customBeforeMenuItemClick('Department_delete_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department_delete_instance', 'Cancel');
}


function menuItemCallbackDepartmentDetailSubmit() {
    if (!customBeforeMenuItemClick('DepartmentDetail', 'Submit')) {
        return;
    }

    if (saveScreens()) {
        doSubmitWorkflow('DepartmentDetail', 'Submit', '', '');
    }
    customAfterMenuItemClick('DepartmentDetail', 'Submit');
}


function menuItemCallbackDepartmentDetailOpenEmployee() {
    if (!customBeforeMenuItemClick('DepartmentDetail', 'OpenEmployee')) {
        return;
    }
    navigateForward('Employee');
    customAfterMenuItemClick('DepartmentDetail', 'OpenEmployee');
}


function menuItemCallbackDepartmentDetailOpenDepartment_update_instance() {
    if (!customBeforeMenuItemClick('DepartmentDetail', 'OpenDepartment_update_instance')) {
        return;
    }
    navigateForward('Department_update_instance');
    customAfterMenuItemClick('DepartmentDetail', 'OpenDepartment_update_instance');
}


function menuItemCallbackDepartmentDetailOpenDepartment_delete_instance() {
    if (!customBeforeMenuItemClick('DepartmentDetail', 'OpenDepartment_delete_instance')) {
        return;
    }
    navigateForward('Department_delete_instance');
    customAfterMenuItemClick('DepartmentDetail', 'OpenDepartment_delete_instance');
}


function menuItemCallbackDepartmentDetailBack() {
    if (!customBeforeMenuItemClick('DepartmentDetail', 'Back')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('DepartmentDetail', 'Back');
}
function menuItemCallbackDepartmentDetailCancel() {
    if (!customBeforeMenuItemClick('DepartmentDetail', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('DepartmentDetail', 'Cancel');
}


function menuItemCallbackEmployeeAdd() {
    if (!customBeforeMenuItemClick('Employee', 'Add')) {
        return;
    }
    doAddRowAction('Employee_add');
    customAfterMenuItemClick('Employee', 'Add');
}


function menuItemCallbackEmployeeBack() {
    if (!customBeforeMenuItemClick('Employee', 'Back')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('Employee', 'Back');
}
function menuItemCallbackEmployeeCancel() {
    if (!customBeforeMenuItemClick('Employee', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Employee', 'Cancel');
}


function menuItemCallbackEmployee_addCreate() {
    if (!customBeforeMenuItemClick('Employee_add', 'Create')) {
        return;
    }
    doListviewAddRowAction("Department_employees_relationshipKey");
    customAfterMenuItemClick('Employee_add', 'Create');
}


function menuItemCallbackEmployee_addCancel() {
    if (!customBeforeMenuItemClick('Employee_add', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Employee_add', 'Cancel');
}


function menuItemCallbackEmployee_update_instanceUpdate() {
    if (!customBeforeMenuItemClick('Employee_update_instance', 'Update')) {
        return;
    }
    doListviewUpdateRowAction("Department_employees_relationshipKey");
    customAfterMenuItemClick('Employee_update_instance', 'Update');
}


function menuItemCallbackEmployee_update_instanceCancel() {
    if (!customBeforeMenuItemClick('Employee_update_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Employee_update_instance', 'Cancel');
}


function menuItemCallbackEmployeeDetailOpenEmployee_update_instance() {
    if (!customBeforeMenuItemClick('EmployeeDetail', 'OpenEmployee_update_instance')) {
        return;
    }
    navigateForward('Employee_update_instance');
    customAfterMenuItemClick('EmployeeDetail', 'OpenEmployee_update_instance');
}


function menuItemCallbackEmployeeDetailEmployee_delete_instance() {
    if (!customBeforeMenuItemClick('EmployeeDetail', 'Employee_delete_instance')) {
        return;
    }
    doListviewDeleteRowAction("Department_employees_relationshipKey");
    customAfterMenuItemClick('EmployeeDetail', 'Employee_delete_instance');
}


function menuItemCallbackEmployeeDetailBack() {
    if (!customBeforeMenuItemClick('EmployeeDetail', 'Back')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('EmployeeDetail', 'Back');
}
function menuItemCallbackEmployeeDetailCancel() {
    if (!customBeforeMenuItemClick('EmployeeDetail', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('EmployeeDetail', 'Cancel');
}

function doAddRowAction(addScreen) {
    var mvc = getCurrentMessageValueCollection();
    var relationKey = getListViewKey(getCurrentScreen());
    var mv = mvc.getData(relationKey);
    var childMVC = new MessageValueCollection();
    var key = guid();
    childMVC.setKey(key);
    childMVC.setState("new");
    childMVC.setParent(mv.getKey());
    childMVC.setParentValue(mv);
    mv.getValue().push(childMVC);
    setDefaultValues(addScreen);
    // collect default values from the addScreen
    updateMessageValueCollectionFromUI(childMVC, addScreen);
    navigateForward(addScreen, key);
}

function doListviewAddRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (mvc.getState() === "new") {
        // this action is triggered after AddRow action
        if (validateScreen(getCurrentScreen(), mvc)) {
            mvc.setState("add");
            doSaveAction(false);
        }
    }
}

function doListviewUpdateRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("update");            
        }
        doSaveAction(false);
    }
}

function doListviewDeleteRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("delete");            
            doSaveAction(false);
        }
        else {
            var valuesArray = mvc.getParentValue().getValue();
            for (var i = 0; i < valuesArray.length; i++) {
                if (valuesArray[i] == mvc) {
                    valuesArray.splice(i, 1);
                }
            }
            navigateBack(true);
            updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        }        
    }
}

function doSaveActionWithoutReturn() {
   doSaveAction();
   return;
}

function doSaveAction(needValidation) {
    if (!getPreviousScreen()) {
        if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
            doSubmitWorkflow(getCurrentScreen(), "Save", '', '');
            return false;
        }
        return true;
    }
    if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
        navigateBack(false);
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        return true;
    }
    return false;
}

function doCancelAction() {
    if (!getPreviousScreen()) {
        closeWorkflow();
        return;
    }
    var mvc = getCurrentMessageValueCollection();
    navigateBack(true);
    var mvc1 = getCurrentMessageValueCollection();
    if (mvc.getState() === "add" || mvc.getState() === "new") {
        mvc1.getData(mvc.getParent()).getValue().pop();
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
    } else if (mvc.getState() === "update") {
        mvc.setState("");
    }
}

function customNavigationEntry() {
    this.condition;
    this.screen;
}
function customNavigationEntry( a_condition, a_screen ) {
    this.condition = a_condition;
    this.screen = a_screen;
}

/**
 * For the specific pair - screen named 'currentScreenKey' and the action 'actionName', return
 * the list of custom navigation condition-names and their destination screens.
 */
function getCustomNavigations( currentScreenKey, actionName )  {
    var customNavigations = new Array();
    return customNavigations;
}
