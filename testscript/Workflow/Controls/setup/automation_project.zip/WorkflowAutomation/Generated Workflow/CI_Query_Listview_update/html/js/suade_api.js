/**
 * Loaded in ExternalResource.js
 */
function uploadData(d)
{
   // 	var fakeXHR;
   var options =
   {
      method : "POST",
      async : false,
      data : (d),
      // 	data : ("user=eric;age=10"),
      headers : ("Content-Type", "application/x-www-form-urlencoded"	),
      // 	complete : function(response) { fakeXHR = response; }
   }
   ;

   getExternalResource(server(), options);
   // 	var strText = fakeXHR.responseText;
   // 	alert(strText);
   // 	return strText;
}

function end()
{
   uploadData("EOM=true");
}

function uploadIdValue(screen, id)
{
   var element = getElementInScreen(screen, id);
   var data = "screen=" + screen + ";id=" + id + ";value=" + element.value;
   uploadData(data);
}

function server()
{
   return "http://10.56.252.114:8008";
}

function getElementInScreen(screen, id){
	var fullScreenName = screen+"ScreenDiv"
	var elm;
    var elms = document.getElementById(fullScreenName).getElementsByTagName("*");
    for (var i = 0; i < elms.length; i++) {
        if (elms[i].id == id) {
            elm = elms[i];
            break;
        }
    }
    return elm;

}