$.widget("sy.syListview", {
    _create:function() {
       this.iscroller = null;
    
       if ( this.options.showViewHeader ){
            this._createHeader();
            this.iscroller = new iScroll ();
       }
       var self = this;
 
       UIFrameResizeHandlers.push( function( ) {  
    	   self.orientationChanged();
       });
    },
    
    orientationChanged:function() {
    	if ( (this.element.listview.height() > 0 )  ) {
    		this.orientation = window.orientation;
    		var fields =$.mobile.activePage.find(".lv_line_field" );
    		var j;
    		for( j=0;j < fields.length; j++ ) {
    			var fw = $( fields[j]).attr('field_width');
    			var lineW =   window.innerWidth -20  - 30-10 ;//20 for margins,jquery mobile 1.0a4.1 added 15px padding to content. 10px for text padding
            	var ww=  parseInt(lineW) * parseInt(fw) /100;
               $( fields[j]).css('width',ww  );
           }
    	
    	}
    },
    
    updateOnVisible : function( params ) {
    	if ( this.iscroller == null ) {
    		return;
    	}
    	if ( params[1] == 'true'){
    		 this.iscroller.showPage(params[0], false );
    	}else {
              this.iscroller.hidePage(params[0]);
       }
    },
      
    updateUIFromWorkFlowMessage:function( params ) {
        var id = this.element[0].getAttribute('id');
        var data  = params[0].getData( id );
     
        if (!data) {
            data = new MessageValue();
            data.setType("LIST");
            data.setKey(id);
            data.setValue(new Array(0));
            params[0].add(id, data);
        }
        var dataValue = data.value;
             
        var wrapData = this.element[0].getAttribute('wrap_data');
        wrapData = wrapData != null && wrapData === "true"; 

        var fields = this.options.fields;
        var lines = this.options.lines;
     
        var cellstr = "";
             
        var numValues = dataValue.length;
        for (var valuesIdx = 0; valuesIdx < numValues; valuesIdx++) { //for each values in a list
            var listValues = dataValue[valuesIdx];
            if (listValues.getState() === "delete") {
                continue;
            }            
                  
            var test =valuesIdx/2 -  Math.round(valuesIdx/2 );
            var  setAltClr =  test < 0  && this.options. alternateColor.length > 0;
            var alterClr =  this.element.attr('screen') + "_defaultColor";  
            if ( setAltClr ) {
                alterClr = this.element.attr('screen') + "_alternateColor";
            }
            
            cellstr += '<li role="option" class="'+ alterClr +'" id="'+ valuesIdx + '">';
          
            if ( this.options.onItemSelected  !== null ) { 
                cellstr += '<a href="" class="listviewLines ui-link-inherit" id="' +listValues.getKey() +'">';
            }
            
            cellstr += this._createLines( data, valuesIdx, false, wrapData );
            
            if ( this.options.onItemSelected  !== null ) {
            	cellstr += '</a></li>';
            }else {
                cellstr += '</li>';
            }
        }
     
        if (numValues === 0 && this.options.onEmptyList) {
            cellstr += '<li role="option">';
            cellstr += '<div class="lv_line">';
            var value  =this.options.onEmptyList;

            var lineWidth = screen.width -40; //20 for arrow and 20 for margins
            var w = parseInt( lineWidth );
            var style = ' float: left; width:' + w + 'px;' + 'font-style:normal;font-weight:normal';
            var s = '<div  class="lv_line_field" style="'+ style +'">'+ value+'</div>';
            cellstr += s;
            cellstr += '</div></li>';
        }
       
       var listUL = this.element.find('ul#listview_'+ id );
       if ( listUL.length > 0 ) {
    	   listUL.html(cellstr);
	       $(listUL[0]).listview('refresh');
       }else {
	       this.element.listview = $('<ul id="listview_'+ id+ '" data-role="listview"  data-inset="' + this.options.inset + '" >');
           this.element.append( this.element.listview );
           this.element.listview.html( cellstr);
       }
    
        if (numValues > 0 || !this.options.onEmptyList) {
	        var self = this;
	   
	        if (isBlackBerry()) {
	        
	            $('div.lv_lines',this.element.listview).bind('click',  function(){
	               
	                var liEle = this.parentElement.parentElement.parentElement;
	                $( liEle ).addClass("ui-btn-down-c");
	                
	                if ( self.options.onItemSelected != null ) {
	                    self.options.onItemSelected( this  );
	                } 
	                $( liEle ).removeClass("ui-btn-down-c");
	           });
	        
	        }
	        else if (isWindows()) {
	            $('a.listviewLines',this.element.listview).bind('click',  function() {
	                var li = this.parentElement.parentElement.parentElement.parentElement.parentElement;
	                $(li).addClass('ui-btn-down-c');
	                    if ( self.options.onItemSelected != null) {
	                        self.options.onItemSelected(this);
	                    }
	                $(li).removeClass('ui-btn-down-c');
	            });
		    }
	        else {
	            var that = this;
	            
	            $('a.listviewLines',this.element.listview).bind('touchstart',  function(){
	                that.isTouchMove = false;
	            });
	            
	            $('a.listviewLines',this.element.listview).bind('touchmove',  function(){
	                that.isTouchMove = true;
	            });
	              
	            $('a.listviewLines',this.element.listview).bind('touchend',  function(){
	                if ( that.isTouchMove ) {
	                    return;
	                }
	                
	                if (isAndroid()) {
	                   $(this.parentElement.parentElement.parentElement).addClass("ui-btn-down-c");
	                }
	                
	                if ( self.options.onItemSelected != null ) {
	                     self.options.onItemSelected( this  );
	                } 
	                   
	            });
	        }
        }
    },
    
    _createLines:function( data,valuesIdx, isForHeader, wrapData  ) {
       var lines = this.options.lines;
       var isLocaleDisplay = this.options.isLocaleDisplay;
        var cellstr = "";
        var listValues =  null;
        
        if (    data != null ) {      
            listValues = data.value[valuesIdx];
        }
        
        if ( listValues != null ) {
            cellstr += '<div class="lv_lines" id="' +listValues.getKey() +'">';
        }else {
            cellstr += '<div class="lv_lines">';
        }    
        
        var numLines = lines.length;
        for( var l = 0; l < numLines; l++ ) {
            cellstr += '<div class="lv_line">';
            var numFields = lines[l].length;
            for( var f = 0; f < numFields; f++ ) {
                var field = lines[l][f];
                var fieldData = (listValues) ? listValues.getData(field.id) : listValues;
                var value = field.name;
            
                if ( fieldData ) {
                    value  = fieldData.value;
                    if (field.dataType === "DATE") {
                        var aDate = undefined;
						var strIdx = value.indexOf("T");
						if (strIdx !== -1) {
							aDate = new Date(parseDateTime(null, value.substr(0, strIdx)));
						}
						else {
							aDate = new Date(parseDateTime(null, value));
						}
						if(isLocaleDisplay === "true"){
							value = getLocaleDateString(aDate);
						}
						else{
							value = getISODateString(aDate);
						}
						
                    } else if (field.dataType === "TIME") {
                        var aTime = undefined;
						var strIdx = value.indexOf("T");
						if (strIdx !== -1) {
							aTime = new Date(parseTime(value.substr(strIdx+1)));
						}
						else {
							aTime = new Date(parseTime(value));
						}
						if(isLocaleDisplay === "true"){
							value = getLocaleTimeString(aTime);
						}
						else{
							value = getISOTimeString(aTime);
						}
                    } else if (field.dataType === "DATETIME") {
                        var aDateTime = new Date(parseDateTime(null, value));
						aDateTime = convertUtcToLocalTime(aDateTime);
						if(isLocaleDisplay === "true"){
							value = getLocaleDateTimeString(aDateTime);
						}
						else{
							value = getISODateTimeString(aDateTime);
						}
                    } else if (field.dataType === "IMAGE" && field.static) {
                         value ='<img data-role="none" src="' + fieldData.value +'" height="' + field.height + '"/>';
                    } else if ( field.dataType === "IMAGE" && !field.static) {
                         value ='<img data-role="none" src="data:image/jpeg;base64,' + fieldData.value +'" height="' + field.height + '"/>';
                    }

                    if( value === '' ) {
                    	// Empty value.  Use a filler to maintain row height for the value.
                    	value = '<p></p>';
                    } else {
                    	if( wrapData ) {
                    		// User has HTML tags that they want treated as text
                    		// in the list, not markup.  Replace all &, <, and >
                    		// and wrap in PRE and CODE tags.
                    		value = value.toString().replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
                    		value = "<PRE><CODE>" + value + "</CODE></PRE>";
                    	}
                    }
                } else if ( !isForHeader )  {
                	// No data for the field.id, use a filler
                	value = '<p></p>';
                }
                var lineWidth = window.innerWidth -20  - 30-10 ; //20 for margins,jquery mobile 1.0a4.1 added 15px padding to content. 10px for text padding
                var w = parseInt( lineWidth * field.width/100);
                var font = "normal";
                if (  data != null  ) { 
                    font  =field.font;
                }
                var style = ' float: left; width:' + w + 'px;' + 'font-style:' + font +';font-weight:normal';
               
                if ( field.font == "bold" ) {
                    style = style.replace('font-weight:normal', 'font-weight:bold');
                } 
                if ( field.dataType === 'IMAGE') {
                	 var style = ' float: left; width:' + w + 'px; height:' + field.height +'px';
                }
                s = '<div  class="lv_line_field" field_width="'+ field.width +'" style="'+ style +'">'+ value+'</div>';
                cellstr += s;
            }  
            cellstr += '</div>'; //end of line;
        }
        cellstr += '</div>'; //end of lines 
     
        return cellstr;
    },
      
     _createHeader:function() {
        var parents = this.element.parents();
        var page = null;
        
        var numParents = parents.length;
        for( var i =0; i < numParents; i++ ) {
            var node = parents.get( i);
            var value = $(node).attr('data-role');
            if ( value == 'page' ) {
                page = node;
                break;
            }
        }
        
        var header = null;
        var footer = null;
        
        
        if ( page != null ) {
            var children = page.children;
            value = "";
            
            var numChildren = children.length;
            for( var i =0; i < numChildren ; i++ ) {
                var value = $(children[i]).attr('data-role');
                if ( value =='header') {
                    header = children[i];
                }else if ( value =='footer') {
                    footer = children[i];
                }
             }
        }
        
        if ( header != null && this.options.showViewHeader ) {
            var listheader =  $('<div class="listview_header ui-bar-a" >');
            $(header).after( listheader );
            listheader.append( this._createLines( null, null, true ));
        }
     },
        
     options : {
         lines : null,
         data:[],
         showViewHeader:false,
         onEmptyList:"",
         alternateColor:"",
         onItemSelected:null,
         inset:"false",
         isLocalized:"false"
    }
});

