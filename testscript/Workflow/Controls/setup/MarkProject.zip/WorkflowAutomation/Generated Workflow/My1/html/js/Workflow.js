/*
 * Sybase Mobile Workflow version 2.1
 * 
 * Workflow.js
 * This file will be regenerated, so changes made herein will be removed the
 * next time the workflow is regenerated. It is therefore strongly recommended
 * that the user not make changes in this file.
 * 
 * The template used to create this file was compiled on Sun Aug 21 16:47:10 PDT 2011
 *
 * Copyright (c) 2010, 2011 Sybase Inc. All rights reserved.
 */



function menuItemCallbackDepartment_update_instanceSubmit_Workflow() {
    if (!customBeforeMenuItemClick('Department_update_instance', 'Submit Workflow')) {
        return;
    }

    if (saveScreens()) {
        doSubmitWorkflow('Department_update_instance', 'Submit Workflow', '', '');
    }
    customAfterMenuItemClick('Department_update_instance', 'Submit Workflow');
}


function menuItemCallbackDepartment_update_instanceCancel() {
    if (!customBeforeMenuItemClick('Department_update_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department_update_instance', 'Cancel');
}


function menuItemCallbackDepartment_delete_instanceSubmit_Workflow() {
    if (!customBeforeMenuItemClick('Department_delete_instance', 'Submit Workflow')) {
        return;
    }

    if (saveScreens()) {
        doSubmitWorkflow('Department_delete_instance', 'Submit Workflow', '', '');
    }
    customAfterMenuItemClick('Department_delete_instance', 'Submit Workflow');
}


function menuItemCallbackDepartment_delete_instanceCancel() {
    if (!customBeforeMenuItemClick('Department_delete_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Department_delete_instance', 'Cancel');
}


function menuItemCallbackDepartmentDetailSubmit() {
    if (!customBeforeMenuItemClick('DepartmentDetail', 'Submit')) {
        return;
    }

    if (saveScreens()) {
        doSubmitWorkflow('DepartmentDetail', 'Submit', '', '');
    }
    customAfterMenuItemClick('DepartmentDetail', 'Submit');
}


function menuItemCallbackDepartmentDetailOpen_Employee() {
    if (!customBeforeMenuItemClick('DepartmentDetail', 'Open Employee')) {
        return;
    }
    navigateForward('Employee');
    customAfterMenuItemClick('DepartmentDetail', 'Open Employee');
}


function menuItemCallbackDepartmentDetailOpen_Department_update_instance() {
    if (!customBeforeMenuItemClick('DepartmentDetail', 'Open Department_update_instance')) {
        return;
    }
    navigateForward('Department_update_instance');
    customAfterMenuItemClick('DepartmentDetail', 'Open Department_update_instance');
}


function menuItemCallbackDepartmentDetailOpen_Department_delete_instance() {
    if (!customBeforeMenuItemClick('DepartmentDetail', 'Open Department_delete_instance')) {
        return;
    }
    navigateForward('Department_delete_instance');
    customAfterMenuItemClick('DepartmentDetail', 'Open Department_delete_instance');
}
function menuItemCallbackDepartmentDetailCancel() {
    if (!customBeforeMenuItemClick('DepartmentDetail', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('DepartmentDetail', 'Cancel');
}


function menuItemCallbackEmployeeAdd() {
    if (!customBeforeMenuItemClick('Employee', 'Add')) {
        return;
    }
    doAddRowAction('Employee_add');
    customAfterMenuItemClick('Employee', 'Add');
}


function menuItemCallbackEmployeeBack() {
    if (!customBeforeMenuItemClick('Employee', 'Back')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('Employee', 'Back');
}
function menuItemCallbackEmployeeCancel() {
    if (!customBeforeMenuItemClick('Employee', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Employee', 'Cancel');
}


function menuItemCallbackEmployee_addAdd_Key_Collection() {
    if (!customBeforeMenuItemClick('Employee_add', 'Add Key Collection')) {
        return;
    }
    doListviewAddRowAction("Department_employees_relationshipKey");
    customAfterMenuItemClick('Employee_add', 'Add Key Collection');
}


function menuItemCallbackEmployee_addCancel() {
    if (!customBeforeMenuItemClick('Employee_add', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Employee_add', 'Cancel');
}


function menuItemCallbackEmployee_update_instanceUpdate_Key_Collection() {
    if (!customBeforeMenuItemClick('Employee_update_instance', 'Update Key Collection')) {
        return;
    }
    doListviewUpdateRowAction("Department_employees_relationshipKey");
    customAfterMenuItemClick('Employee_update_instance', 'Update Key Collection');
}


function menuItemCallbackEmployee_update_instanceCancel() {
    if (!customBeforeMenuItemClick('Employee_update_instance', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('Employee_update_instance', 'Cancel');
}


function menuItemCallbackEmployeeDetailOpen_Screen_Employee_update_instance() {
    if (!customBeforeMenuItemClick('EmployeeDetail', 'Open Screen Employee_update_instance')) {
        return;
    }
    navigateForward('Employee_update_instance');
    customAfterMenuItemClick('EmployeeDetail', 'Open Screen Employee_update_instance');
}


function menuItemCallbackEmployeeDetailEmployee_delete_instance() {
    if (!customBeforeMenuItemClick('EmployeeDetail', 'Employee_delete_instance')) {
        return;
    }
    doListviewDeleteRowAction("Department_employees_relationshipKey");
    customAfterMenuItemClick('EmployeeDetail', 'Employee_delete_instance');
}


function menuItemCallbackEmployeeDetailBack() {
    if (!customBeforeMenuItemClick('EmployeeDetail', 'Back')) {
        return;
    }
    doSaveAction();
    customAfterMenuItemClick('EmployeeDetail', 'Back');
}
function menuItemCallbackEmployeeDetailCancel() {
    if (!customBeforeMenuItemClick('EmployeeDetail', 'Cancel')) {
        return;
    }
    doCancelAction();
    customAfterMenuItemClick('EmployeeDetail', 'Cancel');
}

function doAddRowAction(addScreen) {
    var mvc = getCurrentMessageValueCollection();
    var relationKey = getListViewKey(getCurrentScreen());
    var mv = mvc.getData(relationKey);
    var childMVC = new MessageValueCollection();
    var key = guid();
    childMVC.setKey(key);
    childMVC.setState("new");
    childMVC.setParent(mv.getKey());
    childMVC.setParentValue(mv);
    mv.getValue().push(childMVC);
    setDefaultValues(addScreen);
    // collect default values from the addScreen
    updateMessageValueCollectionFromUI(childMVC, addScreen);
    navigateForward(addScreen, key);
}

function doListviewAddRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (mvc.getState() === "new") {
        // this action is triggered after AddRow action
        if (validateScreen(getCurrentScreen(), mvc)) {
            mvc.setState("add");
            doSaveAction(false);
        }
    }
}

function doListviewUpdateRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("update");            
        }
        doSaveAction(false);
    }
}

function doListviewDeleteRowAction(listKey) {
    var mvc = getCurrentMessageValueCollection(listKey);
    if (validateScreen(getCurrentScreen(), mvc)) {
        if (mvc.getState() !== "add") {
            mvc.setState("delete");            
            doSaveAction(false);
        }
        else {
            var valuesArray = mvc.getParentValue().getValue();
            for (var i = 0; i < valuesArray.length; i++) {
                if (valuesArray[i] == mvc) {
                    valuesArray.splice(i, 1);
                }
            }
            navigateBack(true);
            updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        }        
    }
}

function doSaveActionWithoutReturn() {
   doSaveAction();
   return;
}

function doSaveAction(needValidation) {
    if (!getPreviousScreen()) {
        if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
            doSubmitWorkflow(getCurrentScreen(), "Save", '', '');
            return false;
        }
        return true;
    }
    if(saveScreen(getCurrentMessageValueCollection(), getCurrentScreen(), needValidation)) {
        navigateBack(false);
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
        return true;
    }
    return false;
}

function doCancelAction() {
    if (!getPreviousScreen()) {
        closeWorkflow();
        return;
    }
    var mvc = getCurrentMessageValueCollection();
    navigateBack(true);
    var mvc1 = getCurrentMessageValueCollection();
    if (mvc.getState() === "add" || mvc.getState() === "new") {
        mvc1.getData(mvc.getParent()).getValue().pop();
        updateUIFromMessageValueCollection(getCurrentScreen(), getCurrentMessageValueCollection());
    } else if (mvc.getState() === "update") {
        mvc.setState("");
    }
}

function customNavigationEntry() {
    this.condition;
    this.screen;
}
function customNavigationEntry( a_condition, a_screen ) {
    this.condition = a_condition;
    this.screen = a_screen;
}

/**
 * For the specific pair - screen named 'currentScreenKey' and the action 'actionName', return
 * the list of custom navigation condition-names and their destination screens.
 */
function getCustomNavigations( currentScreenKey, actionName )  {
    var customNavigations = new Array();
    return customNavigations;
}
